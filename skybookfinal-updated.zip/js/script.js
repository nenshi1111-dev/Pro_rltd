/* ============================================================
   AIRSMART AI - MAIN JAVASCRIPT FILE
   Handles: password show/hide, smooth scroll, simple client
   side validation helpers, seat selection UI.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  // ---------- Password show/hide eye icon ----------
  // Works for every input that has a sibling icon with class "toggle-eye"
  document.querySelectorAll('.toggle-eye').forEach(function (icon) {
    icon.addEventListener('click', function () {
      var input = icon.parentElement.querySelector('input');
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
      } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
      }
    });
  });

  // ---------- Smooth scroll for anchor links ----------
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var targetId = this.getAttribute('href');
      if (targetId.length > 1) {
        var target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });

  // ---------- Simple fade-in on scroll ----------
  var fadeEls = document.querySelectorAll('.fade-on-scroll');
  if (fadeEls.length) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('fade-in-active');
        }
      });
    }, { threshold: 0.15 });
    fadeEls.forEach(function (el) { observer.observe(el); });
  }

  // ---------- Credit card number: allow only digits, max 16 ----------
  var cardInput = document.getElementById('card_number');
  if (cardInput) {
    cardInput.addEventListener('input', function () {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 16);
    });
  }

  // ---------- CVV: allow only digits, max 3 ----------
  var cvvInput = document.getElementById('cvv');
  if (cvvInput) {
    cvvInput.addEventListener('input', function () {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 3);
    });
  }

  // ---------- Contact Us phone: allow only digits, max 10 ----------
  var contactPhoneInput = document.getElementById('contact_phone');
  if (contactPhoneInput) {
    contactPhoneInput.addEventListener('input', function () {
      this.value = this.value.replace(/[^0-9]/g, '').slice(0, 10);
    });
  }

  // ---------- Name fields: allow only alphabet characters and spaces ----------
  document.querySelectorAll('.js-alpha-only').forEach(function (input) {
    input.addEventListener('input', function () {
      this.value = this.value.replace(/[^A-Za-z ]/g, '');
    });
  });

  // ---------- Flight number fields: allow only letters/digits, force uppercase ----------
  document.querySelectorAll('.js-flight-number').forEach(function (input) {
    input.addEventListener('input', function () {
      this.value = this.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 6);
    });
  });

  // ---------- Cancel booking confirmation ----------
  document.querySelectorAll('.confirm-cancel').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!confirm('Are you sure you want to cancel this booking?')) {
        e.preventDefault();
      }
    });
  });

  // ---------- Generic delete confirmation (admin panel) ----------
  document.querySelectorAll('.confirm-delete').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!confirm('Are you sure you want to delete this record? This action cannot be undone.')) {
        e.preventDefault();
      }
    });
  });

  // ---------- Close the mobile user-dashboard sidebar when a link is clicked ----------
  document.querySelectorAll('.user-nav a').forEach(function (link) {
    link.addEventListener('click', function () {
      var sidebar = document.querySelector('.user-sidebar');
      if (sidebar) sidebar.classList.remove('show');
    });
  });

  // ---------- Star rating widget: hover/label handled by CSS, this just
  //            keeps the numeric value in sync for screen readers ----------
  document.querySelectorAll('.star-rating input').forEach(function (input) {
    input.addEventListener('change', function () {
      var wrap = input.closest('.star-rating');
      if (wrap) wrap.setAttribute('data-selected', input.value);
    });
  });
});

/* ---------------- Seat Selection Helper ----------------
   Used on user/seat-selection.php.
   maxSeats = number of passengers, so the user cannot select
   more seats than the number of passengers entered.
------------------------------------------------------------ */
function toggleSeat(el, maxSeats) {
  if (el.classList.contains('booked')) {
    return; // cannot select an already booked seat
  }

  var selectedCount = document.querySelectorAll('.seat-box.selected').length;

  if (el.classList.contains('selected')) {
    el.classList.remove('selected');
  } else {
    if (selectedCount >= maxSeats) {
      alert('You can select only ' + maxSeats + ' seat(s) for the passengers entered.');
      return;
    }
    el.classList.add('selected');
  }

  updateSelectedSeatsList();
}

function updateSelectedSeatsList() {
  var selected = document.querySelectorAll('.seat-box.selected');
  var seatNumbers = [];
  selected.forEach(function (s) { seatNumbers.push(s.getAttribute('data-seat')); });

  var hiddenInput = document.getElementById('selected_seats');
  if (hiddenInput) {
    hiddenInput.value = seatNumbers.join(',');
  }

  var display = document.getElementById('selected_seats_display');
  if (display) {
    display.textContent = seatNumbers.length ? seatNumbers.join(', ') : 'No seats selected yet';
  }
}
