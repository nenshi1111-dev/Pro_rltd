<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'My Feedback';

$userId = $_SESSION['user_id'];

// ---------------- Handle the user sending a new reply on their own feedback thread ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_feedback_id'])) {
    $feedbackId = (int) $_POST['reply_feedback_id'];
    $replyMessage = clean(isset($_POST['reply_message']) ? $_POST['reply_message'] : '');

    // Make sure this feedback thread actually belongs to the logged-in user
    $chk = mysqli_prepare($conn, "SELECT feedback_id FROM feedback WHERE feedback_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($chk, 'ii', $feedbackId, $userId);
    mysqli_stmt_execute($chk);
    $owns = mysqli_num_rows(mysqli_stmt_get_result($chk)) > 0;

    if (!$owns) {
        setAlert('Feedback thread not found.', 'danger');
    } elseif ($replyMessage === '') {
        setAlert('Reply message cannot be empty.', 'danger');
    } else {
        if (insertFeedbackReply($conn, $feedbackId, 'user', $replyMessage)) {
            setAlert('Your reply has been sent.', 'success');
        } else {
            setAlert('Something went wrong. Please try again.', 'danger');
        }
    }
    redirect(BASE_URL . 'user/feedback-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM feedback WHERE user_id = ? ORDER BY created_at DESC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$myFeedback = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
      <div class="section-title text-start mb-0"><h2 class="mb-0">My Feedback</h2></div>
      <a href="<?php echo BASE_URL; ?>user/give-feedback.php" class="btn btn-primary-custom"><i class="fa-solid fa-comment-dots"></i> Give New Feedback</a>
    </div>
    <?php showAlert(); ?>

    <?php if (empty($myFeedback)): ?>
      <div class="dash-card text-center py-5">
        <i class="fa-solid fa-comment-dots fs-1 text-muted mb-3 d-block"></i>
        <p class="text-muted mb-3">You have not submitted any feedback yet.</p>
        <a href="<?php echo BASE_URL; ?>user/give-feedback.php" class="btn btn-primary-custom">Share Your Feedback</a>
      </div>
    <?php endif; ?>

    <?php foreach ($myFeedback as $fb): ?>
      <?php $replies = getFeedbackReplies($conn, $fb['feedback_id']); ?>
      <div class="feedback-card">
        <div class="d-flex justify-content-between flex-wrap gap-2">
          <div>
            <small class="text-muted"><i class="fa-solid fa-clock"></i> Submitted on <?php echo date('d M Y, h:i A', strtotime($fb['created_at'])); ?></small>
          </div>
          <div class="text-end">
            <?php if ($fb['rating']): ?>
              <div class="feedback-stars-display">
                <?php for ($i = 1; $i <= 5; $i++) echo $i <= $fb['rating'] ? '★' : '☆'; ?>
              </div>
            <?php endif; ?>
            <span class="badge bg-<?php echo $fb['status'] == 'Replied' ? 'success' : 'warning'; ?>">
              <?php echo clean($fb['status']); ?>
            </span>
          </div>
        </div>

        <!-- Conversation-style layout: original message, then every reply in order -->
        <?php if (trim($fb['message']) !== ''): ?>
          <div class="feedback-msg-bubble mine mt-3">
            <div class="label"><i class="fa-solid fa-user"></i> You</div>
            <p class="mb-0"><?php echo nl2br(clean($fb['message'])); ?></p>
          </div>
        <?php endif; ?>

        <?php if (empty($replies)): ?>
          <div class="feedback-msg-bubble waiting">
            <i class="fa-solid fa-hourglass-half"></i> Waiting for admin's reply...
          </div>
        <?php else: ?>
          <?php foreach ($replies as $r): ?>
            <?php $isMine = ($r['sender'] === 'user'); ?>
            <div class="feedback-msg-bubble <?php echo $isMine ? 'mine' : 'theirs'; ?> mt-3">
              <div class="label">
                <i class="fa-solid <?php echo $isMine ? 'fa-user' : 'fa-headset'; ?>"></i>
                <?php echo $isMine ? 'You' : 'Admin Reply'; ?> — <?php echo date('d M Y, h:i A', strtotime($r['created_at'])); ?>
              </div>
              <p class="mb-0"><?php echo nl2br(clean($r['message'])); ?></p>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

        <!-- No one-reply limit: the user can keep replying at any time (Section 13) -->
        <form method="POST" action="feedback-history.php" class="mt-3">
          <input type="hidden" name="reply_feedback_id" value="<?php echo (int) $fb['feedback_id']; ?>">
          <div class="mb-2">
            <label class="small fw-semibold">Add a reply</label>
            <textarea name="reply_message" class="form-control" rows="2" placeholder="Type your message..." required></textarea>
          </div>
          <button type="submit" class="btn btn-primary-custom btn-sm"><i class="fa-solid fa-paper-plane"></i> Send Reply</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
