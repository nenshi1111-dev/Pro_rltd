<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Give Feedback';

$errors = [];
$oldMessage = '';
$oldRating = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim(isset($_POST['message']) ? $_POST['message'] : '');
    $rating = (int) (isset($_POST['rating']) ? $_POST['rating'] : 0);
    $oldMessage = $message;
    $oldRating = $rating;

    // ---------------- Validation ----------------
    // Message is optional (Section 5) - feedback can be submitted with just a star rating.
    if (mb_strlen($message) > 1000) {
        $errors[] = 'Your feedback message is too long (maximum 1000 characters).';
    }

    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Please select a star rating between 1 and 5.';
    }

    if (empty($errors)) {
        $message = clean($message);
        $userId = (int) $_SESSION['user_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO feedback (user_id, message, rating) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'isi', $userId, $message, $rating);

        if (mysqli_stmt_execute($stmt)) {
            // Stay inside the User Dashboard instead of redirecting to the
            // public homepage/thank-you page (Section 6).
            setAlert('Thank you for your valuable feedback!', 'success');
            redirect(BASE_URL . 'user/feedback-history.php');
        } else {
            $errors[] = 'Something went wrong while submitting your feedback. Please try again.';
        }
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:750px;">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>

    <div class="dash-card">
      <h4 class="mb-1"><i class="fa-solid fa-comment-dots text-primary"></i> Give Feedback</h4>
      <p class="text-muted">Your experience helps us improve Sky Book for every traveller</p>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0">
            <?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="give-feedback.php">
        <div class="mb-4 text-center">
          <label class="d-block mb-2 fw-semibold">How was your experience?</label>
          <div class="star-rating">
            <input type="radio" name="rating" id="star5" value="5" <?php echo $oldRating==5?'checked':''; ?>><label for="star5"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star4" value="4" <?php echo $oldRating==4?'checked':''; ?>><label for="star4"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star3" value="3" <?php echo $oldRating==3?'checked':''; ?>><label for="star3"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star2" value="2" <?php echo $oldRating==2?'checked':''; ?>><label for="star2"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star1" value="1" <?php echo $oldRating==1?'checked':''; ?>><label for="star1"><i class="fa-solid fa-star"></i></label>
          </div>
        </div>

        <div class="mb-3">
          <label>Your Feedback <span class="text-muted small">(optional)</span></label>
          <textarea name="message" rows="5" class="form-control" placeholder="Tell us what you liked, or what we can improve... (optional)"><?php echo clean($oldMessage); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary-custom w-100 mt-2"><i class="fa-solid fa-paper-plane"></i> Submit Feedback</button>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
