<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

$bookingId = (int) (isset($_GET['booking_id']) ? $_GET['booking_id'] : 0);
$userId = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.airline_name, f.source, f.destination, f.departure_date, f.departure_time, f.arrival_time
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking || $booking['booking_status'] !== 'Confirmed') {
    setAlert('Ticket not available for download.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE booking_id = ? AND status = 'Active' ORDER BY passenger_id");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$passengers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$fareEach = passengerFareShare($booking);

// ---------------- Build one PDF page per passenger (Section 10: PDF only) ----------------
$pages = array();
foreach ($passengers as $p) {
    $lines = array();
    $y = 780;

    $lines[] = pdfTextLine('F2', 20, 50, $y, SITE_NAME); $y -= 22;
    $lines[] = pdfTextLine('F1', 11, 50, $y, 'BOARDING TICKET'); $y -= 36;

    $rows = array(
        'Booking ID'    => $booking['booking_reference'],
        'Ticket Number' => generateTicketNumber($p['passenger_id']),
        'Passenger'     => $p['full_name'],
        'Flight'        => $booking['flight_number'],
        'From'          => $booking['source'],
        'To'            => $booking['destination'],
        'Date'          => formatDate($booking['departure_date']),
        'Departure'     => formatTime($booking['departure_time']),
        'Arrival'       => formatTime($booking['arrival_time']),
        'Class'         => $p['travel_class'],
        'Seat'          => $p['seat_number'],
        'Fare'          => formatMoneyPdf($fareEach),
        'Payment'       => 'PAID',
    );

    foreach ($rows as $label => $value) {
        $lines[] = pdfTextLine('F1', 12, 50, $y, $label . ':');
        $lines[] = pdfTextLine('F2', 12, 200, $y, $value);
        $y -= 24;
    }

    $y -= 16;
    $lines[] = pdfTextLine('F2', 14, 50, $y, 'BOOKING CONFIRMED');

    $pages[] = $lines;
}

$pdfBytes = buildSimplePdf($pages);
$filename = 'Ticket-' . preg_replace('/[^A-Za-z0-9_-]/', '', $booking['booking_reference']) . '.pdf';

// Force the browser's Save/Download dialog so the user can choose where to save it.
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($pdfBytes));
echo $pdfBytes;
exit();
