<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Payment';

if (!isset($_SESSION['booking']) || empty($_SESSION['booking']['seats'])) {
    setAlert('Please complete seat selection first.', 'warning');
    redirect(BASE_URL . 'user/seat-selection.php');
}
$userId = $_SESSION['user_id'];
$b = $_SESSION['booking'];
$travelClass = $b['travel_class'];
$passengerCount = (int) $b['passenger_count'];

$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $b['flight_id']);
mysqli_stmt_execute($stmt);
$flight = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// ---------------- Fare Calculation ----------------
$pricePerSeat = ($travelClass === 'Business') ? $flight['business_price'] : $flight['economy_price'];
$baseFare = $pricePerSeat * $passengerCount;
$taxPercent = (float) getSetting($conn, 'tax_percentage', '5');
$taxAmount = round($baseFare * ($taxPercent / 100), 2);
$totalAmount = $baseFare + $taxAmount;

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardHolder = clean(isset($_POST['card_holder']) ? $_POST['card_holder'] : '');
    $cardNumber = preg_replace('/\s+/', '', isset($_POST['card_number']) ? $_POST['card_number'] : ''); // remove any spaces first
    $expMonth = clean(isset($_POST['exp_month']) ? $_POST['exp_month'] : '');
    $expYear = clean(isset($_POST['exp_year']) ? $_POST['exp_year'] : '');
    $cvv = clean(isset($_POST['cvv']) ? $_POST['cvv'] : '');

    if ($cardHolder === '') {
        $errors[] = 'Please enter the card holder name.';
    } elseif (!isAlphaName($cardHolder)) {
        $errors[] = 'Card holder name can only contain alphabet characters and spaces.';
    }
    // ---------------- Section 14: Credit card must be exactly 16 digits, no spaces ----------------
    if (!preg_match('/^[0-9]{16}$/', $cardNumber)) {
        $errors[] = 'Credit card number must contain exactly 16 digits without spaces.';
    }
    if (!preg_match('/^[0-9]{3}$/', $cvv)) {
        $errors[] = 'CVV must be exactly 3 digits.';
    }
    if ($expMonth === '' || $expYear === '') {
        $errors[] = 'Please select the card expiry month and year.';
    } elseif (strtotime("$expYear-$expMonth-01") < strtotime(date('Y-m-01'))) {
        $errors[] = 'The card has expired. Please use a valid card.';
    }

    if (empty($errors)) {
        // Simple demo rule: a test card ending 0000 simulates a failed payment
        $paymentSuccess = (substr($cardNumber, -4) !== '0000');

        mysqli_begin_transaction($conn);
        try {
            // ---------------- Re-check seat availability again (Section 37) ----------------
            $availableSeats = ($travelClass === 'Business') ? $flight['business_available_seats'] : $flight['economy_available_seats'];
            if ($availableSeats < $passengerCount) {
                throw new Exception('No seats available in this class. Please search again.');
            }
            foreach ($b['seats'] as $seat) {
                $chk = mysqli_prepare($conn, "SELECT seat_id FROM seats WHERE flight_id=? AND travel_date=? AND seat_number=? AND status='Booked'");
                mysqli_stmt_bind_param($chk, 'iss', $flight['flight_id'], $flight['departure_date'], $seat);
                mysqli_stmt_execute($chk);
                if (mysqli_stmt_get_result($chk)->num_rows > 0) {
                    throw new Exception("Sorry, seat $seat has just been booked. Please select another seat.");
                }
            }

            // ---------------- Create booking ----------------
            $bookingRef = generateBookingReference($conn);
            $status = $paymentSuccess ? 'Confirmed' : 'Cancelled';
            $payStatus = $paymentSuccess ? 'Success' : 'Failed';

            $stmt = mysqli_prepare($conn, "INSERT INTO bookings (booking_reference, user_id, flight_id, travel_class, passenger_count, total_amount, booking_status, payment_status) VALUES (?,?,?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, 'siisidss', $bookingRef, $userId, $flight['flight_id'], $travelClass, $passengerCount, $totalAmount, $status, $payStatus);
            mysqli_stmt_execute($stmt);
            $bookingId = mysqli_insert_id($conn);

            // ---------------- Create passengers + seats (always, so seats stay reserved for a moment even if payment fails) ----------------
            foreach ($b['passengers'] as $p) {
                $stmt = mysqli_prepare($conn, "INSERT INTO passengers (booking_id, full_name, gender, dob, id_number, seat_number, travel_class) VALUES (?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt, 'issssss', $bookingId, $p['full_name'], $p['gender'], $p['dob'], $p['id_number'], $p['seat_number'], $travelClass);
                mysqli_stmt_execute($stmt);

                if ($paymentSuccess) {
                    $stmt = mysqli_prepare($conn, "INSERT INTO seats (flight_id, travel_date, seat_number, travel_class, status, booking_id) VALUES (?,?,?,?, 'Booked', ?)");
                    mysqli_stmt_bind_param($stmt, 'isssi', $flight['flight_id'], $flight['departure_date'], $p['seat_number'], $travelClass, $bookingId);
                    mysqli_stmt_execute($stmt);
                }
            }

            // ---------------- Create payment record (masked card only) ----------------
            $maskedCard = str_repeat('*', 12) . substr($cardNumber, -4);
            $transactionId = generateTransactionId();
            $stmt = mysqli_prepare($conn, "INSERT INTO payments (booking_id, transaction_id, masked_card_number, amount, payment_status) VALUES (?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, 'issds', $bookingId, $transactionId, $maskedCard, $totalAmount, $payStatus);
            mysqli_stmt_execute($stmt);

            if ($paymentSuccess) {
                // ---------------- Decrease available seats for the correct class only (Section 9) ----------------
                if ($travelClass === 'Business') {
                    mysqli_query($conn, "UPDATE flights SET business_available_seats = business_available_seats - $passengerCount WHERE flight_id = " . (int)$flight['flight_id']);
                } else {
                    mysqli_query($conn, "UPDATE flights SET economy_available_seats = economy_available_seats - $passengerCount WHERE flight_id = " . (int)$flight['flight_id']);
                }
                mysqli_commit($conn);
                unset($_SESSION['booking']);
                setAlert('Payment Successful. Booking Confirmed!', 'success');
                redirect(BASE_URL . 'user/ticket.php?booking_id=' . $bookingId);
            } else {
                mysqli_commit($conn); // keep the Cancelled/Failed record for the student demo, but seats were never marked Booked
                $errors[] = 'Payment Failed. Please try again.';
            }
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $errors[] = $e->getMessage();
        }
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:850px;">
    <a href="seat-selection.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back</a>

    <div class="row g-4">
      <div class="col-md-5">
        <div class="dash-card">
          <h5 class="mb-3"><i class="fa-solid fa-receipt"></i> Booking Summary</h5>
          <div class="ticket-row"><span class="label">Flight</span><span class="value"><?php echo clean($flight['flight_number']); ?></span></div>
          <div class="ticket-row"><span class="label">Route</span><span class="value"><?php echo clean($flight['source']); ?> → <?php echo clean($flight['destination']); ?></span></div>
          <div class="ticket-row"><span class="label">Date</span><span class="value"><?php echo formatDate($flight['departure_date']); ?></span></div>
          <div class="ticket-row"><span class="label">Class</span><span class="value"><?php echo clean($travelClass); ?></span></div>
          <div class="ticket-row"><span class="label">Passengers</span><span class="value"><?php echo $passengerCount; ?></span></div>
          <div class="ticket-row"><span class="label">Seats</span><span class="value"><?php echo clean(implode(', ', $b['seats'])); ?></span></div>
          <div class="ticket-row"><span class="label">Base Fare</span><span class="value"><?php echo formatMoney($baseFare); ?></span></div>
          <div class="ticket-row"><span class="label">Taxes (<?php echo $taxPercent; ?>%)</span><span class="value"><?php echo formatMoney($taxAmount); ?></span></div>
          <div class="ticket-row" style="border-bottom:none;"><span class="label fw-bold">Total Amount</span><span class="value fs-5"><?php echo formatMoney($totalAmount); ?></span></div>
        </div>
      </div>

      <div class="col-md-7">
        <div class="dash-card">
          <h5 class="mb-3"><i class="fa-solid fa-credit-card"></i> Payment Details</h5>

          <?php if (!empty($errors)): ?>
            <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
          <?php endif; ?>

          <form method="POST" action="payment.php">
            <div class="mb-3">
              <label>Card Holder Name</label>
              <input type="text" name="card_holder" class="form-control js-alpha-only" pattern="[A-Za-z ]+" title="Alphabet characters only" minlength="3" required>
            </div>
            <div class="mb-3">
              <label>Credit Card Number (16 digits, no spaces)</label>
              <input type="text" name="card_number" id="card_number" class="form-control" placeholder="1234567890123456" maxlength="16" pattern="[0-9]{16}" inputmode="numeric" title="Enter a valid 16 digit card number" required>
            </div>
            <div class="row g-3 mb-3">
              <div class="col-4">
                <label>Expiry Month</label>
                <select name="exp_month" class="form-select" required>
                  <option value="">MM</option>
                  <?php for ($m = 1; $m <= 12; $m++): $mm = str_pad($m,2,'0',STR_PAD_LEFT); ?>
                    <option value="<?php echo $mm; ?>"><?php echo $mm; ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="col-4">
                <label>Expiry Year</label>
                <select name="exp_year" class="form-select" required>
                  <option value="">YYYY</option>
                  <?php for ($y = (int)date('Y'); $y <= (int)date('Y')+8; $y++): ?>
                    <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="col-4">
                <label>CVV</label>
                <input type="password" name="cvv" id="cvv" class="form-control" maxlength="3" pattern="[0-9]{3}" inputmode="numeric" title="Enter a valid 3 digit CVV" required>
              </div>
            </div>
            <p class="small text-muted">For this student project, only a masked card number is stored. No real payment gateway is used. (Tip: a card ending in 0000 simulates a failed payment.)</p>
            <button type="submit" class="btn btn-primary-custom w-100">Pay <?php echo formatMoney($totalAmount); ?> <i class="fa-solid fa-lock"></i></button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
