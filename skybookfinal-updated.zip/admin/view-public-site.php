<?php
/* ============================================================
   Admin - "View Public Site" security gate
   ------------------------------------------------------------
   Per security requirement: when an Admin clicks "View Public
   Website", the Admin session must end immediately. To come
   back to the Admin Dashboard afterwards, the Admin must log
   in again via admin/login.php.
   ============================================================ */
require_once '../includes/config.php';
require_once '../includes/functions.php';

// End the Admin session completely (same approach as admin/logout.php)
session_unset();
session_destroy();
session_start();

redirect(BASE_URL . 'index.php');
