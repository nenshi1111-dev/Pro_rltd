<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'View User';

$userId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$u = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$u) {
    setAlert('User not found.', 'danger');
    redirect(BASE_URL . 'admin/users/users.php');
}

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.source, f.destination FROM bookings b JOIN flights f ON b.flight_id=f.flight_id WHERE b.user_id=? ORDER BY b.booking_date DESC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$bookings = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <h5><i class="fa-solid fa-user"></i> <?php echo clean($u['full_name']); ?></h5>
  <div class="row">
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Username</span><span class="value"><?php echo clean($u['username']); ?></span></div>
      <div class="ticket-row"><span class="label">Email</span><span class="value"><?php echo clean($u['email']); ?></span></div>
      <div class="ticket-row"><span class="label">Mobile</span><span class="value"><?php echo clean($u['mobile']); ?></span></div>
    </div>
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Gender</span><span class="value"><?php echo clean($u['gender']); ?></span></div>
      <div class="ticket-row"><span class="label">DOB</span><span class="value"><?php echo formatDate($u['dob']); ?></span></div>
      <div class="ticket-row"><span class="label">Address</span><span class="value"><?php echo clean($u['address']); ?></span></div>
    </div>
  </div>
  <a href="users.php" class="btn btn-outline-secondary mt-2">Back</a>
</div>
<div class="admin-card">
  <h5>Booking History</h5>
  <div class="table-responsive">
    <table class="table table-custom">
      <thead><tr><th>Booking Ref</th><th>Flight</th><th>Route</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php if (empty($bookings)): ?><tr><td colspan="5" class="text-center text-muted py-3">No bookings yet.</td></tr><?php endif; ?>
      <?php foreach ($bookings as $b): ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['flight_number']); ?></td>
          <td><?php echo clean($b['source']); ?> → <?php echo clean($b['destination']); ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><?php echo clean($b['booking_status']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
