<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Feedback Management';

// ---------------- Handle admin reply submission ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_feedback_id'])) {
    $feedbackId = (int) $_POST['reply_feedback_id'];
    $reply = clean(isset($_POST['admin_reply']) ? $_POST['admin_reply'] : '');

    if ($reply === '') {
        setAlert('Reply message cannot be empty.', 'danger');
    } else {
        if (insertFeedbackReply($conn, $feedbackId, 'admin', $reply)) {
            setAlert('Reply sent successfully.', 'success');
        } else {
            setAlert('Something went wrong. Please try again.', 'danger');
        }
    }
    redirect(BASE_URL . 'admin/feedback/feedback.php');
}

// ---------------- Summary counts ----------------
$totalFeedback = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback"))['total'];
$pendingFeedback = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback WHERE status='Pending'"))['total'];
$repliedFeedback = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback WHERE status='Replied'"))['total'];
$avgRatingRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(rating) AS avg_rating FROM feedback WHERE rating IS NOT NULL"));
$avgRating = $avgRatingRow['avg_rating'] ? round($avgRatingRow['avg_rating'], 1) : 0;

// ---------------- Fetch all feedback with user info ----------------
$result = mysqli_query($conn, "SELECT f.*, u.full_name, u.email FROM feedback f
    JOIN users u ON f.user_id = u.user_id
    ORDER BY (f.status = 'Pending') DESC, f.created_at DESC");
$feedbackList = mysqli_fetch_all($result, MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>

<div class="row g-4 mb-4">
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-comment-dots"></i></div>
      <div><h3><?php echo $totalFeedback; ?></h3><p>Total Feedback</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div>
      <div><h3><?php echo $pendingFeedback; ?></h3><p>Pending Reply</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div>
      <div><h3><?php echo $repliedFeedback; ?></h3><p>Replied</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-star"></i></div>
      <div><h3><?php echo $avgRating; ?> / 5</h3><p>Average Rating</p></div></div>
  </div>
</div>

<div class="admin-card">
  <h5 class="mb-3"><i class="fa-solid fa-comment-dots"></i> All User Feedback</h5>

  <?php if (empty($feedbackList)): ?>
    <p class="text-center text-muted py-4">No feedback has been submitted yet.</p>
  <?php endif; ?>

  <?php foreach ($feedbackList as $fb): ?>
    <?php $replies = getFeedbackReplies($conn, $fb['feedback_id']); ?>
    <div class="feedback-card">
      <div class="d-flex justify-content-between flex-wrap gap-2">
        <div>
          <strong><?php echo clean($fb['full_name']); ?></strong>
          <span class="text-muted small">(<?php echo clean($fb['email']); ?>)</span><br>
          <small class="text-muted"><i class="fa-solid fa-clock"></i> <?php echo date('d M Y, h:i A', strtotime($fb['created_at'])); ?></small>
        </div>
        <div class="text-end">
          <?php if ($fb['rating']): ?>
            <div class="feedback-stars-display">
              <?php for ($i = 1; $i <= 5; $i++) echo $i <= $fb['rating'] ? '★' : '☆'; ?>
            </div>
          <?php endif; ?>
          <span class="badge bg-<?php echo $fb['status'] == 'Replied' ? 'success' : 'warning'; ?>">
            <?php echo clean($fb['status']); ?>
          </span>
        </div>
      </div>

      <?php if (trim($fb['message']) !== ''): ?>
        <div class="feedback-msg-bubble theirs mt-3">
          <div class="label"><i class="fa-solid fa-user"></i> <?php echo clean($fb['full_name']); ?></div>
          <p class="mb-0"><?php echo nl2br(clean($fb['message'])); ?></p>
        </div>
      <?php endif; ?>

      <?php foreach ($replies as $r): ?>
        <?php $isAdmin = ($r['sender'] === 'admin'); ?>
        <div class="feedback-msg-bubble <?php echo $isAdmin ? 'mine' : 'theirs'; ?> mt-3">
          <div class="label">
            <i class="fa-solid <?php echo $isAdmin ? 'fa-headset' : 'fa-user'; ?>"></i>
            <?php echo $isAdmin ? 'Admin Reply (You)' : clean($fb['full_name']); ?> — <?php echo date('d M Y, h:i A', strtotime($r['created_at'])); ?>
          </div>
          <p class="mb-0"><?php echo nl2br(clean($r['message'])); ?></p>
        </div>
      <?php endforeach; ?>

      <!-- No one-reply limit: admin can keep replying at any time (Section 13) -->
      <form method="POST" action="feedback.php" class="mt-3">
        <input type="hidden" name="reply_feedback_id" value="<?php echo (int) $fb['feedback_id']; ?>">
        <div class="mb-2">
          <label class="small fw-semibold">Reply to <?php echo clean($fb['full_name']); ?></label>
          <textarea name="admin_reply" class="form-control" rows="2" placeholder="Type your reply..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary-custom btn-sm"><i class="fa-solid fa-paper-plane"></i> Send Reply</button>
      </form>
    </div>
  <?php endforeach; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
