-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 16, 2026 at 04:46 PM
-- Server version: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airline_db`
--
CREATE DATABASE IF NOT EXISTS `airline_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `airline_db`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `full_name`, `password`, `created_at`) VALUES
(1, 'admin', 'System Administrator', '$2y$10$pU4UYsqD5sfWzsy4mzc68OKMTmiFePWQyTsDREy7/P3aOrRC6JWs2', '2026-08-22 15:42:24');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `booking_reference` varchar(30) NOT NULL,
  `user_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `travel_class` enum('Economy','Business') NOT NULL,
  `passenger_count` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `booking_status` enum('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
  `payment_status` enum('Pending','Success','Failed','Refunded') DEFAULT 'Pending',
  `booking_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `cancellation_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `booking_reference`, `user_id`, `flight_id`, `travel_class`, `passenger_count`, `total_amount`, `booking_status`, `payment_status`, `booking_date`, `cancellation_date`) VALUES
(1, 'AS20260810001', 1, 1, 'Economy', 2, '9450.00', 'Confirmed', 'Success', '2026-08-22 15:42:24', NULL),
(2, 'AS20260810002', 2, 5, 'Business', 1, '10710.00', 'Confirmed', 'Success', '2026-08-22 15:42:24', NULL),
(3, 'AS20260810003', 3, 12, 'Economy', 1, '4700.00', 'Completed', 'Success', '2026-08-22 15:42:24', NULL),
(4, 'AS20260822001', 5, 2, 'Economy', 3, '9450.00', 'Cancelled', 'Refunded', '2026-08-22 15:45:26', '2026-08-22 15:58:09'),
(5, 'AS20260822002', 5, 1, 'Business', 1, '9975.00', 'Confirmed', 'Success', '2026-08-22 15:46:38', NULL),
(6, 'AS20260822003', 5, 7, 'Business', 5, '68250.00', 'Confirmed', 'Success', '2026-08-22 15:50:53', NULL),
(7, 'AS20260823001', 6, 4, 'Economy', 3, '16380.00', 'Confirmed', 'Success', '2026-08-23 13:51:56', NULL),
(8, 'AS20260916001', 5, 1, 'Economy', 1, '4725.00', 'Confirmed', 'Success', '2026-09-16 22:11:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cancellations`
--

CREATE TABLE `cancellations` (
  `cancellation_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `passenger_id` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `cancelled_by` enum('User','Admin') DEFAULT 'User',
  `cancellation_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `refund_amount` decimal(10,2) DEFAULT '0.00',
  `refund_percentage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `refund_status` enum('Pending','Processing','Completed','Rejected','Not Applicable') DEFAULT 'Pending',
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cancellations`
--

INSERT INTO `cancellations` (`cancellation_id`, `booking_id`, `passenger_id`, `reason`, `cancelled_by`, `cancellation_date`, `refund_amount`, `refund_percentage`, `refund_status`, `updated_at`) VALUES
(1, 4, 7, 'Individually cancelled by user: jalpa rajput', 'User', '2026-08-22 15:57:47', '2362.50', '50.00', 'Completed', '2026-08-22 16:09:42'),
(2, 4, NULL, 'Cancelled by user from booking history.', 'User', '2026-08-22 15:58:09', '4725.00', '50.00', 'Completed', '2026-08-22 16:09:32');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `message_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`message_id`, `name`, `email`, `phone`, `subject`, `message`, `created_at`) VALUES
(1, 'Demo User', 'demo.user@example.com', '9999900000', 'General Query', 'This is a sample contact message for demo and testing purposes.', '2026-08-22 15:42:24'),
(2, 'Nutan Rajput', 'nutan@gmail.com', '09725335094', 'ticket booking', 'your flight is fastly book', '2026-08-22 15:56:07');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `rating` tinyint(4) DEFAULT NULL,
  `status` enum('Pending','Replied') DEFAULT 'Pending',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `user_id`, `message`, `rating`, `status`, `created_at`) VALUES
(1, 1, 'Booking my tickets on Sky Book was very quick and the seat selection screen is really easy to use. Loved the experience!', 5, 'Replied', '2026-08-22 15:42:24'),
(2, 2, 'It would be great if there were more payment options available at checkout.', 4, 'Replied', '2026-08-22 15:42:24'),
(3, 5, 'your flight is very best and comfertable', 3, 'Replied', '2026-08-22 15:51:28'),
(4, 5, 'nice your staff behavior', 1, 'Replied', '2026-08-22 15:52:04'),
(5, 5, '', 1, 'Pending', '2026-09-16 22:12:25');

-- --------------------------------------------------------

--
-- Table structure for table `feedback_replies`
--

CREATE TABLE `feedback_replies` (
  `reply_id` int(11) NOT NULL,
  `feedback_id` int(11) NOT NULL,
  `sender` enum('user','admin') NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback_replies`
--

INSERT INTO `feedback_replies` (`reply_id`, `feedback_id`, `sender`, `message`, `created_at`) VALUES
(1, 1, 'admin', 'Thank you so much for your kind words, Rahul! We are glad you enjoyed booking with Sky Book.', '2026-08-22 15:42:24'),
(2, 2, 'admin', 'ohk', '2026-08-22 15:53:18'),
(3, 3, 'admin', 'Thank you so much for your kind words, nutan! We are glad you enjoyed booking with Sky Book.', '2026-08-22 15:53:42'),
(4, 4, 'admin', 'thank you so much', '2026-08-22 15:52:43'),
(5, 4, 'admin', 'fgg', '2026-09-16 22:07:54'),
(6, 5, 'user', 'thank you', '2026-09-16 22:12:42');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `flight_id` int(11) NOT NULL,
  `flight_number` varchar(20) NOT NULL,
  `airline_name` varchar(100) NOT NULL,
  `source` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `departure_date` date NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `duration` varchar(20) NOT NULL,
  `economy_total_seats` int(11) NOT NULL DEFAULT '150',
  `economy_available_seats` int(11) NOT NULL DEFAULT '150',
  `economy_price` decimal(10,2) NOT NULL,
  `business_total_seats` int(11) NOT NULL DEFAULT '30',
  `business_available_seats` int(11) NOT NULL DEFAULT '30',
  `business_price` decimal(10,2) NOT NULL,
  `status` enum('Scheduled','Delayed','Cancelled','Completed') DEFAULT 'Scheduled',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flight_id`, `flight_number`, `airline_name`, `source`, `destination`, `departure_date`, `departure_time`, `arrival_time`, `duration`, `economy_total_seats`, `economy_available_seats`, `economy_price`, `business_total_seats`, `business_available_seats`, `business_price`, `status`, `created_at`) VALUES
(1, 'AI101', 'Sky Book Airlines', 'Rajkot', 'Mumbai', '2026-10-27', '10:30:00', '12:00:00', '1h 30m', 150, 149, '4500.00', 30, 29, '9500.00', 'Scheduled', '2026-08-22 15:42:24'),
(2, 'AI102', 'Sky Book Airlines', 'Mumbai', 'Rajkot', '2026-11-27', '14:00:00', '15:30:00', '1h 30m', 150, 151, '4500.00', 30, 30, '9500.00', 'Scheduled', '2026-08-22 15:42:24'),
(3, 'AI205', 'Sky Book Airlines', 'Ahmedabad', 'Delhi', '2026-10-25', '07:15:00', '09:15:00', '2h 00m', 150, 150, '5200.00', 30, 30, '11000.00', 'Scheduled', '2026-08-22 15:42:24'),
(4, 'AI206', 'Sky Book Airlines', 'Delhi', 'Ahmedabad', '2026-10-25', '18:00:00', '20:00:00', '2h 00m', 150, 147, '5200.00', 30, 30, '11000.00', 'Scheduled', '2026-08-22 15:42:24'),
(5, 'AI310', 'Sky Book Airlines', 'Mumbai', 'Bengaluru', '2026-10-29', '06:45:00', '08:15:00', '1h 30m', 150, 150, '4800.00', 30, 30, '10200.00', 'Scheduled', '2026-08-22 15:42:24'),
(6, 'AI311', 'Sky Book Airlines', 'Bengaluru', 'Mumbai', '2026-09-29', '20:30:00', '22:00:00', '1h 30m', 150, 150, '4800.00', 30, 30, '10200.00', 'Scheduled', '2026-08-22 15:42:24'),
(7, 'AI415', 'Sky Book Airlines', 'Delhi', 'Goa', '2026-10-01', '09:00:00', '11:30:00', '2h 30m', 150, 150, '6200.00', 30, 25, '13000.00', 'Scheduled', '2026-08-22 15:42:24'),
(8, 'AI416', 'Sky Book Airlines', 'Goa', 'Delhi', '2026-10-01', '16:00:00', '18:30:00', '2h 30m', 150, 150, '6200.00', 30, 30, '13000.00', 'Scheduled', '2026-08-22 15:42:24'),
(9, 'AI520', 'Sky Book Airlines', 'Chennai', 'Kolkata', '2026-10-26', '11:00:00', '13:20:00', '2h 20m', 150, 150, '5600.00', 30, 30, '11800.00', 'Scheduled', '2026-08-22 15:42:24'),
(10, 'AI521', 'Sky Book Airlines', 'Kolkata', 'Chennai', '2026-11-26', '15:30:00', '17:50:00', '2h 20m', 150, 150, '5600.00', 30, 30, '11800.00', 'Scheduled', '2026-08-22 15:42:24'),
(11, 'AI102', 'Sky Book Airlines', 'Rajkot', 'Mumbai', '2026-10-23', '09:00:00', '10:30:00', '1h 30m', 150, 148, '4300.00', 30, 29, '9200.00', 'Scheduled', '2026-08-22 15:42:24'),
(12, 'AI604', 'Sky Book Airlines', 'Jaipur', 'Mumbai', '2026-10-20', '08:00:00', '09:45:00', '1h 45m', 150, 150, '4700.00', 30, 30, '9900.00', 'Completed', '2026-08-22 15:42:24');

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `passenger_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` date NOT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `seat_number` varchar(10) NOT NULL,
  `travel_class` enum('Economy','Business') NOT NULL,
  `status` enum('Active','Cancelled') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`passenger_id`, `booking_id`, `full_name`, `gender`, `dob`, `id_number`, `seat_number`, `travel_class`, `status`) VALUES
(1, 1, 'Rahul Patel', 'Male', '1998-05-14', 'PAS1234567', '12A', 'Economy', 'Active'),
(2, 1, 'Kavita Patel', 'Female', '2001-03-09', 'PAS7654321', '12B', 'Economy', 'Active'),
(3, 2, 'Priya Shah', 'Female', '2000-08-22', 'PAS1122334', '2A', 'Business', 'Active'),
(4, 3, 'Aman Verma', 'Male', '1995-11-02', 'PAS9988776', '15C', 'Economy', 'Active'),
(5, 4, 'ruchi rajput', 'Female', '2006-12-20', 'PAS1234567', '1A', 'Economy', 'Cancelled'),
(6, 4, 'undhad krisha', 'Female', '2007-08-17', 'PAS1234568', '1B', 'Economy', 'Cancelled'),
(7, 4, 'jalpa rajput', 'Female', '2008-03-12', 'PAS1234569', '1C', 'Economy', 'Cancelled'),
(8, 5, 'ruchi gujrati', 'Female', '2005-12-27', 'PAS1234567', '1A', 'Business', 'Active'),
(9, 6, 'ruchi sarvaiya', 'Female', '2006-12-20', 'PAS1234567', '1A', 'Business', 'Active'),
(10, 6, 'undhad krisha', 'Female', '2007-08-17', 'PAS1234568', '2D', 'Business', 'Active'),
(11, 6, 'jalpa rajput', 'Female', '2008-03-12', 'PAS1234569', '4C', 'Business', 'Active'),
(12, 6, 'joriya jya', 'Female', '2007-09-20', 'PAS1234569', '6B', 'Business', 'Active'),
(13, 6, 'hiren rajput', 'Male', '2008-03-18', 'PAS1234510', '6C', 'Business', 'Active'),
(14, 7, 'ruchi rajput', 'Female', '2006-12-20', 'PAS1234567', '1A', 'Economy', 'Active'),
(15, 7, 'undhad krisha', 'Female', '2007-08-17', 'PAS1234568', '1B', 'Economy', 'Active'),
(16, 7, 'jalpa rajput', 'Female', '2008-03-12', 'PAS1234569', '1C', 'Economy', 'Active'),
(17, 8, 'parmar pooja', 'Female', '2008-03-12', 'PAS1234567', '1A', 'Economy', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `booking_id` int(11) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `masked_card_number` varchar(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Pending','Success','Failed','Refunded') DEFAULT 'Pending',
  `payment_date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `booking_id`, `transaction_id`, `masked_card_number`, `amount`, `payment_status`, `payment_date`) VALUES
(1, 1, 'TXN100000001', '************3456', '9450.00', 'Success', '2026-08-22 15:42:24'),
(2, 2, 'TXN100000002', '************7890', '10710.00', 'Success', '2026-08-22 15:42:24'),
(3, 3, 'TXN100000003', '************1122', '4700.00', 'Success', '2026-08-22 15:42:24'),
(4, 4, 'TXN1787393726655', '************1234', '14175.00', 'Refunded', '2026-08-22 15:45:26'),
(5, 5, 'TXN1787393798393', '************1234', '9975.00', 'Success', '2026-08-22 15:46:38'),
(6, 6, 'TXN1787394053296', '************1234', '68250.00', 'Success', '2026-08-22 15:50:53'),
(7, 7, 'TXN1787473316210', '************1234', '16380.00', 'Success', '2026-08-23 13:51:56'),
(8, 8, 'TXN1789576910100', '************1234', '4725.00', 'Success', '2026-09-16 22:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `seat_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `travel_date` date NOT NULL,
  `seat_number` varchar(10) NOT NULL,
  `travel_class` enum('Economy','Business') NOT NULL,
  `status` enum('Available','Booked') DEFAULT 'Available',
  `booking_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`seat_id`, `flight_id`, `travel_date`, `seat_number`, `travel_class`, `status`, `booking_id`) VALUES
(1, 1, '2026-08-27', '12A', 'Economy', 'Booked', 1),
(2, 1, '2026-08-27', '12B', 'Economy', 'Booked', 1),
(3, 5, '2026-08-29', '2A', 'Business', 'Booked', 2),
(4, 12, '2026-08-20', '15C', 'Economy', 'Booked', 3),
(8, 1, '2026-08-27', '1A', 'Business', 'Booked', 5),
(9, 7, '2026-09-01', '1A', 'Business', 'Booked', 6),
(10, 7, '2026-09-01', '2D', 'Business', 'Booked', 6),
(11, 7, '2026-09-01', '4C', 'Business', 'Booked', 6),
(12, 7, '2026-09-01', '6B', 'Business', 'Booked', 6),
(13, 7, '2026-09-01', '6C', 'Business', 'Booked', 6),
(14, 4, '2026-08-25', '1A', 'Economy', 'Booked', 7),
(15, 4, '2026-08-25', '1B', 'Economy', 'Booked', 7),
(16, 4, '2026-08-25', '1C', 'Economy', 'Booked', 7),
(17, 1, '2026-10-27', '1A', 'Economy', 'Booked', 8);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `setting_key`, `setting_value`) VALUES
(1, 'site_name', 'Sky Book'),
(2, 'one_booking_per_day', '0'),
(3, 'tax_percentage', '5'),
(4, 'support_phone', '+91 98765 43210'),
(5, 'support_email', 'support@skybook.com'),
(6, 'support_address', 'Sky Book HQ, Rajkot, Gujarat, India');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `dob` date NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `gender`, `dob`, `mobile`, `email`, `address`, `username`, `password`, `status`, `created_at`) VALUES
(1, 'Rahul Patel', 'Male', '1998-05-14', '9876543210', 'rahul.patel@example.com', 'Rajkot, Gujarat', 'rahulpatel', '$2y$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active', '2026-08-22 15:42:24'),
(2, 'Priya Shah', 'Female', '2000-08-22', '9876501234', 'priya.shah@example.com', 'Ahmedabad, Gujarat', 'priyashah', '$2y$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active', '2026-08-22 15:42:24'),
(3, 'Aman Verma', 'Male', '1995-11-02', '9998877665', 'aman.verma@example.com', 'Mumbai, Maharashtra', 'amanverma', '$2y$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active', '2026-08-22 15:42:24'),
(4, 'Sneha Joshi', 'Female', '1999-02-18', '9123456780', 'sneha.joshi@example.com', 'Pune, Maharashtra', 'snehajoshi', '$2y$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active', '2026-08-22 15:42:24'),
(5, 'Nutan Rajput', 'Female', '2006-03-20', '9725335094', 'nutan@gmail.com', 'AT LUNAGARA', 'nutanrajput', '$2y$10$knJ21SfL3faKzpUpQPoJju15Bb7FATmV1N6iJLtmAO0.2Ycnwzw3W', 'Active', '2026-08-22 15:43:50'),
(6, 'undhad pooja', 'Female', '2007-08-17', '9725335094', 'pooja@gmail.com', 'station vavdi', 'pujapatel', '$2y$10$ngrmBVIVhuq3aV17z7hLN.35kw9ojFd73j5YxnnqGPReW6b5m72AO', 'Active', '2026-08-23 13:50:18'),
(7, 'undhad kreeya', 'Female', '2008-03-20', '9725335094', 'nutanrajput@gmail.com', 'station vavdi', 'nutan123', '$2y$10$9zjxUZdoyU0tRlSmbpI4HOfsJUyBbV1IF6btQl.SVdk5vZpjtYQvG', 'Active', '2026-09-16 22:15:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `booking_reference` (`booking_reference`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_flight` (`flight_id`);

--
-- Indexes for table `cancellations`
--
ALTER TABLE `cancellations`
  ADD PRIMARY KEY (`cancellation_id`),
  ADD KEY `booking_id` (`booking_id`),
  ADD KEY `passenger_id` (`passenger_id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `feedback_replies`
--
ALTER TABLE `feedback_replies`
  ADD PRIMARY KEY (`reply_id`),
  ADD KEY `idx_feedback` (`feedback_id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`flight_id`),
  ADD KEY `idx_route` (`source`,`destination`),
  ADD KEY `idx_date` (`departure_date`);

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`passenger_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`seat_id`),
  ADD UNIQUE KEY `uniq_seat` (`flight_id`,`travel_date`,`seat_number`),
  ADD KEY `booking_id` (`booking_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cancellations`
--
ALTER TABLE `cancellations`
  MODIFY `cancellation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `feedback_replies`
--
ALTER TABLE `feedback_replies`
  MODIFY `reply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `flight_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `passengers`
--
ALTER TABLE `passengers`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `seat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`flight_id`) ON DELETE CASCADE;

--
-- Constraints for table `cancellations`
--
ALTER TABLE `cancellations`
  ADD CONSTRAINT `cancellations_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cancellations_ibfk_2` FOREIGN KEY (`passenger_id`) REFERENCES `passengers` (`passenger_id`) ON DELETE SET NULL;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback_replies`
--
ALTER TABLE `feedback_replies`
  ADD CONSTRAINT `feedback_replies_ibfk_1` FOREIGN KEY (`feedback_id`) REFERENCES `feedback` (`feedback_id`) ON DELETE CASCADE;

--
-- Constraints for table `passengers`
--
ALTER TABLE `passengers`
  ADD CONSTRAINT `passengers_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE;

--
-- Constraints for table `seats`
--
ALTER TABLE `seats`
  ADD CONSTRAINT `seats_ibfk_1` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`flight_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `seats_ibfk_2` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
