<?php
/* ============================================================
   AIRSMART AI - USER DASHBOARD SIDEBAR
   Included by every page inside /user/ (after header.php) to
   give the logged-in user area a modern vertical sidebar layout,
   matching the Admin panel's Dark Blue + Sky Blue theme.
   ============================================================ */
$currentFile = basename($_SERVER['PHP_SELF']);
$bookingPages = ['booking-history.php', 'view-booking.php', 'ticket.php', 'cancel-booking.php', 'booking.php', 'seat-selection.php', 'passenger-details.php', 'payment.php'];
$profilePages = ['profile.php', 'change-password.php'];
?>
<div class="user-wrapper">
  <aside class="user-sidebar no-print">
    <div class="user-brand">
      <i class="fa-solid fa-plane-up"></i> <?php echo SITE_NAME; ?>
      <small class="d-block">My Account</small>
    </div>
    <nav class="user-nav">
      <a href="<?php echo BASE_URL; ?>user/index.php" class="<?php echo $currentFile == 'index.php' ? 'active' : ''; ?>">
        <i class="fa-solid fa-gauge"></i> Dashboard
      </a>
      <a href="<?php echo BASE_URL; ?>user/search-flights.php" class="<?php echo $currentFile == 'search-flights.php' ? 'active' : ''; ?>">
        <i class="fa-solid fa-magnifying-glass"></i> Search Flight
      </a>
      <a href="<?php echo BASE_URL; ?>user/booking-history.php" class="<?php echo in_array($currentFile, $bookingPages) ? 'active' : ''; ?>">
        <i class="fa-solid fa-ticket"></i> My Booking
      </a>
      <a href="<?php echo BASE_URL; ?>user/profile.php" class="<?php echo in_array($currentFile, $profilePages) ? 'active' : ''; ?>">
        <i class="fa-solid fa-user"></i> My Profile
      </a>
      <a href="<?php echo BASE_URL; ?>user/recommendations.php" class="<?php echo $currentFile == 'recommendations.php' ? 'active' : ''; ?>">
        <i class="fa-solid fa-star"></i> Recommendation
      </a>
      <div class="nav-divider"></div>
      <a href="<?php echo BASE_URL; ?>user/give-feedback.php" class="<?php echo $currentFile == 'give-feedback.php' ? 'active' : ''; ?>">
        <i class="fa-solid fa-comment-dots"></i> Give Feedback
      </a>
      <a href="<?php echo BASE_URL; ?>user/feedback-history.php" class="<?php echo $currentFile == 'feedback-history.php' ? 'active' : ''; ?>">
        <i class="fa-solid fa-comments"></i> My Feedback
      </a>
      <a href="<?php echo BASE_URL; ?>index.php">
        <i class="fa-solid fa-house"></i> Back to Home
      </a>
      <a href="<?php echo BASE_URL; ?>user/logout.php" class="text-danger">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
      </a>
    </nav>
  </aside>
  <div class="user-content-col">
    <header class="user-topbar no-print">
      <button class="sidebar-toggle d-lg-none" onclick="document.querySelector('.user-sidebar').classList.toggle('show')">
        <i class="fa-solid fa-bars"></i>
      </button>
      <h5 class="mb-0"><?php echo isset($pageTitle) ? clean($pageTitle) : 'My Dashboard'; ?></h5>
      <div class="user-topbar-user">
        <i class="fa-solid fa-circle-user"></i> <?php echo clean(isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'User'); ?>
      </div>
    </header>
    <main class="user-main">
