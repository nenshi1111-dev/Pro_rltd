<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Complaint Guide';
require_once __DIR__ . '/includes/header.php';
$steps = [
  ['Register an account', 'Sign up as a citizen with your basic details, email, and phone number.'],
  ['Login securely', 'Use your username and password to access your citizen dashboard.'],
  ['Submit your complaint', 'Fill in the crime category, incident details, and description as accurately as possible.'],
  ['Upload evidence', 'Attach screenshots, documents, or receipts that support your complaint (JPG, PNG, PDF, DOC, DOCX).'],
  ['Get a reference number', 'A unique complaint number (e.g. CR2026000001) is generated automatically.'],
  ['Track the status', 'Follow your complaint through Submitted, Under Review, Assigned, Investigation, and Resolution.'],
  ['Respond if needed', 'Provide additional information if the investigator requests it.'],
  ['Resolution', 'Once investigated, your complaint is marked Resolved or Closed with full status history.'],
];
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">How to File a Complaint</h1>
    <p class="lead cr-hero-fade delay-1">Follow these steps to report a cyber crime on Cyber-Report.</p>
  </div>
</section>

<section class="py-5">
  <div class="container" style="max-width:760px;">
    <?php foreach ($steps as $i => $s): ?>
    <div class="d-flex mb-4 cr-reveal">
      <div class="cr-step-badge"><?= $i + 1 ?></div>
      <div>
        <h6 class="fw-bold mb-1"><?= clean($s[0]) ?></h6>
        <p class="text-muted small mb-0"><?= clean($s[1]) ?></p>
      </div>
    </div>
    <?php endforeach; ?>
    <div class="text-center mt-5 cr-reveal">
      <a href="<?= BASE_URL ?>register.php" class="btn btn-cr-solid btn-lg">Start Now</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
