<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Contact';
$success = false; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean($_POST['name'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $message = clean($_POST['message'] ?? '');

    if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$message) {
        $error = 'Please fill in a valid name, email, and message.';
    } else {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, phone, message) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $name, $email, $phone, $message);
        $stmt->execute();
        $success = true;
    }
}

$site = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
require_once __DIR__ . '/includes/header.php';
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">Contact Us</h1>
    <p class="lead cr-hero-fade delay-1">Reach the Cyber Crime Cell for general queries.</p>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-5 cr-reveal">
        <div class="cr-card p-4 h-100">
          <h5 class="mb-3">Office Details</h5>
          <p class="small text-muted mb-1"><strong>Address:</strong> <?= clean($site['office_address']) ?></p>
          <p class="small text-muted mb-1"><strong>Phone:</strong> <?= clean($site['contact_phone']) ?></p>
          <p class="small text-muted mb-1"><strong>Email:</strong> <?= clean($site['contact_email']) ?></p>
          <p class="small text-muted mb-0"><strong>Working Hours:</strong> <?= clean($site['working_hours']) ?></p>
        </div>
      </div>
      <div class="col-lg-7 cr-reveal">
        <div class="cr-card p-4">
          <?php if ($success): ?>
            <div class="alert alert-success">Thank you — your message has been received.</div>
          <?php endif; ?>
          <?php if ($error): ?>
            <div class="alert alert-danger"><?= clean($error) ?></div>
          <?php endif; ?>
          <form method="post" novalidate>
            <?= csrf_field() ?>
            <div class="mb-3">
              <label class="form-label">Name</label>
              <input type="text" name="name" class="form-control" required>
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Phone</label>
                <input type="text" name="phone" class="form-control">
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label">Message</label>
              <textarea name="message" rows="4" class="form-control" required></textarea>
            </div>
            <button class="btn btn-cr-solid" type="submit">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
