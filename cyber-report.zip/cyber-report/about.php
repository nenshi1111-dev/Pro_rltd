<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'About';
require_once __DIR__ . '/includes/header.php';
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">About Cyber-Report</h1>
    <p class="lead cr-hero-fade delay-1">A student-built platform for organized, secure cyber crime case management.</p>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6 cr-reveal">
        <h2 class="cr-section-title">Our Purpose</h2>
        <p class="text-muted">
          Cyber-Report is a Cyber Crime Reporting &amp; Case Management System built to make it easier
          for citizens to report cyber crimes online, and for administrators and investigators to manage
          those complaints in an organized, transparent, and secure way.
        </p>
        <p class="text-muted">
          Instead of manual, paper-based reporting, Cyber-Report centralizes complaints, evidence metadata,
          investigation updates, and status history in one place — with role-based access ensuring
          citizen privacy and investigation confidentiality are respected at every step.
        </p>
      </div>
      <div class="col-lg-6 cr-reveal">
        <div class="cr-card p-4">
          <h5 class="mb-3">What Makes It Reliable</h5>
          <ul class="text-muted small">
            <li>Role-based access for Citizens, Investigators, and Admins</li>
            <li>Unique, auto-generated complaint reference numbers</li>
            <li>Full status history for every complaint</li>
            <li>Secure evidence upload with strict file-type validation</li>
            <li>Password hashing and prepared SQL statements throughout</li>
            <li>Public aggregate statistics with no personal data exposed</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5 bg-white">
  <div class="container text-center cr-reveal">
    <h2 class="cr-section-title mb-4">Project Team</h2>
    <div class="row justify-content-center g-4">
      <div class="col-md-3">
        <div class="cr-card p-4">
          <div class="cr-icon-box mx-auto">R</div>
          <h6 class="mt-2">Rachna</h6>
          <p class="text-muted small mb-0">Co-Creator</p>
        </div>
      </div>
      <div class="col-md-3">
        <div class="cr-card p-4">
          <div class="cr-icon-box mx-auto">Y</div>
          <h6 class="mt-2">Yagni</h6>
          <p class="text-muted small mb-0">Co-Creator</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
