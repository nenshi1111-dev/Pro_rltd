<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Safety Tips';
$tips = [
  'Never share OTP' => 'Banks and legitimate services never ask for your OTP over a call or message.',
  'Use strong passwords' => 'Combine letters, numbers, and symbols, and avoid reusing passwords across sites.',
  'Enable two-factor authentication' => 'Add an extra verification layer to your important accounts.',
  'Verify URLs' => 'Check the website address carefully before entering login or payment details.',
  'Avoid unknown attachments' => "Don't open attachments or links from unexpected or unknown senders.",
  'Keep software updated' => 'Regular updates patch security vulnerabilities on your devices.',
  'Do not share banking credentials' => 'No genuine bank representative will ask for your PIN, CVV, or password.',
  'Report suspicious activity quickly' => 'Early reporting improves the chances of recovering funds and evidence.',
  'Use official websites and applications' => 'Download apps only from official stores and verified sources.',
  'Preserve evidence after an incident' => 'Take screenshots and save messages/emails before they can be deleted.',
];
require_once __DIR__ . '/includes/header.php';
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">Cyber Safety Tips</h1>
    <p class="lead cr-hero-fade delay-1">Simple habits that go a long way in preventing cyber crime.</p>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <?php foreach ($tips as $title => $desc): ?>
      <div class="col-md-6 col-lg-4 cr-reveal">
        <div class="cr-card p-4">
          <div class="cr-icon-box">&#10003;</div>
          <h6 class="fw-bold"><?= clean($title) ?></h6>
          <p class="text-muted small mb-0"><?= clean($desc) ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
