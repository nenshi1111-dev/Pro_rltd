<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Cyber Crimes';
$cats = $conn->query("SELECT * FROM crime_categories WHERE status='Active' ORDER BY name");
require_once __DIR__ . '/includes/header.php';
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">Types of Cyber Crimes</h1>
    <p class="lead cr-hero-fade delay-1">Know the common categories so you can identify and report them quickly.</p>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <?php while ($c = $cats->fetch_assoc()): ?>
      <div class="col-md-4 cr-reveal">
        <div class="cr-card p-4">
          <div class="cr-icon-box">&#9888;</div>
          <h5><?= clean($c['name']) ?></h5>
          <p class="text-muted small mb-0"><?= clean($c['description']) ?></p>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
    <div class="text-center mt-5 cr-reveal">
      <a href="<?= BASE_URL ?>register.php" class="btn btn-cr-solid btn-lg">Report an Incident</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
