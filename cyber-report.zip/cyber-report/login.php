<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Login';
if (is_logged_in()) redirect(current_role() . '/dashboard.php');

$error = '';
$flash = $_SESSION['flash_success'] ?? '';
unset($_SESSION['flash_success']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $role = $_POST['role'] ?? 'citizen';
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $tableMap = ['admin' => 'admins', 'investigator' => 'investigators', 'citizen' => 'citizens'];
    $table = $tableMap[$role] ?? 'citizens';
    $nameField = $table === 'citizens' ? 'full_name' : 'name';

    $stmt = $conn->prepare("SELECT * FROM {$table} WHERE username = ? LIMIT 1");
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user || !password_verify($password, $user['password'])) {
        $error = 'Invalid username or password.';
    } elseif (isset($user['status']) && in_array($user['status'], ['Blocked', 'Inactive'], true)) {
        $error = 'Your account has been ' . strtolower($user['status']) . '. Please contact the administrator.';
    } else {
        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['role']      = $role;
        $_SESSION['user_name'] = $user[$nameField];
        redirect($role . '/dashboard.php');
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<div class="cr-auth-wrap">
  <div class="cr-auth-card">
    <h3 class="fw-bold text-center mb-1">Login to Cyber-Report</h3>
    <p class="text-muted text-center small mb-4">Access your dashboard as a Citizen, Investigator, or Admin.</p>

    <?php if ($flash): ?><div class="alert alert-success py-2 small"><?= clean($flash) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger py-2 small"><?= clean($error) ?></div><?php endif; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label">Login As</label>
        <select name="role" class="form-select">
          <option value="citizen">Citizen</option>
          <option value="investigator">Investigator</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required autofocus>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
          <input type="password" id="pwd1" name="password" class="form-control pwd-toggle-input" required>
          <button class="btn btn-outline-secondary pwd-toggle-btn" type="button" data-target="#pwd1">Show</button>
        </div>
      </div>
      <button type="submit" class="btn btn-cr-solid w-100">Login</button>
    </form>
    <p class="text-center small text-muted mt-3 mb-0">New citizen? <a href="<?= BASE_URL ?>register.php">Create an account</a></p>

    <div class="mt-4 pt-3 border-top">
      <p class="small text-muted mb-1"><strong>Demo credentials</strong> (after importing the SQL file):</p>
      <p class="small text-muted mb-0">Admin: <code>admin</code> / <code>Admin@123</code></p>
      <p class="small text-muted mb-0">Citizen: <code>rahulm</code> / <code>Citizen@123</code></p>
      <p class="small text-muted mb-0">Investigator: <code>vikramr</code> / <code>Invest@123</code></p>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
