<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Admin Dashboard';
$active = 'dashboard';

$citizens = $conn->query("SELECT COUNT(*) c FROM citizens")->fetch_assoc()['c'];
$complaintsTotal = $conn->query("SELECT COUNT(*) c FROM complaints")->fetch_assoc()['c'];
$investigators = $conn->query("SELECT COUNT(*) c FROM investigators")->fetch_assoc()['c'];
$pending = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Submitted','Under Review')")->fetch_assoc()['c'];
$activeInv = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Assigned','Investigation In Progress','Additional Information Required')")->fetch_assoc()['c'];
$resolved = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Resolved'")->fetch_assoc()['c'];
$closed = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Closed'")->fetch_assoc()['c'];
$unassigned = $conn->query("SELECT COUNT(*) c FROM complaints c2 WHERE NOT EXISTS (SELECT 1 FROM complaint_assignments ca WHERE ca.complaint_id=c2.id AND ca.is_active=1) AND status NOT IN ('Resolved','Closed','Rejected')")->fetch_assoc()['c'];

$recentComplaints = $conn->query("SELECT c.*, cc.name AS category_name, ct.full_name AS citizen_name FROM complaints c JOIN crime_categories cc ON cc.id=c.category_id JOIN citizens ct ON ct.id=c.citizen_id ORDER BY c.created_at DESC LIMIT 6");
$recentAnnouncements = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC LIMIT 4");

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$citizens ?></div><div class="lbl">Citizens</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$complaintsTotal ?></div><div class="lbl">Complaints</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$investigators ?></div><div class="lbl">Investigators</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$unassigned ?></div><div class="lbl">Unassigned</div></div></div>
</div>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$pending ?></div><div class="lbl">Pending Cases</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$activeInv ?></div><div class="lbl">Active Investigations</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$resolved ?></div><div class="lbl">Resolved</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$closed ?></div><div class="lbl">Closed</div></div></div>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h6 class="fw-bold mb-0">Recent Complaints</h6>
      <a href="complaints.php" class="btn btn-cr-outline btn-sm">View All</a>
    </div>
    <div class="cr-card p-3">
      <div class="table-responsive">
        <table class="table cr-table align-middle mb-0">
          <thead><tr><th>Ref No.</th><th>Citizen</th><th>Category</th><th>Status</th><th></th></tr></thead>
          <tbody>
            <?php while ($r = $recentComplaints->fetch_assoc()): ?>
            <tr>
              <td><code><?= clean($r['complaint_number']) ?></code></td>
              <td><?= clean($r['citizen_name']) ?></td>
              <td><?= clean($r['category_name']) ?></td>
              <td><span class="badge bg-<?= status_badge_class($r['status']) ?> badge-status"><?= clean($r['status']) ?></span></td>
              <td><a href="complaint-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">Open</a></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h6 class="fw-bold mb-0">Recent Announcements</h6>
      <a href="announcements.php" class="btn btn-cr-outline btn-sm">Manage</a>
    </div>
    <div class="cr-card p-3">
      <?php if ($recentAnnouncements->num_rows === 0): ?><p class="text-muted small mb-0">No announcements yet.</p><?php endif; ?>
      <?php while ($a = $recentAnnouncements->fetch_assoc()): ?>
        <div class="mb-3 pb-3 border-bottom">
          <div class="fw-semibold small"><?= clean($a['title']) ?></div>
          <div class="text-muted small"><?= clean($a['message']) ?></div>
          <div class="text-muted" style="font-size:.75rem;"><?= format_date($a['created_at']) ?> &bull; <?= clean($a['audience']) ?></div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
