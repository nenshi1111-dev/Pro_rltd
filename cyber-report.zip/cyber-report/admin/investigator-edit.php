<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM investigators WHERE id=?");
$stmt->bind_param('i', $id); $stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
if (!$inv) redirect('admin/investigators.php');

$page_title = 'Edit Investigator';
$active = 'investigators';
$errors = []; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean($_POST['name'] ?? '');
    $gender = clean($_POST['gender'] ?? 'Other');
    $dob = $_POST['dob'] ?: null;
    $phone = clean($_POST['phone'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $department = clean($_POST['department'] ?? '');
    $specialization = clean($_POST['specialization'] ?? '');
    $joining_date = $_POST['joining_date'] ?: null;

    if (!$name) $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';

    if (!$errors) {
        $stmt = $conn->prepare("UPDATE investigators SET name=?, gender=?, dob=?, phone=?, email=?, address=?, department=?, specialization=?, joining_date=? WHERE id=?");
        $stmt->bind_param('sssssssssi', $name, $gender, $dob, $phone, $email, $address, $department, $specialization, $joining_date, $id);
        $stmt->execute();
        $success = 'Investigator updated successfully.';
        $inv = array_merge($inv, compact('name','gender','dob','phone','email','address','department','specialization','joining_date'));
    }
}
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-4" style="max-width:760px;">
  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" value="<?= clean($inv['name']) ?>" required></div>
      <div class="col-md-3 mb-3"><label class="form-label">Gender</label>
        <select name="gender" class="form-select">
          <?php foreach (['Male','Female','Other'] as $g): ?>
            <option <?= $inv['gender']===$g?'selected':'' ?>><?= $g ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-3 mb-3"><label class="form-label">Date of Birth</label><input type="date" name="dob" class="form-control" value="<?= clean($inv['dob']) ?>"></div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?= clean($inv['phone']) ?>"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= clean($inv['email']) ?>" required></div>
    </div>
    <div class="mb-3"><label class="form-label">Address</label><input type="text" name="address" class="form-control" value="<?= clean($inv['address']) ?>"></div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Department/Unit</label><input type="text" name="department" class="form-control" value="<?= clean($inv['department']) ?>"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Specialization</label><input type="text" name="specialization" class="form-control" value="<?= clean($inv['specialization']) ?>"></div>
    </div>
    <div class="mb-3"><label class="form-label">Joining Date</label><input type="date" name="joining_date" class="form-control" value="<?= clean($inv['joining_date']) ?>"></div>
    <button type="submit" class="btn btn-cr-solid">Save Changes</button>
    <a href="investigators.php" class="btn btn-outline-secondary">Back</a>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
