<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'My Profile';
$active = 'profile';
$aid = current_id();
$errors = []; $success = '';

$stmt = $conn->prepare("SELECT * FROM admins WHERE id=?");
$stmt->bind_param('i', $aid); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean($_POST['name'] ?? '');
    $email = clean($_POST['email'] ?? '');

    if (!$name) $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';

    if (!$errors) {
        $stmt = $conn->prepare("UPDATE admins SET name=?, email=? WHERE id=?");
        $stmt->bind_param('ssi', $name, $email, $aid);
        $stmt->execute();
        $_SESSION['user_name'] = $name;
        $success = 'Profile updated successfully.';
        $user = array_merge($user, compact('name', 'email'));
    }
}
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-4" style="max-width:640px;">
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label">Username</label><input type="text" class="form-control" value="<?= clean($user['username']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" value="<?= clean($user['name']) ?>" required></div>
    <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= clean($user['email']) ?>" required></div>
    <button type="submit" class="btn btn-cr-solid">Save Changes</button>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
