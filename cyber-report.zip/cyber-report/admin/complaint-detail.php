<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT c.*, cc.name AS category_name, ct.full_name AS citizen_name, ct.phone AS citizen_phone, ct.email AS citizen_email
                         FROM complaints c JOIN crime_categories cc ON cc.id=c.category_id JOIN citizens ct ON ct.id=c.citizen_id WHERE c.id=?");
$stmt->bind_param('i', $id); $stmt->execute();
$complaint = $stmt->get_result()->fetch_assoc();
if (!$complaint) redirect('admin/complaints.php');

$page_title = 'Complaint ' . $complaint['complaint_number'];
$active = 'complaints';
$errors = []; $success = '';
$adminId = current_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'assign') {
        $investigator_id = (int)($_POST['investigator_id'] ?? 0);
        if ($investigator_id) {
            // Preserve assignment history: deactivate current active assignment, insert new one
            $conn->query("UPDATE complaint_assignments SET is_active=0 WHERE complaint_id={$id} AND is_active=1");
            $stmt = $conn->prepare("INSERT INTO complaint_assignments (complaint_id, investigator_id, assigned_by) VALUES (?,?,?)");
            $stmt->bind_param('iii', $id, $investigator_id, $adminId);
            $stmt->execute();
            if (!in_array($complaint['status'], ['Investigation In Progress','Resolved','Closed'], true)) {
                change_complaint_status($conn, $id, 'Assigned', current_name(), 'admin', 'Complaint assigned to investigator.');
                $complaint['status'] = 'Assigned';
            }
            $success = 'Complaint assigned successfully.';
        } else {
            $errors[] = 'Please select an investigator.';
        }
    } elseif ($action === 'change_status') {
        $new_status = $_POST['new_status'] ?? '';
        $remarks = clean($_POST['remarks'] ?? '');
        if (in_array($new_status, status_list(), true)) {
            change_complaint_status($conn, $id, $new_status, current_name(), 'admin', $remarks);
            $complaint['status'] = $new_status;
            $success = 'Status updated to ' . $new_status . '.';
        }
    }
}

$evidence = $conn->prepare("SELECT * FROM evidence WHERE complaint_id=? ORDER BY uploaded_at DESC");
$evidence->bind_param('i', $id); $evidence->execute(); $evidence = $evidence->get_result();

$history = $conn->prepare("SELECT * FROM status_history WHERE complaint_id=? ORDER BY created_at ASC");
$history->bind_param('i', $id); $history->execute(); $history = $history->get_result();

$updates = $conn->prepare("SELECT iu.*, i.name AS investigator_name FROM investigation_updates iu JOIN investigators i ON i.id=iu.investigator_id WHERE complaint_id=? ORDER BY iu.created_at DESC");
$updates->bind_param('i', $id); $updates->execute(); $updates = $updates->get_result();

$assignments = $conn->prepare("SELECT ca.*, i.name AS investigator_name FROM complaint_assignments ca JOIN investigators i ON i.id=ca.investigator_id WHERE complaint_id=? ORDER BY assigned_at DESC");
$assignments->bind_param('i', $id); $assignments->execute(); $assignments = $assignments->get_result();

$activeInvestigators = $conn->query("SELECT * FROM investigators WHERE status='Active' ORDER BY name");

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h5 class="mb-1"><?= clean($complaint['title']) ?></h5>
    <div class="text-muted small">Ref: <code><?= clean($complaint['complaint_number']) ?></code> &bull; Filed <?= format_date($complaint['created_at']) ?></div>
  </div>
  <span class="badge bg-<?= status_badge_class($complaint['status']) ?> badge-status fs-6"><?= clean($complaint['status']) ?></span>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Complaint Details</h6>
      <div class="row small mb-2"><div class="col-5 text-muted">Category</div><div class="col-7"><?= clean($complaint['category_name']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Incident Date/Time</div><div class="col-7"><?= format_date($complaint['incident_datetime']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Location</div><div class="col-7"><?= clean($complaint['incident_location'] ?: '—') ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Platform</div><div class="col-7"><?= clean($complaint['platform'] ?: '—') ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Financial Loss</div><div class="col-7">₹<?= number_format($complaint['financial_loss'], 2) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Transaction Ref</div><div class="col-7"><?= clean($complaint['transaction_ref'] ?: '—') ?></div></div>
      <hr>
      <div class="mb-2"><span class="text-muted small">Description</span><p class="mb-0"><?= nl2br(clean($complaint['description'])) ?></p></div>
      <?php if ($complaint['additional_info']): ?><div><span class="text-muted small">Additional Information</span><p class="mb-0"><?= nl2br(clean($complaint['additional_info'])) ?></p></div><?php endif; ?>
    </div>

    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Complainant Information</h6>
      <div class="row small mb-2"><div class="col-5 text-muted">Name</div><div class="col-7"><?= clean($complaint['citizen_name']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Phone</div><div class="col-7"><?= clean($complaint['citizen_phone']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Email</div><div class="col-7"><?= clean($complaint['citizen_email']) ?></div></div>
    </div>

    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Evidence</h6>
      <?php if ($evidence->num_rows === 0): ?><p class="text-muted small mb-0">No evidence uploaded.</p><?php endif; ?>
      <ul class="list-unstyled small mb-0">
        <?php while ($e = $evidence->fetch_assoc()): ?>
          <li class="mb-1">&#128206; <?= clean($e['original_name']) ?> <span class="text-muted">(<?= strtoupper($e['file_type']) ?>, <?= round($e['file_size']/1024) ?> KB)</span></li>
        <?php endwhile; ?>
      </ul>
    </div>

    <div class="cr-card p-4">
      <h6 class="fw-bold mb-3">Investigation Updates</h6>
      <?php if ($updates->num_rows === 0): ?><p class="text-muted small mb-0">No updates recorded yet.</p><?php endif; ?>
      <ul class="list-unstyled small">
        <?php while ($u = $updates->fetch_assoc()): ?>
          <li class="mb-2 pb-2 border-bottom">
            <div><?= nl2br(clean($u['update_text'])) ?></div>
            <div class="text-muted" style="font-size:.78rem;"><?= clean($u['investigator_name']) ?> &bull; <?= format_date($u['created_at']) ?></div>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Assign Investigator</h6>
      <form method="post" class="mb-2">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="assign">
        <select name="investigator_id" class="form-select mb-2">
          <option value="">Select investigator</option>
          <?php while ($i = $activeInvestigators->fetch_assoc()): ?>
            <option value="<?= (int)$i['id'] ?>"><?= clean($i['name']) ?> (<?= clean($i['specialization']) ?>)</option>
          <?php endwhile; ?>
        </select>
        <button class="btn btn-cr-solid btn-sm w-100">Assign</button>
      </form>
      <div class="small">
        <div class="text-muted mb-1">Assignment History</div>
        <ul class="list-unstyled mb-0">
          <?php if ($assignments->num_rows === 0): ?><li class="text-muted">Not yet assigned.</li><?php endif; ?>
          <?php while ($a = $assignments->fetch_assoc()): ?>
            <li class="mb-1"><?= clean($a['investigator_name']) ?> — <?= format_date($a['assigned_at']) ?> <?= $a['is_active'] ? '<span class="badge bg-primary">Active</span>' : '<span class="badge bg-secondary">Reassigned</span>' ?></li>
          <?php endwhile; ?>
        </ul>
      </div>
    </div>

    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Update Status</h6>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="change_status">
        <select name="new_status" class="form-select mb-2">
          <?php foreach (status_list() as $s): ?>
            <option value="<?= clean($s) ?>" <?= $complaint['status']===$s?'selected':'' ?>><?= clean($s) ?></option>
          <?php endforeach; ?>
        </select>
        <textarea name="remarks" rows="2" class="form-control mb-2" placeholder="Remarks (optional)"></textarea>
        <button class="btn btn-cr-solid btn-sm w-100">Update Status</button>
      </form>
    </div>

    <div class="cr-card p-4">
      <h6 class="fw-bold mb-3">Status History</h6>
      <ul class="list-unstyled small">
        <?php while ($h = $history->fetch_assoc()): ?>
          <li class="mb-3 pb-3 border-bottom">
            <div><span class="badge bg-<?= status_badge_class($h['new_status']) ?> badge-status"><?= clean($h['new_status']) ?></span></div>
            <div class="text-muted mt-1"><?= format_date($h['created_at']) ?> by <?= clean($h['changed_by']) ?> (<?= clean($h['user_role']) ?>)</div>
            <?php if ($h['remarks']): ?><div class="mt-1"><?= clean($h['remarks']) ?></div><?php endif; ?>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
