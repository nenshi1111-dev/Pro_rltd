<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'System Settings';
$active = 'settings';
$success = '';

$settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
if (!$settings) {
    $conn->query("INSERT INTO settings (id) VALUES (1)");
    $settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $site_name = clean($_POST['site_name'] ?? '');
    $tagline = clean($_POST['tagline'] ?? '');
    $contact_email = clean($_POST['contact_email'] ?? '');
    $contact_phone = clean($_POST['contact_phone'] ?? '');
    $office_address = clean($_POST['office_address'] ?? '');
    $working_hours = clean($_POST['working_hours'] ?? '');

    $stmt = $conn->prepare("UPDATE settings SET site_name=?, tagline=?, contact_email=?, contact_phone=?, office_address=?, working_hours=? WHERE id=?");
    $id = $settings['id'];
    $stmt->bind_param('ssssssi', $site_name, $tagline, $contact_email, $contact_phone, $office_address, $working_hours, $id);
    $stmt->execute();
    $success = 'Settings updated successfully.';
    $settings = compact('site_name','tagline','contact_email','contact_phone','office_address','working_hours') + $settings;
}

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-4" style="max-width:640px;">
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label">Site Name</label><input type="text" name="site_name" class="form-control" value="<?= clean($settings['site_name']) ?>"></div>
    <div class="mb-3"><label class="form-label">Tagline</label><input type="text" name="tagline" class="form-control" value="<?= clean($settings['tagline']) ?>"></div>
    <div class="mb-3"><label class="form-label">Contact Email</label><input type="email" name="contact_email" class="form-control" value="<?= clean($settings['contact_email']) ?>"></div>
    <div class="mb-3"><label class="form-label">Contact Phone</label><input type="text" name="contact_phone" class="form-control" value="<?= clean($settings['contact_phone']) ?>"></div>
    <div class="mb-3"><label class="form-label">Office Address</label><input type="text" name="office_address" class="form-control" value="<?= clean($settings['office_address']) ?>"></div>
    <div class="mb-3"><label class="form-label">Working Hours</label><input type="text" name="working_hours" class="form-control" value="<?= clean($settings['working_hours']) ?>"></div>
    <button type="submit" class="btn btn-cr-solid">Save Settings</button>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
