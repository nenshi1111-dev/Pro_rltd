<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Manage Citizens';
$active = 'citizens';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle_status') {
    verify_csrf();
    $id = (int)$_POST['id'];
    $new_status = $_POST['current_status'] === 'Active' ? 'Blocked' : 'Active';
    $stmt = $conn->prepare("UPDATE citizens SET status=? WHERE id=?");
    $stmt->bind_param('si', $new_status, $id);
    $stmt->execute();
    $success = "Citizen status updated to {$new_status}.";
}

$search = clean($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 10;

$where = '1=1'; $params = []; $types = '';
if ($search !== '') {
    $where = "(full_name LIKE ? OR username LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $like = "%$search%"; $params = [$like, $like, $like, $like]; $types = 'ssss';
}

$countStmt = $conn->prepare("SELECT COUNT(*) c FROM citizens WHERE $where");
if ($types) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalRows = $countStmt->get_result()->fetch_assoc()['c'];
$p = paginate($totalRows, $per_page, $page);

$sql = "SELECT * FROM citizens WHERE $where ORDER BY created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$types2 = $types . 'ii';
$params2 = array_merge($params, [$per_page, $p['offset']]);
$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$rows = $stmt->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-3 mb-3">
  <form class="row g-2" method="get">
    <div class="col-md-8"><input type="text" name="q" class="form-control" placeholder="Search by name, username, email, or phone" value="<?= clean($search) ?>"></div>
    <div class="col-md-4"><button class="btn btn-cr-solid w-100">Search</button></div>
  </form>
</div>

<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>State</th><th>Status</th><th>Joined</th><th></th></tr></thead>
      <tbody>
      <?php if ($rows->num_rows === 0): ?><tr><td colspan="8" class="text-center text-muted py-4">No citizens found.</td></tr><?php endif; ?>
      <?php while ($r = $rows->fetch_assoc()): ?>
        <tr>
          <td><?= clean($r['full_name']) ?></td>
          <td><?= clean($r['username']) ?></td>
          <td><?= clean($r['email']) ?></td>
          <td><?= clean($r['phone']) ?></td>
          <td><?= clean($r['state']) ?></td>
          <td><span class="badge bg-<?= $r['status']==='Active'?'success':'danger' ?>"><?= clean($r['status']) ?></span></td>
          <td><?= format_date($r['created_at']) ?></td>
          <td>
            <form method="post" class="d-inline confirm-action" data-confirm="Change this citizen's status?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle_status">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="current_status" value="<?= clean($r['status']) ?>">
              <button class="btn btn-sm btn-outline-<?= $r['status']==='Active'?'danger':'success' ?>">
                <?= $r['status']==='Active' ? 'Block' : 'Activate' ?>
              </button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($p['total_pages'] > 1): ?>
<nav class="mt-3"><ul class="pagination justify-content-center">
  <?php for ($i=1;$i<=$p['total_pages'];$i++): ?>
    <li class="page-item <?= $i===$p['current_page']?'active':'' ?>"><a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search) ?>"><?= $i ?></a></li>
  <?php endfor; ?>
</ul></nav>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
