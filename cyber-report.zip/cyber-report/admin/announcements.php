<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Announcements';
$active = 'announcements';
$errors = []; $success = '';
$adminId = current_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $title = clean($_POST['title'] ?? '');
        $message = clean($_POST['message'] ?? '');
        $audience = $_POST['audience'] ?? 'all';
        if (!in_array($audience, ['public','citizens','investigators','all'], true)) $audience = 'all';

        if (!$title || !$message) {
            $errors[] = 'Title and message are required.';
        } else {
            $stmt = $conn->prepare("INSERT INTO announcements (title, message, audience, created_by) VALUES (?,?,?,?)");
            $stmt->bind_param('sssi', $title, $message, $audience, $adminId);
            $stmt->execute();
            $success = 'Announcement published.';
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $conn->prepare("DELETE FROM announcements WHERE id=?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $success = 'Announcement deleted.';
    }
}

$rows = $conn->query("SELECT * FROM announcements ORDER BY created_at DESC");
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="cr-card p-4">
      <h6 class="fw-bold mb-3">New Announcement</h6>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="mb-3"><label class="form-label">Title</label><input type="text" name="title" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Message</label><textarea name="message" class="form-control" rows="3" required></textarea></div>
        <div class="mb-3">
          <label class="form-label">Audience</label>
          <select name="audience" class="form-select">
            <option value="all">All Users</option>
            <option value="public">Public (website visitors)</option>
            <option value="citizens">Citizens Only</option>
            <option value="investigators">Investigators Only</option>
          </select>
        </div>
        <button class="btn btn-cr-solid w-100">Publish</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="cr-card p-3">
      <?php if ($rows->num_rows === 0): ?><p class="text-muted small mb-0 p-2">No announcements yet.</p><?php endif; ?>
      <?php while ($a = $rows->fetch_assoc()): ?>
        <div class="d-flex justify-content-between align-items-start mb-3 pb-3 border-bottom">
          <div>
            <div class="fw-semibold"><?= clean($a['title']) ?> <span class="badge bg-secondary text-capitalize"><?= clean($a['audience']) ?></span></div>
            <div class="text-muted small"><?= clean($a['message']) ?></div>
            <div class="text-muted" style="font-size:.75rem;"><?= format_date($a['created_at']) ?></div>
          </div>
          <form method="post" class="confirm-action" data-confirm="Delete this announcement?">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
            <button class="btn btn-sm btn-outline-danger">Delete</button>
          </form>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
