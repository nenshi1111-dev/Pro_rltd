<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Manage Investigators';
$active = 'investigators';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle_status') {
    verify_csrf();
    $id = (int)$_POST['id'];
    $new_status = $_POST['current_status'] === 'Active' ? 'Inactive' : 'Active';
    $stmt = $conn->prepare("UPDATE investigators SET status=? WHERE id=?");
    $stmt->bind_param('si', $new_status, $id);
    $stmt->execute();
    $success = "Investigator status updated to {$new_status}.";
}

$search = clean($_GET['q'] ?? '');
$where = '1=1'; $params = []; $types = '';
if ($search !== '') {
    $where = "(name LIKE ? OR username LIKE ? OR email LIKE ? OR department LIKE ?)";
    $like = "%$search%"; $params = [$like, $like, $like, $like]; $types = 'ssss';
}
$sql = "SELECT * FROM investigators WHERE $where ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <form class="row g-2 flex-grow-1 me-3" method="get">
    <div class="col-md-6"><input type="text" name="q" class="form-control" placeholder="Search investigators" value="<?= clean($search) ?>"></div>
    <div class="col-md-3"><button class="btn btn-cr-outline w-100">Search</button></div>
  </form>
  <a href="investigator-add.php" class="btn btn-cr-solid text-nowrap">+ Add Investigator</a>
</div>

<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Department</th><th>Specialization</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php if ($rows->num_rows === 0): ?><tr><td colspan="7" class="text-center text-muted py-4">No investigators found.</td></tr><?php endif; ?>
      <?php while ($r = $rows->fetch_assoc()): ?>
        <tr>
          <td><?= clean($r['name']) ?></td>
          <td><?= clean($r['username']) ?></td>
          <td><?= clean($r['email']) ?></td>
          <td><?= clean($r['department']) ?></td>
          <td><?= clean($r['specialization']) ?></td>
          <td><span class="badge bg-<?= $r['status']==='Active'?'success':'secondary' ?>"><?= clean($r['status']) ?></span></td>
          <td class="text-nowrap">
            <a href="investigator-edit.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
            <form method="post" class="d-inline confirm-action" data-confirm="Change this investigator's status?">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle_status">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="hidden" name="current_status" value="<?= clean($r['status']) ?>">
              <button class="btn btn-sm btn-outline-<?= $r['status']==='Active'?'danger':'success' ?>">
                <?= $r['status']==='Active' ? 'Deactivate' : 'Activate' ?>
              </button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
