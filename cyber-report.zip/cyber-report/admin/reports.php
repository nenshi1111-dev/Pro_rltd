<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Reports & Statistics';
$active = 'reports';

$total = $conn->query("SELECT COUNT(*) c FROM complaints")->fetch_assoc()['c'];
$resolved = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Resolved'")->fetch_assoc()['c'];
$closed = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Closed'")->fetch_assoc()['c'];
$activeInv = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Assigned','Investigation In Progress','Additional Information Required')")->fetch_assoc()['c'];

$statusRows = $conn->query("SELECT status, COUNT(*) cnt FROM complaints GROUP BY status");
$statusLabels = []; $statusData = [];
while ($r = $statusRows->fetch_assoc()) { $statusLabels[] = $r['status']; $statusData[] = (int)$r['cnt']; }

$catRows = $conn->query("SELECT cc.name, COUNT(c.id) cnt FROM crime_categories cc LEFT JOIN complaints c ON c.category_id=cc.id GROUP BY cc.id ORDER BY cnt DESC");
$catLabels = []; $catData = [];
while ($r = $catRows->fetch_assoc()) { $catLabels[] = $r['name']; $catData[] = (int)$r['cnt']; }

$trendRows = $conn->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt FROM complaints GROUP BY ym ORDER BY ym");
$trendLabels = []; $trendData = [];
while ($r = $trendRows->fetch_assoc()) { $trendLabels[] = $r['ym']; $trendData[] = (int)$r['cnt']; }

$workload = $conn->query("SELECT i.name, COUNT(ca.id) cnt FROM investigators i LEFT JOIN complaint_assignments ca ON ca.investigator_id=i.id AND ca.is_active=1 GROUP BY i.id ORDER BY cnt DESC");

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$total ?></div><div class="lbl">Total Complaints</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$activeInv ?></div><div class="lbl">Active Investigations</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$resolved ?></div><div class="lbl">Resolved</div></div></div>
  <div class="col-6 col-md-3"><div class="cr-kpi text-center"><div class="num"><?= (int)$closed ?></div><div class="lbl">Closed</div></div></div>
</div>

<div class="row g-4 mb-4">
  <div class="col-lg-6"><div class="cr-card p-4"><h6 class="fw-bold mb-3">Complaints by Status</h6><canvas id="statusChart" height="220"></canvas></div></div>
  <div class="col-lg-6"><div class="cr-card p-4"><h6 class="fw-bold mb-3">Complaints by Category</h6><canvas id="catChart" height="220"></canvas></div></div>
  <div class="col-lg-12"><div class="cr-card p-4"><h6 class="fw-bold mb-3">Monthly Complaint Trend</h6><canvas id="trendChart" height="120"></canvas></div></div>
</div>

<div class="cr-card p-3">
  <h6 class="fw-bold mb-3 px-2 pt-2">Investigator Workload (active cases)</h6>
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Investigator</th><th>Active Assigned Cases</th></tr></thead>
      <tbody>
        <?php while ($w = $workload->fetch_assoc()): ?>
          <tr><td><?= clean($w['name']) ?></td><td><?= (int)$w['cnt'] ?></td></tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
const palette = ['#2563eb','#3b82f6','#0f1b45','#64748b','#22c55e','#f59e0b','#ef4444','#0ea5e9','#8b5cf6','#14b8a6','#eab308','#f97316'];
new Chart(document.getElementById('statusChart'), { type:'pie', data:{ labels:<?= json_encode($statusLabels) ?>, datasets:[{ data:<?= json_encode($statusData) ?>, backgroundColor: palette }] }, options:{ plugins:{ legend:{ position:'bottom', labels:{ boxWidth:12, font:{size:11} } } } } });
new Chart(document.getElementById('catChart'), { type:'bar', data:{ labels:<?= json_encode($catLabels) ?>, datasets:[{ label:'Cases', data:<?= json_encode($catData) ?>, backgroundColor:'#2563eb' }] }, options:{ indexAxis:'y', plugins:{ legend:{ display:false } } } });
new Chart(document.getElementById('trendChart'), { type:'line', data:{ labels:<?= json_encode($trendLabels) ?>, datasets:[{ label:'Complaints', data:<?= json_encode($trendData) ?>, borderColor:'#2563eb', backgroundColor:'rgba(37,99,235,.15)', fill:true, tension:.3 }] }, options:{ plugins:{ legend:{ display:false } } } });
</script>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
