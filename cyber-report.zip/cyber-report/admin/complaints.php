<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Manage Complaints';
$active = 'complaints';

$search = clean($_GET['q'] ?? '');
$status_filter = clean($_GET['status'] ?? '');
$category_filter = (int)($_GET['category'] ?? 0);
$investigator_filter = (int)($_GET['investigator'] ?? 0);
$date_filter = clean($_GET['date'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 10;

$joins = "JOIN crime_categories cc ON cc.id=c.category_id JOIN citizens ct ON ct.id=c.citizen_id
          LEFT JOIN complaint_assignments ca ON ca.complaint_id=c.id AND ca.is_active=1
          LEFT JOIN investigators inv ON inv.id=ca.investigator_id";
$where = "WHERE 1=1"; $params = []; $types = '';

if ($search !== '') { $where .= " AND (c.complaint_number LIKE ? OR ct.full_name LIKE ? OR c.title LIKE ?)"; $like="%$search%"; $params=array_merge($params,[$like,$like,$like]); $types.='sss'; }
if ($status_filter !== '') { $where .= " AND c.status = ?"; $params[] = $status_filter; $types .= 's'; }
if ($category_filter) { $where .= " AND c.category_id = ?"; $params[] = $category_filter; $types .= 'i'; }
if ($investigator_filter) { $where .= " AND ca.investigator_id = ?"; $params[] = $investigator_filter; $types .= 'i'; }
if ($date_filter !== '') { $where .= " AND DATE(c.created_at) = ?"; $params[] = $date_filter; $types .= 's'; }

$countStmt = $conn->prepare("SELECT COUNT(DISTINCT c.id) cnt FROM complaints c $joins $where");
if ($types) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalRows = $countStmt->get_result()->fetch_assoc()['cnt'];
$p = paginate($totalRows, $per_page, $page);

$sql = "SELECT DISTINCT c.*, cc.name AS category_name, ct.full_name AS citizen_name, inv.name AS investigator_name
        FROM complaints c $joins $where ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$types2 = $types . 'ii';
$params2 = array_merge($params, [$per_page, $p['offset']]);
$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$rows = $stmt->get_result();

$categories = $conn->query("SELECT * FROM crime_categories ORDER BY name");
$investigatorsList = $conn->query("SELECT * FROM investigators WHERE status='Active' ORDER BY name");

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="cr-card p-3 mb-3">
  <form class="row g-2" method="get">
    <div class="col-md-3"><input type="text" name="q" class="form-control" placeholder="Search ref/citizen/title" value="<?= clean($search) ?>"></div>
    <div class="col-md-2">
      <select name="status" class="form-select">
        <option value="">All Statuses</option>
        <?php foreach (status_list() as $s): ?><option value="<?= clean($s) ?>" <?= $status_filter===$s?'selected':'' ?>><?= clean($s) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <select name="category" class="form-select">
        <option value="0">All Categories</option>
        <?php $categories->data_seek(0); while ($c = $categories->fetch_assoc()): ?>
          <option value="<?= (int)$c['id'] ?>" <?= $category_filter===(int)$c['id']?'selected':'' ?>><?= clean($c['name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2">
      <select name="investigator" class="form-select">
        <option value="0">All Investigators</option>
        <?php $investigatorsList->data_seek(0); while ($i = $investigatorsList->fetch_assoc()): ?>
          <option value="<?= (int)$i['id'] ?>" <?= $investigator_filter===(int)$i['id']?'selected':'' ?>><?= clean($i['name']) ?></option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2"><input type="date" name="date" class="form-control" value="<?= clean($date_filter) ?>"></div>
    <div class="col-md-1"><button class="btn btn-cr-solid w-100">Go</button></div>
  </form>
</div>

<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Ref No.</th><th>Citizen</th><th>Category</th><th>Investigator</th><th>Status</th><th>Filed</th><th></th></tr></thead>
      <tbody>
      <?php if ($rows->num_rows === 0): ?><tr><td colspan="7" class="text-center text-muted py-4">No complaints found.</td></tr><?php endif; ?>
      <?php while ($r = $rows->fetch_assoc()): ?>
        <tr>
          <td><code><?= clean($r['complaint_number']) ?></code></td>
          <td><?= clean($r['citizen_name']) ?></td>
          <td><?= clean($r['category_name']) ?></td>
          <td><?= $r['investigator_name'] ? clean($r['investigator_name']) : '<span class="text-muted">Unassigned</span>' ?></td>
          <td><span class="badge bg-<?= status_badge_class($r['status']) ?> badge-status"><?= clean($r['status']) ?></span></td>
          <td><?= format_date($r['created_at']) ?></td>
          <td><a href="complaint-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">Open</a></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($p['total_pages'] > 1): ?>
<nav class="mt-3"><ul class="pagination justify-content-center">
  <?php for ($i=1;$i<=$p['total_pages'];$i++): ?>
    <li class="page-item <?= $i===$p['current_page']?'active':'' ?>">
      <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>&category=<?= $category_filter ?>&investigator=<?= $investigator_filter ?>&date=<?= urlencode($date_filter) ?>"><?= $i ?></a>
    </li>
  <?php endfor; ?>
</ul></nav>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
