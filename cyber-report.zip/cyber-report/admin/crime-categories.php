<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Crime Categories';
$active = 'categories';
$errors = []; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = clean($_POST['name'] ?? '');
        $description = clean($_POST['description'] ?? '');
        if (!$name) {
            $errors[] = 'Category name is required.';
        } else {
            $stmt = $conn->prepare("INSERT INTO crime_categories (name, description) VALUES (?,?)");
            $stmt->bind_param('ss', $name, $description);
            if ($stmt->execute()) { $success = 'Category added.'; }
            else { $errors[] = 'Category name must be unique.'; }
        }
    } elseif ($action === 'toggle') {
        $id = (int)$_POST['id'];
        $new_status = $_POST['current_status'] === 'Active' ? 'Inactive' : 'Active';
        $stmt = $conn->prepare("UPDATE crime_categories SET status=? WHERE id=?");
        $stmt->bind_param('si', $new_status, $id);
        $stmt->execute();
        $success = 'Category status updated.';
    } elseif ($action === 'edit') {
        $id = (int)$_POST['id'];
        $name = clean($_POST['name'] ?? '');
        $description = clean($_POST['description'] ?? '');
        if ($name) {
            $stmt = $conn->prepare("UPDATE crime_categories SET name=?, description=? WHERE id=?");
            $stmt->bind_param('ssi', $name, $description, $id);
            $stmt->execute();
            $success = 'Category updated.';
        }
    }
}

$rows = $conn->query("SELECT * FROM crime_categories ORDER BY name");
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="cr-card p-4">
      <h6 class="fw-bold mb-3">Add Category</h6>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
        <button class="btn btn-cr-solid w-100">Add Category</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="cr-card p-3">
      <div class="table-responsive">
        <table class="table cr-table align-middle mb-0">
          <thead><tr><th>Name</th><th>Description</th><th>Status</th><th></th></tr></thead>
          <tbody>
          <?php while ($c = $rows->fetch_assoc()):
            $editFormId = 'edit-cat-' . (int)$c['id'];
          ?>
            <tr>
                <td style="min-width:160px;">
                  <input type="text" form="<?= $editFormId ?>" name="name" class="form-control form-control-sm" value="<?= clean($c['name']) ?>">
                </td>
                <td>
                  <input type="text" form="<?= $editFormId ?>" name="description" class="form-control form-control-sm" value="<?= clean($c['description']) ?>">
                </td>
                <td><span class="badge bg-<?= $c['status']==='Active'?'success':'secondary' ?>"><?= clean($c['status']) ?></span></td>
                <td class="text-nowrap">
                  <form method="post" id="<?= $editFormId ?>" class="d-inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <button class="btn btn-sm btn-outline-primary">Save</button>
                  </form>
                  <form method="post" class="d-inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="toggle">
                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <input type="hidden" name="current_status" value="<?= clean($c['status']) ?>">
                    <button class="btn btn-sm btn-outline-<?= $c['status']==='Active'?'danger':'success' ?>"><?= $c['status']==='Active'?'Deactivate':'Activate' ?></button>
                  </form>
                </td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
