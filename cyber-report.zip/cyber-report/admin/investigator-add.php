<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('admin');
$page_title = 'Add Investigator';
$active = 'investigators';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean($_POST['name'] ?? '');
    $gender = clean($_POST['gender'] ?? 'Other');
    $dob = $_POST['dob'] ?? null;
    $phone = clean($_POST['phone'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $department = clean($_POST['department'] ?? '');
    $specialization = clean($_POST['specialization'] ?? '');
    $joining_date = $_POST['joining_date'] ?? date('Y-m-d');
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$name) $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (!preg_match('/^[a-zA-Z0-9_]{4,30}$/', $username)) $errors[] = 'Username must be 4-30 characters.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';

    if (!$errors) {
        $stmt = $conn->prepare("SELECT id FROM investigators WHERE username=? OR email=?");
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) $errors[] = 'Username or email already exists.';
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $dobVal = $dob ?: null;
        $stmt = $conn->prepare("INSERT INTO investigators (name, gender, dob, phone, email, address, department, specialization, joining_date, status, username, password) VALUES (?,?,?,?,?,?,?,?,?, 'Active', ?, ?)");
        $stmt->bind_param('sssssssssss', $name, $gender, $dobVal, $phone, $email, $address, $department, $specialization, $joining_date, $username, $hash);
        $stmt->execute();
        $_SESSION['flash_success'] = 'Investigator added successfully.';
        redirect('admin/investigators.php');
    }
}
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>

<div class="cr-card p-4" style="max-width:760px;">
  <form method="post" novalidate>
    <?= csrf_field() ?>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" required></div>
      <div class="col-md-3 mb-3"><label class="form-label">Gender</label>
        <select name="gender" class="form-select"><option>Male</option><option>Female</option><option>Other</option></select>
      </div>
      <div class="col-md-3 mb-3"><label class="form-label">Date of Birth</label><input type="date" name="dob" class="form-control"></div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" required></div>
    </div>
    <div class="mb-3"><label class="form-label">Address</label><input type="text" name="address" class="form-control"></div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Department/Unit</label><input type="text" name="department" class="form-control" value="Cyber Crime Unit"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Specialization</label><input type="text" name="specialization" class="form-control"></div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3"><label class="form-label">Joining Date</label><input type="date" name="joining_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
      <div class="col-md-6 mb-3"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
    </div>
    <div class="mb-3">
      <label class="form-label">Password</label>
      <div class="input-group">
        <input type="password" id="pwd1" name="password" class="form-control pwd-toggle-input" required>
        <button class="btn btn-outline-secondary pwd-toggle-btn" type="button" data-target="#pwd1">Show</button>
      </div>
    </div>
    <button type="submit" class="btn btn-cr-solid">Add Investigator</button>
    <a href="investigators.php" class="btn btn-outline-secondary">Cancel</a>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
