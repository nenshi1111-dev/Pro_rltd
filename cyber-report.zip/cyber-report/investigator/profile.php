<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('investigator');
$page_title = 'My Profile';
$active = 'profile';
$iid = current_id();
$errors = []; $success = '';

$stmt = $conn->prepare("SELECT * FROM investigators WHERE id=?");
$stmt->bind_param('i', $iid); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean($_POST['name'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $address = clean($_POST['address'] ?? '');

    if (!$name) $errors[] = 'Name is required.';

    if (!$errors) {
        $stmt = $conn->prepare("UPDATE investigators SET name=?, phone=?, address=? WHERE id=?");
        $stmt->bind_param('sssi', $name, $phone, $address, $iid);
        $stmt->execute();
        $_SESSION['user_name'] = $name;
        $success = 'Profile updated successfully.';
        $user = array_merge($user, compact('name', 'phone', 'address'));
    }
}
require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-4" style="max-width:640px;">
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label">Username</label><input type="text" class="form-control" value="<?= clean($user['username']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label">Email</label><input type="text" class="form-control" value="<?= clean($user['email']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label">Department</label><input type="text" class="form-control" value="<?= clean($user['department']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label">Specialization</label><input type="text" class="form-control" value="<?= clean($user['specialization']) ?>" disabled></div>
    <div class="mb-3"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" value="<?= clean($user['name']) ?>" required></div>
    <div class="mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control" value="<?= clean($user['phone']) ?>"></div>
    <div class="mb-3"><label class="form-label">Address</label><input type="text" name="address" class="form-control" value="<?= clean($user['address']) ?>"></div>
    <button type="submit" class="btn btn-cr-solid">Save Changes</button>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
