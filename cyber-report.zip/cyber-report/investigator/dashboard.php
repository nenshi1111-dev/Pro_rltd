<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('investigator');
$page_title = 'Investigator Dashboard';
$active = 'dashboard';
$iid = current_id();

// Assigned complaints = complaints where an active assignment exists for this investigator
$base = "FROM complaints c JOIN complaint_assignments ca ON ca.complaint_id = c.id AND ca.is_active = 1 JOIN crime_categories cc ON cc.id = c.category_id WHERE ca.investigator_id = ?";

function count_for($conn, $iid, $extra, $base) {
    $stmt = $conn->prepare("SELECT COUNT(*) c $base $extra");
    $stmt->bind_param('i', $iid);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['c'];
}

$assigned  = count_for($conn, $iid, '', $base);
$inProg    = count_for($conn, $iid, "AND c.status='Investigation In Progress'", $base);
$infoReq   = count_for($conn, $iid, "AND c.status='Additional Information Required'", $base);
$resolved  = count_for($conn, $iid, "AND c.status='Resolved'", $base);
$closed    = count_for($conn, $iid, "AND c.status='Closed'", $base);

$stmt = $conn->prepare("SELECT c.*, cc.name AS category_name $base ORDER BY c.updated_at DESC LIMIT 6");
$stmt->bind_param('i', $iid);
$stmt->execute();
$recent = $stmt->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$assigned ?></div><div class="lbl">Assigned</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$inProg ?></div><div class="lbl">In Progress</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$infoReq ?></div><div class="lbl">Info Required</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$resolved ?></div><div class="lbl">Resolved</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$closed ?></div><div class="lbl">Closed</div></div></div>
</div>

<h6 class="fw-bold mb-3">Recently Assigned Complaints</h6>
<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Ref No.</th><th>Title</th><th>Category</th><th>Status</th><th>Last Updated</th><th></th></tr></thead>
      <tbody>
        <?php if ($recent->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No complaints assigned yet.</td></tr>
        <?php endif; ?>
        <?php while ($r = $recent->fetch_assoc()): ?>
        <tr>
          <td><code><?= clean($r['complaint_number']) ?></code></td>
          <td><?= clean($r['title']) ?></td>
          <td><?= clean($r['category_name']) ?></td>
          <td><span class="badge bg-<?= status_badge_class($r['status']) ?> badge-status"><?= clean($r['status']) ?></span></td>
          <td><?= format_date($r['updated_at']) ?></td>
          <td><a href="complaint-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">Open</a></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
