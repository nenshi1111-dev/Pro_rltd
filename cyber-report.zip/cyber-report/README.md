# CYBER-REPORT
### Cyber Crime Reporting & Case Management System
**Tagline:** "Report. Track. Protect."
**Created by:** Rachna & Yagni

A college final-year project built with PHP, MySQL (mysqli), HTML, CSS, JavaScript,
Bootstrap 5, and Chart.js — no framework required.

---

## 1. Requirements

- XAMPP or WAMP (PHP 7.4+ / 8.x, MySQL/MariaDB)
- A browser

## 2. Installation

1. **Copy the project folder**
   Copy the whole `cyber-report` folder into your server's web root:
   - XAMPP: `C:\xampp\htdocs\cyber-report`
   - WAMP: `C:\wamp64\www\cyber-report`

2. **Start Apache and MySQL** from the XAMPP/WAMP control panel.

3. **Create the database**
   - Open `http://localhost/phpmyadmin` (XAMPP) or `http://localhost/adminer` / phpMyAdmin (WAMP).
   - Click **Import**, choose `sql/cyber_report.sql`, and run it.
   - This creates the `cyber_report` database, all tables, and dummy demo data.

4. **Check database credentials**
   Open `config/db.php` and confirm:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');   // WAMP often uses 'root' here — update if needed
   define('DB_NAME', 'cyber_report');
   ```

5. **Check the base URL**
   Open `config/functions.php` and confirm this matches your folder name:
   ```php
   define('BASE_URL', '/cyber-report/');
   ```

6. **Visit the site**
   `http://localhost/cyber-report/index.php`

## 3. Demo Login Credentials

| Role         | Username  | Password     |
|--------------|-----------|--------------|
| Admin        | admin     | Admin@123    |
| Citizen      | rahulm    | Citizen@123  |
| Investigator | vikramr   | Invest@123   |

(All dummy citizens use `Citizen@123`; all dummy investigators use `Invest@123`.)

If login ever fails with these credentials (rare cross-server bcrypt issue),
visit `http://localhost/cyber-report/reset_admin_password.php` once in your
browser to regenerate the admin hash correctly, then delete that file.

## 4. Folder Structure

```
cyber-report/
├── admin/              Admin panel pages
├── investigator/        Investigator panel pages
├── citizen/             Citizen panel pages
├── includes/             Shared header/footer/sidebar includes
├── assets/               CSS, JS
├── config/                db.php, functions.php (helpers, auth, CSRF)
├── uploads/
│   ├── evidence/         Uploaded complaint evidence (protected via .htaccess)
│   └── photos/           Reserved for profile photos
├── sql/cyber_report.sql   Full schema + dummy data
├── index.php, about.php, cyber-crimes.php, safety-tips.php,
│   complaint-guide.php, records.php, contact.php   Public site
├── register.php, login.php, logout.php
└── reset_admin_password.php   One-time utility (delete after use)
```

## 5. Key Features Implemented

- Role-based auth for Citizen / Investigator / Admin (separate tables & dashboards)
- Citizen: register, submit complaint with evidence upload, track status, respond to
  info requests, profile & password management
- Investigator: view only assigned complaints, add investigation updates, move status
  through the permitted workflow, profile & password management
- Admin: manage citizens, investigators (add/edit/activate/deactivate), assign
  complaints (assignment history preserved), manage crime categories, publish
  announcements, view reports/statistics with Chart.js, manage system settings
- Auto-generated complaint reference numbers (e.g. `CR2026000001`)
- Full status history log for every complaint
- Secure evidence upload: extension whitelist, blocked executable/script types,
  5 MB size limit, randomized stored filenames, `.htaccess` execution block
- CSRF tokens on all forms, prepared statements everywhere, `password_hash()` /
  `password_verify()`, `htmlspecialchars()` output escaping
- Public Records & Statistics page with live Chart.js visualizations (safe
  aggregate data only — no personal or case data)
- Search, filter, and pagination on all complaint listing screens

## 6. Notes

- This project intentionally implements **defensive** case-management functionality
  only — no offensive security tooling.
- Change `DB_PASS` and delete `reset_admin_password.php` before any public deployment.
