<?php
/**
 * CYBER-REPORT :: Database Connection
 * Update these values if your MySQL credentials differ (XAMPP/WAMP default shown).
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');       // WAMP default is often 'root' - change if needed
define('DB_NAME', 'cyber_report');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error .
        '<br>Make sure XAMPP/WAMP MySQL is running and the cyber_report database has been imported.');
}

$conn->set_charset('utf8mb4');
