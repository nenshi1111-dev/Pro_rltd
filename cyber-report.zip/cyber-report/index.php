<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Home';

$totalComplaints = $conn->query("SELECT COUNT(*) c FROM complaints")->fetch_assoc()['c'];
$resolvedCount   = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Resolved','Closed')")->fetch_assoc()['c'];
$citizenCount    = $conn->query("SELECT COUNT(*) c FROM citizens")->fetch_assoc()['c'];
$investigatorCount = $conn->query("SELECT COUNT(*) c FROM investigators WHERE status='Active'")->fetch_assoc()['c'];

$announcements = $conn->query("SELECT * FROM announcements WHERE audience IN ('public','all') ORDER BY created_at DESC LIMIT 3");

require_once __DIR__ . '/includes/header.php';
?>

<section class="cr-hero">
  <div class="container text-center">
    <h1 class="display-5 fw-bold cr-hero-fade">Report. Track. Protect.</h1>
    <p class="lead cr-hero-fade delay-1 mx-auto" style="max-width:640px;">
      A secure, organized online platform to report cyber crimes and track the progress
      of your complaint from submission to resolution.
    </p>
    <div class="cr-hero-fade delay-2 mt-4">
      <a href="<?= BASE_URL ?>register.php" class="btn btn-cr-solid btn-lg me-2">File a Complaint</a>
      <a href="<?= BASE_URL ?>records.php" class="btn btn-cr-outline btn-lg">View Public Records</a>
    </div>
  </div>
</section>

<section class="cr-stats-strip">
  <div class="container">
    <div class="row text-center g-4">
      <div class="col-6 col-md-3">
        <div class="cr-stat-num"><?= (int)$totalComplaints ?></div>
        <div class="small text-uppercase">Total Complaints</div>
      </div>
      <div class="col-6 col-md-3">
        <div class="cr-stat-num"><?= (int)$resolvedCount ?></div>
        <div class="small text-uppercase">Resolved / Closed</div>
      </div>
      <div class="col-6 col-md-3">
        <div class="cr-stat-num"><?= (int)$citizenCount ?></div>
        <div class="small text-uppercase">Registered Citizens</div>
      </div>
      <div class="col-6 col-md-3">
        <div class="cr-stat-num"><?= (int)$investigatorCount ?></div>
        <div class="small text-uppercase">Active Investigators</div>
      </div>
    </div>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="text-center mb-5 cr-reveal">
      <h2 class="cr-section-title">How Cyber-Report Helps You</h2>
      <p class="cr-section-sub">A complete case-management workflow, from complaint to closure.</p>
    </div>
    <div class="row g-4">
      <div class="col-md-4 cr-reveal">
        <div class="cr-card p-4">
          <div class="cr-icon-box">1</div>
          <h5>Submit Complaint</h5>
          <p class="text-muted small mb-0">Register and file your cyber crime complaint online with supporting evidence in minutes.</p>
        </div>
      </div>
      <div class="col-md-4 cr-reveal">
        <div class="cr-card p-4">
          <div class="cr-icon-box">2</div>
          <h5>Track Investigation</h5>
          <p class="text-muted small mb-0">Get a unique complaint number and follow every status change with a transparent history log.</p>
        </div>
      </div>
      <div class="col-md-4 cr-reveal">
        <div class="cr-card p-4">
          <div class="cr-icon-box">3</div>
          <h5>Get Resolution</h5>
          <p class="text-muted small mb-0">Assigned investigators work your case through to resolution with role-based confidentiality.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php if ($announcements && $announcements->num_rows > 0): ?>
<section class="py-5 bg-white">
  <div class="container">
    <div class="text-center mb-5 cr-reveal">
      <h2 class="cr-section-title">Latest Announcements</h2>
    </div>
    <div class="row g-4">
      <?php while ($a = $announcements->fetch_assoc()): ?>
      <div class="col-md-4 cr-reveal">
        <div class="cr-card p-4">
          <h6 class="fw-bold"><?= clean($a['title']) ?></h6>
          <p class="text-muted small"><?= clean($a['message']) ?></p>
          <div class="text-muted" style="font-size:.78rem;"><?= format_date($a['created_at']) ?></div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="py-5">
  <div class="container text-center cr-reveal">
    <h2 class="cr-section-title mb-3">Ready to report an incident?</h2>
    <p class="cr-section-sub mb-4">Registration takes less than two minutes.</p>
    <a href="<?= BASE_URL ?>register.php" class="btn btn-cr-solid btn-lg">Get Started</a>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
