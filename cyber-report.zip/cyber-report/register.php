<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Register';
if (is_logged_in()) redirect(current_role() . '/dashboard.php');

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $full_name = clean($_POST['full_name'] ?? '');
    $username  = clean($_POST['username'] ?? '');
    $email     = clean($_POST['email'] ?? '');
    $phone     = clean($_POST['phone'] ?? '');
    $address   = clean($_POST['address'] ?? '');
    $state     = clean($_POST['state'] ?? '');
    $password  = $_POST['password'] ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if (!$full_name) $errors[] = 'Full name is required.';
    if (!preg_match('/^[a-zA-Z0-9_]{4,30}$/', $username)) $errors[] = 'Username must be 4-30 characters (letters, numbers, underscore).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (!preg_match('/^[0-9]{10}$/', $phone)) $errors[] = 'Phone number must be 10 digits.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $stmt = $conn->prepare("SELECT id FROM citizens WHERE username=? OR email=? OR phone=?");
        $stmt->bind_param('sss', $username, $email, $phone);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $errors[] = 'Username, email, or phone is already registered.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO citizens (full_name, username, email, phone, password, address, state) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param('sssssss', $full_name, $username, $email, $phone, $hash, $address, $state);
        if ($stmt->execute()) {
            $_SESSION['flash_success'] = 'Registration successful. Please login.';
            redirect('login.php');
        } else {
            $errors[] = 'Something went wrong. Please try again.';
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<div class="cr-auth-wrap">
  <div class="cr-auth-card">
    <h3 class="fw-bold text-center mb-1">Create Citizen Account</h3>
    <p class="text-muted text-center small mb-4">Register to report and track cyber crime complaints.</p>

    <?php foreach ($errors as $e): ?>
      <div class="alert alert-danger py-2 small"><?= clean($e) ?></div>
    <?php endforeach; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="full_name" class="form-control" value="<?= clean($_POST['full_name'] ?? '') ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="<?= clean($_POST['username'] ?? '') ?>" required>
      </div>
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Email</label>
          <input type="email" name="email" class="form-control" value="<?= clean($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Phone</label>
          <input type="text" name="phone" class="form-control" maxlength="10" value="<?= clean($_POST['phone'] ?? '') ?>" required>
        </div>
      </div>
      <div class="row">
        <div class="col-md-8 mb-3">
          <label class="form-label">Address</label>
          <input type="text" name="address" class="form-control" value="<?= clean($_POST['address'] ?? '') ?>">
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">State</label>
          <input type="text" name="state" class="form-control" value="<?= clean($_POST['state'] ?? '') ?>">
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
          <input type="password" id="pwd1" name="password" class="form-control pwd-toggle-input" required>
          <button class="btn btn-outline-secondary pwd-toggle-btn" type="button" data-target="#pwd1">Show</button>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <div class="input-group">
          <input type="password" id="pwd2" name="confirm_password" class="form-control pwd-toggle-input" required>
          <button class="btn btn-outline-secondary pwd-toggle-btn" type="button" data-target="#pwd2">Show</button>
        </div>
      </div>
      <button type="submit" class="btn btn-cr-solid w-100">Register</button>
    </form>
    <p class="text-center small text-muted mt-3 mb-0">Already have an account? <a href="<?= BASE_URL ?>login.php">Login here</a></p>
  </div>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
