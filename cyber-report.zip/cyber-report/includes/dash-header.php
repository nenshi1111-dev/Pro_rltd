<?php
// Expects: $page_title, $active (menu key), require_login already called by caller
$role = current_role();
$site = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();

$menus = [
  'citizen' => [
    'dashboard'        => ['Dashboard', 'dashboard.php'],
    'submit-complaint' => ['Submit Complaint', 'submit-complaint.php'],
    'my-complaints'    => ['My Complaints', 'my-complaints.php'],
    'profile'          => ['Profile', 'profile.php'],
    'change-password'  => ['Change Password', 'change-password.php'],
  ],
  'investigator' => [
    'dashboard'        => ['Dashboard', 'dashboard.php'],
    'assigned'         => ['Assigned Complaints', 'assigned-complaints.php'],
    'profile'          => ['Profile', 'profile.php'],
    'change-password'  => ['Change Password', 'change-password.php'],
  ],
  'admin' => [
    'dashboard'      => ['Dashboard', 'dashboard.php'],
    'citizens'       => ['Citizens', 'citizens.php'],
    'investigators'  => ['Investigators', 'investigators.php'],
    'complaints'     => ['Complaints', 'complaints.php'],
    'categories'     => ['Crime Categories', 'crime-categories.php'],
    'announcements'  => ['Announcements', 'announcements.php'],
    'reports'        => ['Reports & Statistics', 'reports.php'],
    'settings'       => ['Settings', 'settings.php'],
    'profile'        => ['Profile', 'profile.php'],
    'change-password'=> ['Change Password', 'change-password.php'],
  ],
];
$menu = $menus[$role] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($page_title ?? 'Dashboard') ?> | <?= clean($site['site_name'] ?? 'Cyber-Report') ?></title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="d-flex">
  <div class="cr-sidebar" style="width:250px;flex-shrink:0;">
    <div class="cr-side-brand"><span class="cr-shield">&#128737;</span> Cyber-Report</div>
    <?php foreach ($menu as $key => $item): ?>
      <a href="<?= BASE_URL . $role . '/' . $item[1] ?>" class="<?= ($active ?? '') === $key ? 'active' : '' ?>"><?= clean($item[0]) ?></a>
    <?php endforeach; ?>
    <a href="<?= BASE_URL ?>logout.php" class="mt-3 text-danger">Logout</a>
  </div>
  <div class="flex-grow-1">
    <div class="cr-topbar">
      <div>
        <h5 class="mb-0"><?= clean($page_title ?? 'Dashboard') ?></h5>
        <div class="text-muted small text-capitalize"><?= clean($role) ?> Panel</div>
      </div>
      <div class="text-end">
        <div class="fw-semibold"><?= clean(current_name()) ?></div>
        <a href="<?= BASE_URL ?>index.php" class="small text-decoration-none">&larr; Back to site</a>
      </div>
    </div>
    <div class="cr-main">
