<footer class="cr-footer">
  <div class="container py-5">
    <div class="row g-4">
      <div class="col-lg-4">
        <h5 class="cr-brand"><span class="cr-shield">&#128737;</span> <?= clean($site['site_name'] ?? 'Cyber-Report') ?></h5>
        <p class="text-light-50 small"><?= clean($site['tagline'] ?? 'Report. Track. Protect.') ?></p>
        <p class="text-light-50 small">A secure platform for reporting and tracking cyber crime complaints.</p>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Quick Links</h6>
        <ul class="list-unstyled cr-footer-links">
          <li><a href="<?= BASE_URL ?>about.php">About</a></li>
          <li><a href="<?= BASE_URL ?>cyber-crimes.php">Cyber Crimes</a></li>
          <li><a href="<?= BASE_URL ?>safety-tips.php">Safety Tips</a></li>
          <li><a href="<?= BASE_URL ?>complaint-guide.php">Complaint Guide</a></li>
        </ul>
      </div>
      <div class="col-lg-2 col-6">
        <h6>Account</h6>
        <ul class="list-unstyled cr-footer-links">
          <li><a href="<?= BASE_URL ?>login.php">Login</a></li>
          <li><a href="<?= BASE_URL ?>register.php">Register</a></li>
          <li><a href="<?= BASE_URL ?>records.php">Public Records</a></li>
        </ul>
      </div>
      <div class="col-lg-4">
        <h6>Contact</h6>
        <ul class="list-unstyled cr-footer-links small">
          <li><?= clean($site['office_address'] ?? '') ?></li>
          <li><?= clean($site['contact_phone'] ?? '') ?></li>
          <li><?= clean($site['contact_email'] ?? '') ?></li>
          <li><?= clean($site['working_hours'] ?? '') ?></li>
        </ul>
      </div>
    </div>
    <hr class="border-secondary">
    <p class="text-center small text-light-50 mb-0">&copy; <?= date('Y') ?> <?= clean($site['site_name'] ?? 'Cyber-Report') ?>. College Final-Year Project by Rachna &amp; Yagni. For demonstration purposes only.</p>
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
