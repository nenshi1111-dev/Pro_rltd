<?php
// Expects optional $page_title
if (!isset($conn)) { require_once __DIR__ . '/../config/functions.php'; }
$site = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? clean($page_title) . ' | ' : '' ?><?= clean($site['site_name'] ?? 'Cyber-Report') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top cr-navbar">
  <div class="container">
    <a class="navbar-brand cr-brand" href="<?= BASE_URL ?>index.php">
      <i class="bi"></i><span class="cr-shield">&#128737;</span> <?= clean($site['site_name'] ?? 'Cyber-Report') ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>cyber-crimes.php">Cyber Crimes</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>safety-tips.php">Safety Tips</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>complaint-guide.php">Complaint Guide</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>records.php">Records &amp; Statistics</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>contact.php">Contact</a></li>
        <?php if (is_logged_in()): ?>
          <li class="nav-item ms-lg-2">
            <a class="btn btn-cr-outline btn-sm" href="<?= BASE_URL . current_role() ?>/dashboard.php">
              <?= clean(current_name()) ?> Dashboard
            </a>
          </li>
          <li class="nav-item ms-lg-2">
            <a class="btn btn-cr-solid btn-sm" href="<?= BASE_URL ?>logout.php">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item ms-lg-2"><a class="btn btn-cr-outline btn-sm" href="<?= BASE_URL ?>login.php">Login</a></li>
          <li class="nav-item ms-lg-2"><a class="btn btn-cr-solid btn-sm" href="<?= BASE_URL ?>register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
