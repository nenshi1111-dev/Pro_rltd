<?php
/**
 * ONE-TIME UTILITY: Reset the default admin password.
 *
 * The SQL dump ships with a bcrypt hash for "Admin@123". If for any reason
 * that hash doesn't work on your PHP/OpenSSL build, run this file once
 * from your browser (e.g. http://localhost/cyber-report/reset_admin_password.php)
 * to regenerate it correctly, then DELETE this file for security.
 */
require_once __DIR__ . '/config/db.php';

$newPassword = 'Admin@123';
$hash = password_hash($newPassword, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE admins SET password = ? WHERE username = 'admin'");
$stmt->bind_param('s', $hash);

if ($stmt->execute()) {
    echo "Admin password has been reset to: <b>{$newPassword}</b><br>";
    echo "Please <a href='login.php'>login</a> now, then delete this file (reset_admin_password.php) for security.";
} else {
    echo "Something went wrong: " . $conn->error;
}
