<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('citizen');
$cid = current_id();
$id = (int)($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT c.*, cc.name AS category_name FROM complaints c JOIN crime_categories cc ON cc.id=c.category_id WHERE c.id=? AND c.citizen_id=?");
$stmt->bind_param('ii', $id, $cid);
$stmt->execute();
$complaint = $stmt->get_result()->fetch_assoc();
if (!$complaint) { redirect('citizen/my-complaints.php'); }

$page_title = 'Complaint ' . $complaint['complaint_number'];
$active = 'my-complaints';
$errors = [];

// Citizen can add additional info when requested
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_info') {
    verify_csrf();
    $info = clean($_POST['additional_info'] ?? '');
    if ($info) {
        $stmt = $conn->prepare("UPDATE complaints SET additional_info = CONCAT(COALESCE(additional_info,''), '\n\n[Citizen update ', NOW(), ']: ', ?) WHERE id=?");
        $stmt->bind_param('si', $info, $id);
        $stmt->execute();
        change_complaint_status($conn, $id, 'Under Review', current_name(), 'citizen', 'Citizen provided additional information.');
        redirect('citizen/complaint-detail.php?id=' . $id);
    }
}

$evidence = $conn->prepare("SELECT * FROM evidence WHERE complaint_id=? ORDER BY uploaded_at DESC");
$evidence->bind_param('i', $id); $evidence->execute();
$evidence = $evidence->get_result();

$history = $conn->prepare("SELECT * FROM status_history WHERE complaint_id=? ORDER BY created_at ASC");
$history->bind_param('i', $id); $history->execute();
$history = $history->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="d-flex justify-content-between align-items-start mb-3">
  <div>
    <h5 class="mb-1"><?= clean($complaint['title']) ?></h5>
    <div class="text-muted small">Ref: <code><?= clean($complaint['complaint_number']) ?></code> &bull; Filed <?= format_date($complaint['created_at']) ?></div>
  </div>
  <span class="badge bg-<?= status_badge_class($complaint['status']) ?> badge-status fs-6"><?= clean($complaint['status']) ?></span>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Complaint Details</h6>
      <div class="row small mb-2"><div class="col-5 text-muted">Category</div><div class="col-7"><?= clean($complaint['category_name']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Incident Date/Time</div><div class="col-7"><?= format_date($complaint['incident_datetime']) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Location</div><div class="col-7"><?= clean($complaint['incident_location'] ?: '—') ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Platform</div><div class="col-7"><?= clean($complaint['platform'] ?: '—') ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Financial Loss</div><div class="col-7">₹<?= number_format($complaint['financial_loss'], 2) ?></div></div>
      <div class="row small mb-2"><div class="col-5 text-muted">Transaction Ref</div><div class="col-7"><?= clean($complaint['transaction_ref'] ?: '—') ?></div></div>
      <hr>
      <div class="mb-2"><span class="text-muted small">Description</span><p class="mb-0"><?= nl2br(clean($complaint['description'])) ?></p></div>
      <?php if ($complaint['additional_info']): ?>
        <div><span class="text-muted small">Additional Information</span><p class="mb-0"><?= nl2br(clean($complaint['additional_info'])) ?></p></div>
      <?php endif; ?>
    </div>

    <div class="cr-card p-4 mb-4">
      <h6 class="fw-bold mb-3">Evidence</h6>
      <?php if ($evidence->num_rows === 0): ?>
        <p class="text-muted small mb-0">No evidence uploaded.</p>
      <?php endif; ?>
      <ul class="list-unstyled small mb-0">
        <?php while ($e = $evidence->fetch_assoc()): ?>
          <li class="mb-1">&#128206; <?= clean($e['original_name']) ?> <span class="text-muted">(<?= strtoupper($e['file_type']) ?>, <?= round($e['file_size']/1024) ?> KB)</span></li>
        <?php endwhile; ?>
      </ul>
    </div>

    <?php if ($complaint['status'] === 'Additional Information Required'): ?>
    <div class="cr-card p-4 border border-warning">
      <h6 class="fw-bold mb-3 text-warning">Additional Information Requested</h6>
      <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add_info">
        <textarea name="additional_info" rows="3" class="form-control mb-3" placeholder="Provide the requested details..." required></textarea>
        <button class="btn btn-cr-solid btn-sm">Submit Information</button>
      </form>
    </div>
    <?php endif; ?>
  </div>

  <div class="col-lg-5">
    <div class="cr-card p-4">
      <h6 class="fw-bold mb-3">Status History</h6>
      <ul class="list-unstyled small">
        <?php while ($h = $history->fetch_assoc()): ?>
          <li class="mb-3 pb-3 border-bottom">
            <div><span class="badge bg-<?= status_badge_class($h['new_status']) ?> badge-status"><?= clean($h['new_status']) ?></span></div>
            <div class="text-muted mt-1"><?= format_date($h['created_at']) ?> by <?= clean($h['changed_by']) ?> (<?= clean($h['user_role']) ?>)</div>
            <?php if ($h['remarks']): ?><div class="mt-1"><?= clean($h['remarks']) ?></div><?php endif; ?>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
