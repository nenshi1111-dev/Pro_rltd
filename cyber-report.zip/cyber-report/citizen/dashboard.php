<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('citizen');
$page_title = 'Citizen Dashboard';
$active = 'dashboard';
$cid = current_id();

$total = $conn->prepare("SELECT COUNT(*) c FROM complaints WHERE citizen_id=?");
$total->bind_param('i', $cid); $total->execute();
$total = $total->get_result()->fetch_assoc()['c'];

$submitted = $conn->prepare("SELECT COUNT(*) c FROM complaints WHERE citizen_id=? AND status='Submitted'");
$submitted->bind_param('i', $cid); $submitted->execute();
$submitted = $submitted->get_result()->fetch_assoc()['c'];

$underInv = $conn->prepare("SELECT COUNT(*) c FROM complaints WHERE citizen_id=? AND status IN ('Under Review','Assigned','Investigation In Progress','Additional Information Required')");
$underInv->bind_param('i', $cid); $underInv->execute();
$underInv = $underInv->get_result()->fetch_assoc()['c'];

$resolved = $conn->prepare("SELECT COUNT(*) c FROM complaints WHERE citizen_id=? AND status='Resolved'");
$resolved->bind_param('i', $cid); $resolved->execute();
$resolved = $resolved->get_result()->fetch_assoc()['c'];

$closed = $conn->prepare("SELECT COUNT(*) c FROM complaints WHERE citizen_id=? AND status='Closed'");
$closed->bind_param('i', $cid); $closed->execute();
$closed = $closed->get_result()->fetch_assoc()['c'];

$recent = $conn->prepare("SELECT c.*, cc.name AS category_name FROM complaints c JOIN crime_categories cc ON cc.id=c.category_id WHERE c.citizen_id=? ORDER BY c.created_at DESC LIMIT 5");
$recent->bind_param('i', $cid); $recent->execute();
$recent = $recent->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<div class="row g-3 mb-4">
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$total ?></div><div class="lbl">Total</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$submitted ?></div><div class="lbl">Submitted</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$underInv ?></div><div class="lbl">Under Investigation</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$resolved ?></div><div class="lbl">Resolved</div></div></div>
  <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$closed ?></div><div class="lbl">Closed</div></div></div>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h6 class="fw-bold mb-0">Recent Complaints</h6>
  <a href="submit-complaint.php" class="btn btn-cr-solid btn-sm">+ Submit New Complaint</a>
</div>
<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Ref No.</th><th>Title</th><th>Category</th><th>Status</th><th>Filed On</th><th></th></tr></thead>
      <tbody>
        <?php if ($recent->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No complaints filed yet.</td></tr>
        <?php endif; ?>
        <?php while ($r = $recent->fetch_assoc()): ?>
        <tr>
          <td><code><?= clean($r['complaint_number']) ?></code></td>
          <td><?= clean($r['title']) ?></td>
          <td><?= clean($r['category_name']) ?></td>
          <td><span class="badge bg-<?= status_badge_class($r['status']) ?> badge-status"><?= clean($r['status']) ?></span></td>
          <td><?= format_date($r['created_at']) ?></td>
          <td><a href="complaint-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">View</a></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
