<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('citizen');
$page_title = 'My Complaints';
$active = 'my-complaints';
$cid = current_id();
$flash = $_SESSION['flash_success'] ?? ''; unset($_SESSION['flash_success']);

$search = clean($_GET['q'] ?? '');
$status_filter = clean($_GET['status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 8;

$where = "WHERE c.citizen_id = ?";
$params = [$cid]; $types = 'i';

if ($search !== '') {
    $where .= " AND (c.complaint_number LIKE ? OR c.title LIKE ?)";
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $types .= 'ss';
}
if ($status_filter !== '') {
    $where .= " AND c.status = ?";
    $params[] = $status_filter; $types .= 's';
}

$countStmt = $conn->prepare("SELECT COUNT(*) c FROM complaints c $where");
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalRows = $countStmt->get_result()->fetch_assoc()['c'];
$p = paginate($totalRows, $per_page, $page);

$sql = "SELECT c.*, cc.name AS category_name FROM complaints c JOIN crime_categories cc ON cc.id = c.category_id $where ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$types2 = $types . 'ii';
$params2 = array_merge($params, [$per_page, $p['offset']]);
$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$rows = $stmt->get_result();

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php if ($flash): ?><div class="alert alert-success py-2 small"><?= clean($flash) ?></div><?php endif; ?>

<div class="cr-card p-3 mb-3">
  <form class="row g-2" method="get">
    <div class="col-md-5">
      <input type="text" name="q" class="form-control" placeholder="Search by ref no. or title" value="<?= clean($search) ?>">
    </div>
    <div class="col-md-4">
      <select name="status" class="form-select">
        <option value="">All Statuses</option>
        <?php foreach (status_list() as $s): ?>
          <option value="<?= clean($s) ?>" <?= $status_filter === $s ? 'selected' : '' ?>><?= clean($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <button class="btn btn-cr-solid w-100" type="submit">Filter</button>
    </div>
  </form>
</div>

<div class="cr-card p-3">
  <div class="table-responsive">
    <table class="table cr-table align-middle mb-0">
      <thead><tr><th>Ref No.</th><th>Title</th><th>Category</th><th>Status</th><th>Filed On</th><th></th></tr></thead>
      <tbody>
        <?php if ($rows->num_rows === 0): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">No complaints found.</td></tr>
        <?php endif; ?>
        <?php while ($r = $rows->fetch_assoc()): ?>
        <tr>
          <td><code><?= clean($r['complaint_number']) ?></code></td>
          <td><?= clean($r['title']) ?></td>
          <td><?= clean($r['category_name']) ?></td>
          <td><span class="badge bg-<?= status_badge_class($r['status']) ?> badge-status"><?= clean($r['status']) ?></span></td>
          <td><?= format_date($r['created_at']) ?></td>
          <td><a href="complaint-detail.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary">View</a></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($p['total_pages'] > 1): ?>
<nav class="mt-3">
  <ul class="pagination justify-content-center">
    <?php for ($i = 1; $i <= $p['total_pages']; $i++): ?>
      <li class="page-item <?= $i === $p['current_page'] ? 'active' : '' ?>">
        <a class="page-link" href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>"><?= $i ?></a>
      </li>
    <?php endfor; ?>
  </ul>
</nav>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
