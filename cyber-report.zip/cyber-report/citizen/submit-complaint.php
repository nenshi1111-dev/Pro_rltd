<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('citizen');
$page_title = 'Submit Complaint';
$active = 'submit-complaint';
$cid = current_id();
$errors = [];

$categories = $conn->query("SELECT * FROM crime_categories WHERE status='Active' ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $category_id = (int)($_POST['category_id'] ?? 0);
    $title = clean($_POST['title'] ?? '');
    $incident_datetime = $_POST['incident_datetime'] ?? '';
    $incident_location = clean($_POST['incident_location'] ?? '');
    $platform = clean($_POST['platform'] ?? '');
    $financial_loss = (float)($_POST['financial_loss'] ?? 0);
    $transaction_ref = clean($_POST['transaction_ref'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $additional_info = clean($_POST['additional_info'] ?? '');

    if (!$category_id) $errors[] = 'Please select a crime category.';
    if (!$title) $errors[] = 'Title is required.';
    if (!$incident_datetime) $errors[] = 'Incident date/time is required.';
    if (!$description) $errors[] = 'Description is required.';

    if (!$errors) {
        $complaint_number = generate_complaint_number($conn);
        $stmt = $conn->prepare("INSERT INTO complaints (complaint_number, citizen_id, category_id, title, incident_datetime, incident_location, platform, financial_loss, transaction_ref, description, additional_info, status) VALUES (?,?,?,?,?,?,?,?,?,?,?, 'Submitted')");
        $stmt->bind_param('siissssdsss', $complaint_number, $cid, $category_id, $title, $incident_datetime, $incident_location, $platform, $financial_loss, $transaction_ref, $description, $additional_info);
        $stmt->execute();
        $complaint_id = $stmt->insert_id;

        change_complaint_status($conn, $complaint_id, 'Submitted', current_name(), 'citizen', 'Complaint submitted online.');

        // Evidence uploads (multiple files allowed)
        $evidenceErrors = [];
        if (!empty($_FILES['evidence']['name'][0])) {
            $count = count($_FILES['evidence']['name']);
            for ($i = 0; $i < $count; $i++) {
                if ($_FILES['evidence']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $file = [
                    'name' => $_FILES['evidence']['name'][$i],
                    'type' => $_FILES['evidence']['type'][$i],
                    'tmp_name' => $_FILES['evidence']['tmp_name'][$i],
                    'error' => $_FILES['evidence']['error'][$i],
                    'size' => $_FILES['evidence']['size'][$i],
                ];
                $res = handle_evidence_upload($conn, $complaint_id, $file);
                if (!$res['ok']) $evidenceErrors[] = $file['name'] . ': ' . $res['message'];
            }
        }

        $flash = "Complaint submitted successfully. Reference number: {$complaint_number}";
        if ($evidenceErrors) {
            $flash .= ' However, some files were not attached — ' . implode(' | ', $evidenceErrors);
        }
        $_SESSION['flash_success'] = $flash;
        redirect('citizen/my-complaints.php');
    }
}

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>

<div class="cr-card p-4">
  <form method="post" enctype="multipart/form-data" novalidate>
    <?= csrf_field() ?>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Complaint Title</label>
        <input type="text" name="title" class="form-control" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Crime Category</label>
        <select name="category_id" class="form-select" required>
          <option value="">Select category</option>
          <?php while ($c = $categories->fetch_assoc()): ?>
            <option value="<?= (int)$c['id'] ?>"><?= clean($c['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Incident Date &amp; Time</label>
        <input type="datetime-local" name="incident_datetime" class="form-control" required>
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Incident Location</label>
        <input type="text" name="incident_location" class="form-control" placeholder="City / Area">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">Website / App / Platform</label>
        <input type="text" name="platform" class="form-control" placeholder="e.g. Instagram, PhonePe">
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Financial Loss (₹, if any)</label>
        <input type="number" step="0.01" min="0" name="financial_loss" class="form-control" value="0">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Transaction Reference Number (if applicable)</label>
        <input type="text" name="transaction_ref" class="form-control">
      </div>
    </div>
    <div class="mb-3">
      <label class="form-label">Complaint Description</label>
      <textarea name="description" rows="4" class="form-control" required></textarea>
    </div>
    <div class="mb-3">
      <label class="form-label">Additional Information (optional)</label>
      <textarea name="additional_info" rows="2" class="form-control"></textarea>
    </div>
    <div class="mb-4">
      <label class="form-label">Supporting Evidence</label>
      <input type="file" name="evidence[]" class="form-control" multiple accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
      <div class="form-text">Allowed: JPG, PNG, PDF, DOC, DOCX. Max 5 MB per file.</div>
    </div>
    <button type="submit" class="btn btn-cr-solid">Submit Complaint</button>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
