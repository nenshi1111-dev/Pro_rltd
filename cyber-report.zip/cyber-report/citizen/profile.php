<?php
require_once __DIR__ . '/../config/functions.php';
require_role_prefix('citizen');
$page_title = 'My Profile';
$active = 'profile';
$cid = current_id();
$errors = []; $success = '';

$stmt = $conn->prepare("SELECT * FROM citizens WHERE id=?");
$stmt->bind_param('i', $cid); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $full_name = clean($_POST['full_name'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $state = clean($_POST['state'] ?? '');

    if (!$full_name) $errors[] = 'Full name is required.';
    if (!preg_match('/^[0-9]{10}$/', $phone)) $errors[] = 'Phone number must be 10 digits.';

    if (!$errors) {
        $stmt = $conn->prepare("UPDATE citizens SET full_name=?, phone=?, address=?, state=? WHERE id=?");
        $stmt->bind_param('ssssi', $full_name, $phone, $address, $state, $cid);
        $stmt->execute();
        $_SESSION['user_name'] = $full_name;
        $success = 'Profile updated successfully.';
        $user = array_merge($user, compact('full_name', 'phone', 'address', 'state'));
    }
}

require_once __DIR__ . '/../includes/dash-header.php';
?>
<?php foreach ($errors as $e): ?><div class="alert alert-danger py-2 small"><?= clean($e) ?></div><?php endforeach; ?>
<?php if ($success): ?><div class="alert alert-success py-2 small"><?= clean($success) ?></div><?php endif; ?>

<div class="cr-card p-4" style="max-width:640px;">
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input type="text" class="form-control" value="<?= clean($user['username']) ?>" disabled>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="text" class="form-control" value="<?= clean($user['email']) ?>" disabled>
    </div>
    <div class="mb-3">
      <label class="form-label">Full Name</label>
      <input type="text" name="full_name" class="form-control" value="<?= clean($user['full_name']) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Phone</label>
      <input type="text" name="phone" class="form-control" maxlength="10" value="<?= clean($user['phone']) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Address</label>
      <input type="text" name="address" class="form-control" value="<?= clean($user['address']) ?>">
    </div>
    <div class="mb-3">
      <label class="form-label">State</label>
      <input type="text" name="state" class="form-control" value="<?= clean($user['state']) ?>">
    </div>
    <button type="submit" class="btn btn-cr-solid">Save Changes</button>
  </form>
</div>
<?php require_once __DIR__ . '/../includes/dash-footer.php'; ?>
