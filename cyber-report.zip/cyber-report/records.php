<?php
require_once __DIR__ . '/config/functions.php';
$page_title = 'Records & Statistics';

$total    = $conn->query("SELECT COUNT(*) c FROM complaints")->fetch_assoc()['c'];
$pending  = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Submitted','Under Review')")->fetch_assoc()['c'];
$underInv = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status IN ('Assigned','Investigation In Progress','Additional Information Required')")->fetch_assoc()['c'];
$resolved = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Resolved'")->fetch_assoc()['c'];
$closed   = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Closed'")->fetch_assoc()['c'];
$rejected = $conn->query("SELECT COUNT(*) c FROM complaints WHERE status='Rejected'")->fetch_assoc()['c'];

// Status pie chart data
$statusRows = $conn->query("SELECT status, COUNT(*) cnt FROM complaints GROUP BY status");
$statusLabels = []; $statusData = [];
while ($r = $statusRows->fetch_assoc()) { $statusLabels[] = $r['status']; $statusData[] = (int)$r['cnt']; }

// Category chart data
$catRows = $conn->query("SELECT cc.name, COUNT(c.id) cnt FROM crime_categories cc LEFT JOIN complaints c ON c.category_id = cc.id GROUP BY cc.id ORDER BY cnt DESC");
$catLabels = []; $catData = [];
while ($r = $catRows->fetch_assoc()) { $catLabels[] = $r['name']; $catData[] = (int)$r['cnt']; }

// Monthly trend (last 12 months)
$trendRows = $conn->query("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, COUNT(*) cnt FROM complaints GROUP BY ym ORDER BY ym");
$trendLabels = []; $trendData = [];
while ($r = $trendRows->fetch_assoc()) { $trendLabels[] = $r['ym']; $trendData[] = (int)$r['cnt']; }

require_once __DIR__ . '/includes/header.php';
?>
<section class="cr-hero py-5">
  <div class="container text-center">
    <h1 class="fw-bold cr-hero-fade">Public Records &amp; Statistics</h1>
    <p class="lead cr-hero-fade delay-1">Live, aggregate cyber crime statistics. No personal or case-identifying data is shown.</p>
  </div>
</section>

<section class="py-5">
  <div class="container">
    <div class="row g-3 mb-5">
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$total ?></div><div class="lbl">Total Cases</div></div></div>
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$pending ?></div><div class="lbl">Pending</div></div></div>
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$underInv ?></div><div class="lbl">Under Investigation</div></div></div>
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$resolved ?></div><div class="lbl">Resolved</div></div></div>
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$closed ?></div><div class="lbl">Closed</div></div></div>
      <div class="col-6 col-md-2"><div class="cr-kpi text-center"><div class="num"><?= (int)$rejected ?></div><div class="lbl">Rejected</div></div></div>
    </div>

    <div class="row g-4">
      <div class="col-lg-6 cr-reveal">
        <div class="cr-card p-4">
          <h6 class="fw-bold mb-3">Cases by Status</h6>
          <canvas id="statusChart" height="220"></canvas>
        </div>
      </div>
      <div class="col-lg-6 cr-reveal">
        <div class="cr-card p-4">
          <h6 class="fw-bold mb-3">Cases by Crime Category</h6>
          <canvas id="catChart" height="220"></canvas>
        </div>
      </div>
      <div class="col-lg-12 cr-reveal">
        <div class="cr-card p-4">
          <h6 class="fw-bold mb-3">Monthly Complaint Trend</h6>
          <canvas id="trendChart" height="120"></canvas>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
const palette = ['#2563eb','#3b82f6','#0f1b45','#64748b','#22c55e','#f59e0b','#ef4444','#0ea5e9','#8b5cf6','#14b8a6','#eab308','#f97316'];

new Chart(document.getElementById('statusChart'), {
  type: 'pie',
  data: {
    labels: <?= json_encode($statusLabels) ?>,
    datasets: [{ data: <?= json_encode($statusData) ?>, backgroundColor: palette }]
  },
  options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } } } }
});

new Chart(document.getElementById('catChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($catLabels) ?>,
    datasets: [{ label: 'Cases', data: <?= json_encode($catData) ?>, backgroundColor: '#2563eb' }]
  },
  options: { indexAxis: 'y', plugins: { legend: { display: false } } }
});

new Chart(document.getElementById('trendChart'), {
  type: 'line',
  data: {
    labels: <?= json_encode($trendLabels) ?>,
    datasets: [{ label: 'Complaints', data: <?= json_encode($trendData) ?>, borderColor: '#2563eb', backgroundColor: 'rgba(37,99,235,.15)', fill: true, tension: .3 }]
  },
  options: { plugins: { legend: { display: false } } }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
