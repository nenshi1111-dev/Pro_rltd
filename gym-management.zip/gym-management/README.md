# Gym-Pro — Gym Management System (v4 — online payment verification)

A PHP + MySQL gym management system with a public website, an
Admin panel, a Trainer panel, and a Member panel. Members can
join **more than one batch** (as long as the timings don't
overlap). There is still no membership-plan/pricing concept — fee
is set per batch — and there is still no real payment gateway
integrated. What v4 adds is an online-payment *submission and
verification* flow: a member pays via the gym's own QR/UPI, submits
their transaction ID, and Admin verifies it before it's treated as
a real payment — on top of the access-control gate introduced in
v3, where a member approved via self-registration or self-renewal
can't reach their dashboard
until Admin has logged a payment covering what they owe.

Stack: PHP (procedural, mysqli, prepared statements), MySQL,
Bootstrap 5 + Bootstrap Icons (CDN), Chart.js (CDN, admin dashboard
graph only). No frameworks, no Composer — runs on plain XAMPP/WAMP/UwAmp.

**PHP version compatibility:** written to run on both modern PHP
(7.x/8.x, e.g. most XAMPP installs) AND old PHP 5.4.x (e.g. many
college lab UwAmp setups). `includes/compat.php` provides
`password_hash()`, `password_verify()`, and `array_column()` for
PHP versions older than 5.5 — it only activates if your PHP is too
old to have the real versions, so it's a no-op on modern PHP.

What's new, at a glance:
- **Online payment verification (v4)** — see section 4 below. QR
  code + UPI on the member's payment page, transaction ID
  submission, an admin notification bell entry, and a Verify/Reject
  queue. No amount or payment date is ever typed by anyone,
  anywhere in this flow — the amount is always calculated by the
  system, and the payment date is always today's server date.
- **Every path that creates or renews a member now goes through
  the payment gate, with no exceptions** — including Admin's own
  Add Member and Renew Member actions, which previously skipped
  straight to Active. Nothing sets a member Active without a
  logged or verified payment clearing their balance.
- **Payment gate (v3)** — see section 4 below.
- **Admin table simplified** to exactly 3 columns: `admin_id`,
  `admin_username`, `admin_password`. Login itself works exactly
  the same from the outside — you still type a username and
  password — only the database structure changed.
- **Equipment management removed entirely** — the module, its
  database table, and its dashboard card are all gone.
- **Age restriction** — registering (public or via Admin) now
  requires a date of birth showing the person is 18 or older; the
  date picker itself won't offer a too-recent date, and the server
  double-checks regardless.
- **Duration display** — every place a member's membership shows
  up (their dashboard, their Membership page, Admin's member
  detail view) now shows the duration as "3 Months (Sep 2026 - Dec
  2026)" instead of just a start/end date pair.
- Junction-table primary keys renamed for clarity — see section 5.

---

## 1. Setup (XAMPP/WAMP/UwAmp)

**Already have this project running with real data?** Don't
reimport `gym_pro.sql` (it will error on tables that already
exist). Instead, run these three files once, in order, in
phpMyAdmin's SQL tab:
1. `migration-add-payments.sql` — adds the `payments` table and
   `monthly_fee` column (skip this one if you already ran it
   before).
2. `migration-v3-payment-gate.sql` — renames the junction-table
   ID columns, adds the `Pending Payment` status, simplifies the
   `admins` table to 3 columns, adds the `gym_upi_id` setting, and
   drops the `equipment` table.
3. `migration-v4-online-payment.sql` — adds the
   `payment_submissions` table (the online payment verification
   queue described in section 4).

All three are safe to re-run — each step checks first and skips
anything already applied. See the comments inside each file for
details.

**Starting completely fresh?** Skip both migration files, just
follow the steps below — `gym_pro.sql` already includes
everything.


1. Copy the whole `gym-management` folder into your server's web
   root:
   - XAMPP (Windows/Mac/Linux): `htdocs/gym-management`
   - WAMP: `www/gym-management`
   - UwAmp: `www/gym-management` (usually on the E: or another
     drive, not C: — handy if your lab wipes C: on shutdown)
2. Start Apache and MySQL from the control panel.
3. Open phpMyAdmin (`http://localhost/phpmyadmin` for
   XAMPP/WAMP, or `http://localhost:PORT/mysql/` for UwAmp — check
   your UwAmp window for the exact port, commonly 81), click
   **Import**, choose `gym_pro.sql`, and run the import.
4. In your browser, visit
   `http://localhost[:PORT]/gym-management/seed-passwords.php`
   **once**, then delete that file.
5. Visit `http://localhost[:PORT]/gym-management/`.

**Database credentials:** `includes/config.php` defaults to
`root` / `root` (UwAmp's default). If you're on XAMPP or WAMP,
change `$db_pass` to `""` (blank) — that's the more common default
there. Either way, if login/phpMyAdmin worked with different
credentials for you, use those same ones in `config.php`.

---

## 2. Default login credentials (after step 4 above)

| Role    | URL                                | Username   | Password |
|---------|-------------------------------------|------------|----------|
| Admin   | `/admin/login.php`                 | `admin`    | `password` |
| Trainer | `/trainer/login.php`               | `trainer1` or `trainer2` | `password` |
| Member  | `/login.php`                       | `member1` or `member2`   | `password` |

Staff (Admin/Trainer) can also reach their login pages via the
**Staff Login** link at `/settings.php`.

---

## 3. How membership creation works (two paths)

- **Path A — Public self-registration:** a visitor fills out
  `/register.php`, selecting one or more batches (grouped by
  Morning/Evening, overlap-blocked, capped at
  `max_batches_per_member` from the `settings` table — 3 by
  default). This creates a row in `requested_members` with
  `status='Pending'` plus their chosen batches in
  `requested_member_batches` — it does NOT create a login yet. An
  Admin reviews it under **Admin → Registration Requests**, and
  only on **Approve** does a real row get created in `members`
  (with an auto-generated code like `GM0003`) plus their batch
  links in `member_batches` — but their login lands them on a
  **payment page**, not the dashboard, until Admin logs a payment
  covering what they owe. See section 4 below.
- **Path B — Admin adds directly:** Admin → Members → Add Member
  creates the member immediately with the selected batches, no
  approval step to wait for — but status still starts as
  **Pending Payment**, not Active. This is deliberate: **no path
  anywhere in the system sets a member Active without a logged or
  verified payment**, so Admin adding someone directly doesn't skip
  that rule just because it's faster than the request queue. Admin
  logs the payment right after (Admin → Payments → Log Payment,
  which shows the exact amount owed — nothing to type), or the
  member can pay online themselves via their own Pending Payment
  page. Admin's manual **Renew Member** action works the same way —
  it updates batches/expiry immediately but also lands the member
  back in Pending Payment until a payment clears it.

Renewal submitted by a member (rather than done by Admin directly)
works the same way as registration: a member re-picks their
batches (and a duration) from their dashboard — this can mean
staying in the same batches, dropping one, or switching entirely.
It lands in **Admin → Renewal Requests**; approving it replaces the
member's `member_batches` rows with what was requested, extends
`membership_expiry_date` — and puts them into the same
payment-gated state described above.

---

## 4. Payment gate (Pending Payment status)

A member's `status` column can be `'Pending Payment'`, in addition
to `Active` / `Expired` / `Inactive`. Every path that creates or
renews a member lands here first — self-registration, self-renewal,
and Admin's own Add Member / Renew Member actions all go through
it identically. There are **two separate ways** a Pending Payment
member actually gets paid, and they meet at the same place:

**Path 1 — Online (member self-submits, needs verification).**
The member's `member/pending-payment.php` page shows only *online*
payment — a scannable QR code and the gym's UPI ID (both built from
the `gym_upi_id` setting, rendered client-side with the qrcodejs
library so no server-side image generation is needed). **The member
never types an amount, anywhere** — the page displays the system's
own calculation of what's owed (`get_member_pending_balance()`),
and that's the only number in play. After paying via their own UPI
app, the member submits just two things: the Transaction ID/UTR and
the date they paid. This creates a row in the new
`payment_submissions` table with `status='Pending Verification'` —
**this alone does NOT activate anything**. It only queues the claim
for Admin to check.

**Path 2 — Manual (member pays Admin in person, no verification
needed).** Admin → Payments → Log Payment, for when a member pays
cash or shows Admin a completed UPI transfer directly. Admin never
types an amount here either — the form shows the member's pending
balance read-only, Admin just confirms the date/method and submits.
No notification is generated for this path, since Admin is doing it
themselves in the same moment.

**How verification works (Path 1 only):** every pending submission
shows up in the Admin notification bell (top of every admin page)
and in **Admin → Online Payment Requests**. Opening one shows the
member, amount, and transaction ID for Admin to check against the
gym's real UPI account, then either **Verify** (creates the actual
row in `payments` using the exact snapshotted amount — never
re-typed) or **Reject** (with an optional reason the member sees,
after which they can submit again).

**How it unlocks either way:** the moment a real `payments` row
brings the member's pending balance to zero —
`sync_member_payment_status()` in `includes/payment-functions.php`
— their status flips to `Active` automatically. The same check also
runs defensively every time the member's own pages load, as a
safety net.

**Partial payment is not supported anywhere in this flow** — every
amount, on both paths, is always the member's full remaining
balance at that moment, never a smaller manually-entered figure.

**Pages reachable while Pending Payment:** the payment page itself,
Change Password, and Logout — mirroring exactly how the existing
Expired-member restriction already worked (see
`member/includes/auth.php`, `$allow_restricted`).

---

## 5. Multi-batch selection & overlap prevention

This is the headline feature of v2. Wherever someone picks
batches — public registration, Admin add/edit member, Admin manual
renewal, member self-renewal — they see the exact same widget:
batches grouped into **Morning** / **Evening** (derived
automatically from each batch's start time, not a separate field
an admin has to set), with checkboxes.

Two rules are enforced, both **server-side** (the client-side JS
that greys out conflicting boxes is just a convenience layer, not
the real gate):

1. **No time overlap.** If two selected batches' times overlap at
   all — not just an exact match — the submission is rejected with
   a clear message naming both batches. Test this immediately with
   the dummy data: "Morning Yoga" and "Morning Strength" are both
   06:00-07:00.
2. **Max batches per member.** Configurable via the `settings`
   table (`max_batches_per_member`, default `3`) — change the value
   there and every picker across the whole site picks it up
   automatically, no code changes needed.

Both rules are also **re-checked at approval time**, not just when
the member first submits — because a batch's schedule or fill
level could change in the time between a member requesting it and
Admin approving it.

---

## 6. Folder structure

```
gym-management/
├── gym_pro.sql              ← import this first
├── seed-passwords.php       ← run once, then delete
├── includes/                ← shared DB config + public header/nav/footer
│   └── batch-functions.php  ← overlap detection + Morning/Evening grouping
│                                (used by register.php, admin add/edit/renew
│                                member, member renew-request.php — one
│                                shared source of truth, never duplicated)
├── css/, js/                ← public site theme + password-eye-toggle +
│                                batch-picker overlap/max guard script
├── index.php, about.php, batches.php, gallery.php, contact.php
├── login.php, register.php, logout.php   ← member auth (public root)
├── settings.php             ← staff login chooser (Admin/Trainer)
├── admin/
│   ├── includes/            ← admin-only header/sidebar/topbar/footer/auth
│   ├── member/  trainer/  batch/  equipment/  announcement/
│   ├── request/registration_request/   request/renewable_request/
│   └── settings/settings.php (change password)
├── trainer/
│   ├── includes/
│   ├── batch/  settings/
│   └── index.php, my-members.php, today-schedule.php, workout-plan.php, announcements.php, profile.php
└── member/
    ├── includes/
    └── index.php, profile.php, membership.php, expired.php,
        renew-request.php, renew-status.php, my-batch.php,
        announcement.php, change-password.php, logout.php
```

Each panel (admin/trainer/member) has its **own** `includes/`,
`css/`, `js/` — they don't share PHP includes across panels, only
the root `css/style.css` for the common visual theme and the root
`includes/batch-functions.php` for the batch-selection logic
(pulled in directly by every page that needs it, regardless of
which panel it's in).

---

## 7. Security notes already built in

- All queries use `mysqli` **prepared statements** — no raw string
  concatenation into SQL.
- Passwords are stored with `password_hash()` / verified with
  `password_verify()` — never plain text.
- Every panel has a session guard (`includes/auth.php`) that
  redirects to that panel's login page if not authenticated.
- A trainer can only see/edit batches actually assigned to them
  (checked server-side, not just hidden in the UI).
- An **Expired** member is redirected to `expired.php` from every
  other member page until they renew — enforced in
  `member/includes/auth.php`, not just by hiding menu links.
- A batch can't be deleted while members are still assigned to it
  (checked via the `member_batches` junction table).
- Registration/renewal approval re-checks uniqueness (username /
  email / phone), batch **time-overlap**, and batch **capacity** at
  approval time — not just at submission time, since either could
  have changed in the gap between a member submitting a request and
  Admin approving it.
- The overlap rule is a genuine interval-overlap check (does one
  batch start before the other ends, in both directions), not a
  same-start-time check — so two batches that partially overlap
  (e.g. 6:00-7:00 and 6:30-7:30) are correctly blocked too, not
  just exact time matches.
- The client-side JS that disables conflicting checkboxes is a
  convenience layer only. The real, authoritative check always runs
  server-side in `find_batch_conflict()` — someone could disable
  JavaScript and it still can't be bypassed.

---

## 8. What to extend first

1. **Real photo uploads** — `members.photo` / `trainers.photo`
   columns exist but the forms don't handle file uploads yet.
   Add a multipart form + `move_uploaded_file()` in add/edit
   member and trainer pages.
2. **Attendance marking UI** — the `attendance` table exists with
   sample data, but there's no page yet for a trainer to mark daily
   attendance for their batch. That's a natural next module:
   `trainer/attendance.php` with a checkbox list per batch/day.
3. **Email/SMS notifications** — hook a mail library into the
   approve/reject actions (registration + renewal) so members get
   notified automatically instead of having to check the site.
4. **Contact form persistence** — `contact.php` currently just
   shows a success message; add a `contact_messages` table and an
   admin inbox page if you want to actually track/reply to these.
5. **Pagination** — member/trainer/request list tables will get
   long; add simple `LIMIT`/`OFFSET` pagination once you have more
   than ~50 rows in any list.

---

Created By: Nenshi Pal
