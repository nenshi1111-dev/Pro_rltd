# Gym-Pro — Gym Management System (v2 — multi-batch, no plans)

A PHP + MySQL gym management system with a public website, an
Admin panel, a Trainer panel, and a Member panel. Members can
join **more than one batch** (as long as the timings don't
overlap) — there is no membership-plan/pricing concept anywhere
in the system; payment is handled directly between Admin and
Member, outside the software.

Stack: PHP (procedural, mysqli, prepared statements), MySQL,
Bootstrap 5 + Bootstrap Icons (CDN), Chart.js (CDN, admin dashboard
graph only). No frameworks, no Composer — runs on plain XAMPP/WAMP/UwAmp.

**PHP version compatibility:** written to run on both modern PHP
(7.x/8.x, e.g. most XAMPP installs) AND old PHP 5.4.x (e.g. many
college lab UwAmp setups). `includes/compat.php` provides
`password_hash()`, `password_verify()`, and `array_column()` for
PHP versions older than 5.5 — it only activates if your PHP is too
old to have the real versions, so it's a no-op on modern PHP.

---

## 1. Setup (XAMPP/WAMP/UwAmp)

1. Copy the whole `gym-management` folder into your server's web
   root:
   - XAMPP (Windows/Mac/Linux): `htdocs/gym-management`
   - WAMP: `www/gym-management`
   - UwAmp: `www/gym-management` (usually on the E: or another
     drive, not C: — handy if your lab wipes C: on shutdown)
2. Start Apache and MySQL from the control panel.
3. Open phpMyAdmin (`http://localhost/phpmyadmin` for
   XAMPP/WAMP, or `http://localhost:PORT/mysql/` for UwAmp — check
   your UwAmp window for the exact port, commonly 81), click
   **Import**, choose `gym_pro.sql`, and run the import.
4. In your browser, visit
   `http://localhost[:PORT]/gym-management/seed-passwords.php`
   **once**, then delete that file.
5. Visit `http://localhost[:PORT]/gym-management/`.

**Database credentials:** `includes/config.php` defaults to
`root` / `root` (UwAmp's default). If you're on XAMPP or WAMP,
change `$db_pass` to `""` (blank) — that's the more common default
there. Either way, if login/phpMyAdmin worked with different
credentials for you, use those same ones in `config.php`.

---

## 2. Default login credentials (after step 4 above)

| Role    | URL                                | Username   | Password |
|---------|-------------------------------------|------------|----------|
| Admin   | `/admin/login.php`                 | `admin`    | `password` |
| Trainer | `/trainer/login.php`               | `trainer1` or `trainer2` | `password` |
| Member  | `/login.php`                       | `member1` or `member2`   | `password` |

Staff (Admin/Trainer) can also reach their login pages via the
**Staff Login** link at `/settings.php`.

---

## 3. How membership creation works (two paths)

- **Path A — Public self-registration:** a visitor fills out
  `/register.php`, selecting one or more batches (grouped by
  Morning/Evening, overlap-blocked, capped at
  `max_batches_per_member` from the `settings` table — 3 by
  default). This creates a row in `requested_members` with
  `status='Pending'` plus their chosen batches in
  `requested_member_batches` — it does NOT create a login yet. An
  Admin reviews it under **Admin → Registration Requests**, and
  only on **Approve** does a real row get created in `members`
  (with an auto-generated code like `GM0003`) plus their batch
  links in `member_batches`, which is the moment the person can
  actually log in.
- **Path B — Admin adds directly:** Admin → Members → Add Member
  creates an Active member immediately with the selected batches,
  no approval step.

Renewal works the same way: a member re-picks their batches (and a
duration) from their dashboard — this can mean staying in the same
batches, dropping one, or switching entirely. It lands in
**Admin → Renewal Requests**; approving it replaces the member's
`member_batches` rows with what was requested and extends
`membership_expiry_date`.

---

## 4. Multi-batch selection & overlap prevention

This is the headline feature of v2. Wherever someone picks
batches — public registration, Admin add/edit member, Admin manual
renewal, member self-renewal — they see the exact same widget:
batches grouped into **Morning** / **Evening** (derived
automatically from each batch's start time, not a separate field
an admin has to set), with checkboxes.

Two rules are enforced, both **server-side** (the client-side JS
that greys out conflicting boxes is just a convenience layer, not
the real gate):

1. **No time overlap.** If two selected batches' times overlap at
   all — not just an exact match — the submission is rejected with
   a clear message naming both batches. Test this immediately with
   the dummy data: "Morning Yoga" and "Morning Strength" are both
   06:00-07:00.
2. **Max batches per member.** Configurable via the `settings`
   table (`max_batches_per_member`, default `3`) — change the value
   there and every picker across the whole site picks it up
   automatically, no code changes needed.

Both rules are also **re-checked at approval time**, not just when
the member first submits — because a batch's schedule or fill
level could change in the time between a member requesting it and
Admin approving it.

---

## 5. Folder structure

```
gym-management/
├── gym_pro.sql              ← import this first
├── seed-passwords.php       ← run once, then delete
├── includes/                ← shared DB config + public header/nav/footer
│   └── batch-functions.php  ← overlap detection + Morning/Evening grouping
│                                (used by register.php, admin add/edit/renew
│                                member, member renew-request.php — one
│                                shared source of truth, never duplicated)
├── css/, js/                ← public site theme + password-eye-toggle +
│                                batch-picker overlap/max guard script
├── index.php, about.php, batches.php, gallery.php, contact.php
├── login.php, register.php, logout.php   ← member auth (public root)
├── settings.php             ← staff login chooser (Admin/Trainer)
├── admin/
│   ├── includes/            ← admin-only header/sidebar/topbar/footer/auth
│   ├── member/  trainer/  batch/  equipment/  announcement/
│   ├── request/registration_request/   request/renewable_request/
│   └── settings/settings.php (change password)
├── trainer/
│   ├── includes/
│   ├── batch/  settings/
│   └── index.php, my-members.php, today-schedule.php, workout-plan.php, announcements.php, profile.php
└── member/
    ├── includes/
    └── index.php, profile.php, membership.php, expired.php,
        renew-request.php, renew-status.php, my-batch.php,
        announcement.php, change-password.php, logout.php
```

Each panel (admin/trainer/member) has its **own** `includes/`,
`css/`, `js/` — they don't share PHP includes across panels, only
the root `css/style.css` for the common visual theme and the root
`includes/batch-functions.php` for the batch-selection logic
(pulled in directly by every page that needs it, regardless of
which panel it's in).

---

## 6. Security notes already built in

- All queries use `mysqli` **prepared statements** — no raw string
  concatenation into SQL.
- Passwords are stored with `password_hash()` / verified with
  `password_verify()` — never plain text.
- Every panel has a session guard (`includes/auth.php`) that
  redirects to that panel's login page if not authenticated.
- A trainer can only see/edit batches actually assigned to them
  (checked server-side, not just hidden in the UI).
- An **Expired** member is redirected to `expired.php` from every
  other member page until they renew — enforced in
  `member/includes/auth.php`, not just by hiding menu links.
- A batch can't be deleted while members are still assigned to it
  (checked via the `member_batches` junction table).
- Registration/renewal approval re-checks uniqueness (username /
  email / phone), batch **time-overlap**, and batch **capacity** at
  approval time — not just at submission time, since either could
  have changed in the gap between a member submitting a request and
  Admin approving it.
- The overlap rule is a genuine interval-overlap check (does one
  batch start before the other ends, in both directions), not a
  same-start-time check — so two batches that partially overlap
  (e.g. 6:00-7:00 and 6:30-7:30) are correctly blocked too, not
  just exact time matches.
- The client-side JS that disables conflicting checkboxes is a
  convenience layer only. The real, authoritative check always runs
  server-side in `find_batch_conflict()` — someone could disable
  JavaScript and it still can't be bypassed.

---

## 7. What to extend first

1. **Real photo uploads** — `members.photo` / `trainers.photo`
   columns exist but the forms don't handle file uploads yet.
   Add a multipart form + `move_uploaded_file()` in add/edit
   member and trainer pages.
2. **Attendance marking UI** — the `attendance` table exists with
   sample data, but there's no page yet for a trainer to mark daily
   attendance for their batch. That's a natural next module:
   `trainer/attendance.php` with a checkbox list per batch/day.
3. **Email/SMS notifications** — hook a mail library into the
   approve/reject actions (registration + renewal) so members get
   notified automatically instead of having to check the site.
4. **Contact form persistence** — `contact.php` currently just
   shows a success message; add a `contact_messages` table and an
   admin inbox page if you want to actually track/reply to these.
5. **Pagination** — member/trainer/request list tables will get
   long; add simple `LIMIT`/`OFFSET` pagination once you have more
   than ~50 rows in any list.

---

Created By: Nenshi Pal
