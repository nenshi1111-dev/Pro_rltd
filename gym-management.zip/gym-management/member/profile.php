<?php
// ==========================================================
// member/profile.php — Member's own profile
// Phone and Address are editable here. Everything else (name,
// gender, DOB, email, emergency contact) stays read-only —
// contact Admin to change those.
// ==========================================================
require_once "../includes/config.php";
require_once "includes/auth.php";

$page_title = "My Profile";
$active_menu = "profile";
$member_id = $_SESSION['member_id'];
$error_msg = "";
$success_msg = "";

$stmt = mysqli_prepare($conn, "SELECT * FROM members WHERE member_id=?");
mysqli_stmt_bind_param($stmt, "i", $member_id);
mysqli_stmt_execute($stmt);
$member = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim((isset($_POST['phone']) ? $_POST['phone'] : ''));
    $address = trim((isset($_POST['address']) ? $_POST['address'] : ''));

    if ($phone === '') {
        $error_msg = "Phone number cannot be empty.";
    } else {
        // Phone must stay unique across members — check excluding this member's own row
        $chk = mysqli_prepare($conn, "SELECT 1 FROM members WHERE phone=? AND member_id<>?");
        mysqli_stmt_bind_param($chk, "si", $phone, $member_id);
        mysqli_stmt_execute($chk);
        if (mysqli_num_rows(mysqli_stmt_get_result($chk)) > 0) {
            $error_msg = "That phone number is already in use by another member.";
        } else {
            $upd = mysqli_prepare($conn, "UPDATE members SET phone=?, address=? WHERE member_id=?");
            mysqli_stmt_bind_param($upd, "ssi", $phone, $address, $member_id);
            if (mysqli_stmt_execute($upd)) {
                $success_msg = "Profile updated successfully.";
                $member['phone'] = $phone;
                $member['address'] = $address;
            } else {
                $error_msg = "Could not update your profile. Please try again.";
            }
        }
    }
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<?php if ($error_msg): ?><div class="alert alert-danger auto-hide-alert"><?php echo htmlspecialchars($error_msg); ?></div><?php endif; ?>
<?php if ($success_msg): ?><div class="alert alert-success auto-hide-alert"><?php echo htmlspecialchars($success_msg); ?></div><?php endif; ?>

<div class="gym-card p-4" style="max-width:600px;">
    <h4><?php echo htmlspecialchars($member['full_name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($member['member_code']); ?>)</small></h4>
    <table class="table table-borderless mt-3">
        <tr><th style="width:180px;">Gender</th><td><?php echo htmlspecialchars($member['gender']); ?></td></tr>
        <tr><th>Date of Birth</th><td><?php echo htmlspecialchars($member['dob']); ?></td></tr>
        <tr><th>Email</th><td><?php echo htmlspecialchars($member['email']); ?></td></tr>
        <tr><th>Emergency Contact</th><td><?php echo htmlspecialchars($member['emergency_contact']); ?></td></tr>
    </table>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" required value="<?php echo htmlspecialchars($member['phone']); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo htmlspecialchars($member['address']); ?>">
        </div>
        <button type="submit" class="btn btn-gym-primary">Save Changes</button>
    </form>

    <p class="text-muted small mt-3">To change your name, gender, date of birth, or email, please speak with Admin.
       You can change your password from the Change Password menu.</p>
</div>

<?php include "includes/footer.php"; ?>
