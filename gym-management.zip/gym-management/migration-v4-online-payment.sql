-- ==========================================================
-- migration-v4-online-payment.sql
-- Run this ONCE in phpMyAdmin -> gym_pro -> SQL tab, on a
-- database that already has the payment-gate schema (from
-- migration-v3-payment-gate.sql or a fresh v3 import).
--
-- Adds the online-payment submission queue: a member on the
-- Pending Payment page submits a Transaction ID/UTR after
-- paying via the gym's QR/UPI, and it lands here awaiting
-- Admin verification — nothing is treated as a real payment
-- until Admin verifies it.
--
-- If you're starting completely fresh, skip this file — just
-- import gym_pro.sql, which already includes everything below.
--
-- Safe to run more than once.
-- ==========================================================

CREATE TABLE IF NOT EXISTS payment_submissions (
    submission_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    transaction_id VARCHAR(100) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method VARCHAR(20) NOT NULL DEFAULT 'UPI',
    status ENUM('Pending Verification','Verified','Rejected') DEFAULT 'Pending Verification',
    reject_reason VARCHAR(255),
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_by INT NULL,
    verified_at DATETIME NULL,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES admins(admin_id) ON DELETE SET NULL
);

-- ==========================================================
-- That's it — no other schema changes needed. The Admin
-- "Log Payment" page (for in-person payments) and the member's
-- Pending Payment page (for online submissions) both already
-- calculate the amount automatically from existing tables;
-- this migration only adds the new queue table between them.
-- ==========================================================
