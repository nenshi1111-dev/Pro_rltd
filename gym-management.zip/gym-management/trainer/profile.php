<?php
// ==========================================================
// trainer/profile.php — Trainer's own profile
// Phone is editable here. Address is NOT editable because the
// trainers table has no address column at all (unlike members) —
// adding one would mean changing the database, which was
// explicitly out of scope for this change. Everything else
// (name, gender, email, specialization) stays read-only —
// contact Admin to change those.
// ==========================================================
require_once "../includes/config.php";
require_once "includes/auth.php";

$page_title = "My Profile";
$active_menu = "profile";
$trainer_id = $_SESSION['trainer_id'];
$error_msg = "";
$success_msg = "";

$stmt = mysqli_prepare($conn, "SELECT * FROM trainers WHERE trainer_id=?");
mysqli_stmt_bind_param($stmt, "i", $trainer_id);
mysqli_stmt_execute($stmt);
$trainer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim((isset($_POST['phone']) ? $_POST['phone'] : ''));

    if ($phone === '') {
        $error_msg = "Phone number cannot be empty.";
    } else {
        $chk = mysqli_prepare($conn, "SELECT 1 FROM trainers WHERE phone=? AND trainer_id<>?");
        mysqli_stmt_bind_param($chk, "si", $phone, $trainer_id);
        mysqli_stmt_execute($chk);
        if (mysqli_num_rows(mysqli_stmt_get_result($chk)) > 0) {
            $error_msg = "That phone number is already in use by another trainer.";
        } else {
            $upd = mysqli_prepare($conn, "UPDATE trainers SET phone=? WHERE trainer_id=?");
            mysqli_stmt_bind_param($upd, "si", $phone, $trainer_id);
            if (mysqli_stmt_execute($upd)) {
                $success_msg = "Profile updated successfully.";
                $trainer['phone'] = $phone;
            } else {
                $error_msg = "Could not update your profile. Please try again.";
            }
        }
    }
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<?php if ($error_msg): ?><div class="alert alert-danger auto-hide-alert"><?php echo htmlspecialchars($error_msg); ?></div><?php endif; ?>
<?php if ($success_msg): ?><div class="alert alert-success auto-hide-alert"><?php echo htmlspecialchars($success_msg); ?></div><?php endif; ?>

<div class="gym-card p-4" style="max-width:600px;">
    <h4><?php echo htmlspecialchars($trainer['full_name']); ?> <small class="text-muted">(<?php echo htmlspecialchars($trainer['trainer_code']); ?>)</small></h4>
    <table class="table table-borderless mt-3">
        <tr><th style="width:180px;">Gender</th><td><?php echo htmlspecialchars($trainer['gender']); ?></td></tr>
        <tr><th>Email</th><td><?php echo htmlspecialchars($trainer['email']); ?></td></tr>
        <tr><th>Specialization</th><td><?php echo htmlspecialchars($trainer['specialization']); ?></td></tr>
        <tr><th>Status</th><td><span class="badge <?php echo $trainer['status']=='Active'?'badge-active':'badge-inactive'; ?>"><?php echo htmlspecialchars($trainer['status']); ?></span></td></tr>
    </table>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" required value="<?php echo htmlspecialchars($trainer['phone']); ?>">
        </div>
        <button type="submit" class="btn btn-gym-primary">Save Changes</button>
    </form>

    <p class="text-muted small mt-3">To change your name, gender, email, or specialization, please ask Admin.
       You can change your password from the Settings menu.</p>
</div>

<?php include "includes/footer.php"; ?>
