<?php
// ==========================================================
// admin/index.php — Admin Dashboard
// Summary cards pull live COUNT() queries, so they always
// reflect the current state after any CRUD operation.
// ==========================================================
require_once "../includes/config.php";
require_once "includes/auth.php";

$page_title = "Dashboard";
$active_menu = "dashboard";

// Auto-expire sweep — keep stats accurate without a cron job
mysqli_query($conn, "UPDATE members SET status='Expired' WHERE status='Active' AND membership_expiry_date < CURDATE()");

// ---- Live counts for summary cards ----
function count_rows($conn, $sql) {
    $res = mysqli_query($conn, $sql);
    return $res ? mysqli_fetch_assoc($res)['c'] : 0;
}
$total_members     = count_rows($conn, "SELECT COUNT(*) c FROM members");
$active_members     = count_rows($conn, "SELECT COUNT(*) c FROM members WHERE status='Active'");
$expired_members    = count_rows($conn, "SELECT COUNT(*) c FROM members WHERE status='Expired'");
$total_trainers     = count_rows($conn, "SELECT COUNT(*) c FROM trainers");
$total_batches      = count_rows($conn, "SELECT COUNT(*) c FROM batches");
$pending_reg        = count_rows($conn, "SELECT COUNT(*) c FROM requested_members WHERE status='Pending'");
$pending_renew      = count_rows($conn, "SELECT COUNT(*) c FROM renewal_requests WHERE status='Pending'");
$total_equipment    = count_rows($conn, "SELECT COALESCE(SUM(quantity),0) c FROM equipment");

// ---- Data for a simple "members per batch" chart ----
$chart_labels = [];
$chart_values = [];
$res = mysqli_query($conn, "
    SELECT b.batch_name, COUNT(mb.member_id) AS total
    FROM batches b
    LEFT JOIN member_batches mb ON mb.batch_id = b.batch_id
    GROUP BY b.batch_id, b.batch_name
    ORDER BY b.start_time
");
while ($row = mysqli_fetch_assoc($res)) {
    $chart_labels[] = $row['batch_name'];
    $chart_values[] = (int)$row['total'];
}

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="stat-card bg-stat-1">
            <h3 data-count="<?php echo $active_members; ?>">0</h3>
            <p>Active Members</p>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card bg-stat-2">
            <h3 data-count="<?php echo $total_trainers; ?>">0</h3>
            <p>Trainers</p>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card bg-stat-3">
            <h3 data-count="<?php echo $total_batches; ?>">0</h3>
            <p>Batches</p>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="stat-card bg-stat-4">
            <h3 data-count="<?php echo $expired_members; ?>">0</h3>
            <p>Expired Memberships</p>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="gym-card p-3">
            <h6 class="text-muted">Total Members</h6>
            <h4 data-count="<?php echo $total_members; ?>">0</h4>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="gym-card p-3">
            <h6 class="text-muted">Pending Registrations</h6>
            <h4><?php echo $pending_reg; ?> <a href="request/registration_request/requests.php" class="small">view</a></h4>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="gym-card p-3">
            <h6 class="text-muted">Pending Renewals</h6>
            <h4><?php echo $pending_renew; ?> <a href="request/renewable_request/requests.php" class="small">view</a></h4>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="gym-card p-3">
            <h6 class="text-muted">Equipment Units</h6>
            <h4 data-count="<?php echo $total_equipment; ?>">0</h4>
        </div>
    </div>
</div>

<div class="gym-card p-4">
    <h6 class="mb-3">Members per Batch</h6>
    <canvas id="batchChart" height="90"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
    const ctx = document.getElementById('batchChart');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chart_labels); ?>,
            datasets: [{
                label: 'Members',
                data: <?php echo json_encode($chart_values); ?>,
                backgroundColor: '#e63946'
            }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
    });
</script>

<?php include "includes/footer.php"; ?>
