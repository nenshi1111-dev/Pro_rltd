// ==========================================================
// js/script.js
// Shared JavaScript for the public site (and copied into
// admin/js, trainer/js for their panels).
// Main job: toggle password fields between hidden/visible.
// ==========================================================

document.addEventListener("DOMContentLoaded", function () {
    // Find every eye icon with class "toggle-password"
    const toggles = document.querySelectorAll(".toggle-password");

    toggles.forEach(function (icon) {
        icon.addEventListener("click", function () {
            // The icon must have data-target="idOfPasswordInput"
            const targetId = icon.getAttribute("data-target");
            const input = document.getElementById(targetId);
            if (!input) return;

            if (input.type === "password") {
                input.type = "text";
                icon.classList.remove("bi-eye");
                icon.classList.add("bi-eye-slash");
            } else {
                input.type = "password";
                icon.classList.remove("bi-eye-slash");
                icon.classList.add("bi-eye");
            }
        });
    });

    // Auto-hide Bootstrap alert messages after 4 seconds
    const alerts = document.querySelectorAll(".auto-hide-alert");
    alerts.forEach(function (alertBox) {
        setTimeout(function () {
            alertBox.style.transition = "opacity .5s ease";
            alertBox.style.opacity = "0";
            setTimeout(() => alertBox.remove(), 500);
        }, 4000);
    });

    // ==========================================================
    // Batch picker: live overlap + max-selection guard.
    // This is a CONVENIENCE layer only — the real, authoritative
    // check always happens server-side in PHP (find_batch_conflict()
    // in includes/batch-functions.php). This just stops a user from
    // clicking something that PHP would reject anyway, so they get
    // instant feedback instead of a page reload with an error.
    // Works on any container holding checkboxes with class
    // "batch-check-input" and data-start / data-end (HH:MM:SS) attrs.
    // ==========================================================
    const batchContainer = document.querySelector("[data-batch-picker]");
    if (batchContainer) {
        const maxBatches = parseInt(batchContainer.getAttribute("data-max-batches") || "3", 10);
        const boxes = batchContainer.querySelectorAll(".batch-check-input");

        function timesOverlap(s1, e1, s2, e2) {
            return (s1 < e2) && (s2 < e1);
        }

        function refreshBatchState() {
            const checked = Array.from(boxes).filter(b => b.checked);
            const checkedCount = checked.length;

            boxes.forEach(function (box) {
                if (box.checked) {
                    box.disabled = false;
                    return;
                }
                // Disable if selecting this would exceed the max
                if (checkedCount >= maxBatches) {
                    box.disabled = true;
                    return;
                }
                // Disable if it overlaps any currently-checked batch
                const conflicts = checked.some(c => timesOverlap(
                    box.dataset.start, box.dataset.end, c.dataset.start, c.dataset.end
                ));
                box.disabled = conflicts;
            });
        }

        boxes.forEach(box => box.addEventListener("change", refreshBatchState));
        refreshBatchState(); // run once on load (handles pre-checked edit forms)
    }
});
