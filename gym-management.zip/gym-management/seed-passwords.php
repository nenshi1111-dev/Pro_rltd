<?php
// ==========================================================
// seed-passwords.php
// RUN THIS FILE ONCE IN YOUR BROWSER AFTER IMPORTING gym_pro.sql
// It replaces the placeholder password text inserted by the SQL
// file with real password_hash() values, for every account that
// still has the placeholder (admin, trainer1, trainer2, member1,
// member2). Delete this file after running it.
// ==========================================================

require_once "includes/config.php";

$default_password = "password"; // demo password for all seeded accounts
$hash = password_hash($default_password, PASSWORD_DEFAULT);
$placeholder = "PLEASE_RUN_seed-passwords.php";

$done = [];

// Update every admin still holding the placeholder
$stmt = mysqli_prepare($conn, "UPDATE admins SET admin_password = ? WHERE admin_password = ?");
mysqli_stmt_bind_param($stmt, "ss", $hash, $placeholder);
mysqli_stmt_execute($stmt);
$done[] = "admins updated: " . mysqli_stmt_affected_rows($stmt);

// Update every trainer still holding the placeholder (trainer1, trainer2)
$stmt = mysqli_prepare($conn, "UPDATE trainers SET password = ? WHERE password = ?");
mysqli_stmt_bind_param($stmt, "ss", $hash, $placeholder);
mysqli_stmt_execute($stmt);
$done[] = "trainers updated: " . mysqli_stmt_affected_rows($stmt);

// Update every member still holding the placeholder (member1, member2)
$stmt = mysqli_prepare($conn, "UPDATE members SET password = ? WHERE password = ?");
mysqli_stmt_bind_param($stmt, "ss", $hash, $placeholder);
mysqli_stmt_execute($stmt);
$done[] = "members updated: " . mysqli_stmt_affected_rows($stmt);
?>
<!DOCTYPE html>
<html>
<head><title>Seeding passwords...</title></head>
<body style="font-family: Arial, sans-serif; padding: 40px;">
    <h2>Password seeding complete ✅</h2>
    <p>The following demo accounts now have the working password
       <strong><?php echo htmlspecialchars($default_password); ?></strong>:</p>
    <ul>
        <?php foreach ($done as $line) { echo "<li>" . htmlspecialchars($line) . "</li>"; } ?>
    </ul>
    <p style="color:red;"><strong>Delete this file (seed-passwords.php) now</strong> —
       it should never remain on a live/shared server.</p>
    <p><a href="index.php">Go to homepage</a></p>
</body>
</html>
