-- ==========================================================
-- migration-v3-payment-gate.sql
-- Run this ONCE in phpMyAdmin -> gym_pro -> SQL tab, on an
-- EXISTING database that already has the multi-batch +
-- payments schema (from migration-add-payments.sql or a
-- fresh v2 import). Keeps every row of your existing data —
-- these are column renames and one new ENUM value, not
-- table rebuilds.
--
-- If you're starting completely fresh, skip this file and
-- just import gym_pro.sql, which already includes everything
-- below.
--
-- Safe to run more than once — each step checks first and
-- skips if already applied.
-- ==========================================================

-- ---------------------------------------------------------
-- 1) Rename junction table primary keys
-- ---------------------------------------------------------

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'batch_trainers' AND COLUMN_NAME = 'id');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE batch_trainers CHANGE COLUMN id batch_trainer_id INT(11) NOT NULL AUTO_INCREMENT',
    'SELECT "batch_trainers already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'member_batches' AND COLUMN_NAME = 'id');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE member_batches CHANGE COLUMN id member_batch_id INT(11) NOT NULL AUTO_INCREMENT',
    'SELECT "member_batches already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'requested_member_batches' AND COLUMN_NAME = 'id');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE requested_member_batches CHANGE COLUMN id req_mem_btc_id INT(11) NOT NULL AUTO_INCREMENT',
    'SELECT "requested_member_batches already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'renewal_request_batches' AND COLUMN_NAME = 'id');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE renewal_request_batches CHANGE COLUMN id renwl_req_btc_id INT(11) NOT NULL AUTO_INCREMENT',
    'SELECT "renewal_request_batches already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------
-- 2) Add 'Pending Payment' to members.status
-- ---------------------------------------------------------

ALTER TABLE members
    MODIFY COLUMN status ENUM('Active','Expired','Inactive','Pending Payment') DEFAULT 'Active';

-- ---------------------------------------------------------
-- 3) Add the gym_upi_id setting (shown on the payment page)
-- ---------------------------------------------------------

INSERT INTO settings (setting_key, setting_value)
SELECT 'gym_upi_id', 'gympro@upi'
WHERE NOT EXISTS (SELECT 1 FROM settings WHERE setting_key = 'gym_upi_id');

-- ---------------------------------------------------------
-- 4) Simplify admins table to exactly 3 columns:
--    admin_id, admin_username, admin_password.
--    full_name, email, created_at are DROPPED — note them
--    down first if you want to keep a record, they are not
--    recoverable after this runs.
-- ---------------------------------------------------------

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admins' AND COLUMN_NAME = 'username');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE admins CHANGE COLUMN username admin_username VARCHAR(50) NOT NULL',
    'SELECT "admins.username already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admins' AND COLUMN_NAME = 'password');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE admins CHANGE COLUMN password admin_password VARCHAR(255) NOT NULL',
    'SELECT "admins.password already renamed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admins' AND COLUMN_NAME = 'full_name');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE admins DROP COLUMN full_name',
    'SELECT "admins.full_name already removed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admins' AND COLUMN_NAME = 'email');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE admins DROP COLUMN email',
    'SELECT "admins.email already removed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admins' AND COLUMN_NAME = 'created_at');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE admins DROP COLUMN created_at',
    'SELECT "admins.created_at already removed, skipped"');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ---------------------------------------------------------
-- 5) Remove the equipment feature entirely
-- ---------------------------------------------------------
DROP TABLE IF EXISTS equipment;

-- ==========================================================
-- After running this, new registration/renewal approvals will
-- put a member into 'Pending Payment' status until you log a
-- payment covering their amount due (Admin -> Payments ->
-- Log Payment). Existing members already marked 'Active' are
-- NOT affected — this only changes what happens going forward.
-- ==========================================================
