-- ======================================================
-- GYM-PRO DATABASE (v2 — multi-batch, no plans/pricing)
-- Database Name: gym_pro
-- Import this file in phpMyAdmin (XAMPP/WAMP) to create
-- the full database with default + dummy data.
--
-- CHANGES FROM v1:
--   - membership_plans table REMOVED entirely
--   - members.plan_id REMOVED, members.batch_id REMOVED
--   - New member_batches junction table (a member can be in
--     several batches at once, as long as their times don't
--     overlap — enforced in PHP, not in SQL)
--   - requested_members.membership_plan / batch_id REMOVED,
--     replaced by requested_member_batches junction table
--   - renewal_requests.current_plan / requested_plan REMOVED,
--     replaced by renewal_request_batches junction table
--   - No price/cost column anywhere — payment is handled
--     directly between Admin and Member, outside the system
-- ======================================================

CREATE DATABASE IF NOT EXISTS gym_pro;
USE gym_pro;

-- ------------------------------------------------------
-- 1) admins
-- ------------------------------------------------------
CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default admin account (username: admin)
-- The password column below is a PLACEHOLDER, not a real hash.
-- After importing this file, open seed-passwords.php ONCE in your
-- browser (http://localhost/gym-management/seed-passwords.php) —
-- it replaces every placeholder with a real password_hash() value.
-- After that, log in with: admin / password
INSERT INTO admins (username, password, full_name, email) VALUES
('admin', 'PLEASE_RUN_seed-passwords.php', 'Super Admin', 'admin@gympro.com');

-- ------------------------------------------------------
-- 2) trainers
-- ------------------------------------------------------
CREATE TABLE trainers (
    trainer_id INT AUTO_INCREMENT PRIMARY KEY,
    trainer_code VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') DEFAULT 'Male',
    phone VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    specialization VARCHAR(100),
    photo VARCHAR(255) DEFAULT 'default-trainer.png',
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO trainers (trainer_code, full_name, gender, phone, email, specialization, username, password, status) VALUES
('TR0001', 'Rahul Sharma', 'Male', '9000000001', 'rahul.trainer@gympro.com', 'Strength & Conditioning', 'trainer1', 'PLEASE_RUN_seed-passwords.php', 'Active'),
('TR0002', 'Priya Nair', 'Female', '9000000002', 'priya.trainer@gympro.com', 'Yoga & Flexibility', 'trainer2', 'PLEASE_RUN_seed-passwords.php', 'Active');

-- ------------------------------------------------------
-- 3) batches
-- Dummy data deliberately includes TWO batches with the
-- EXACT same time slot (Morning Yoga vs Morning Strength,
-- both 06:00-07:00) so you can immediately test the
-- overlap-prevention rule without creating data yourself.
-- ------------------------------------------------------
CREATE TABLE batches (
    batch_id INT AUTO_INCREMENT PRIMARY KEY,
    batch_name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    capacity INT NOT NULL DEFAULT 20,
    status ENUM('Active','Inactive') DEFAULT 'Active'
);

INSERT INTO batches (batch_name, start_time, end_time, capacity, status) VALUES
('Morning Yoga', '06:00:00', '07:00:00', 20, 'Active'),
('Morning Strength', '06:00:00', '07:00:00', 25, 'Active'),
('Morning Cardio', '07:15:00', '08:15:00', 20, 'Active'),
('Evening Zumba', '17:00:00', '18:00:00', 20, 'Active'),
('Evening Strength', '18:15:00', '19:15:00', 25, 'Active');

-- ------------------------------------------------------
-- 4) batch_trainers (many-to-many: batches <-> trainers)
-- ------------------------------------------------------
CREATE TABLE batch_trainers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    batch_id INT NOT NULL,
    trainer_id INT NOT NULL,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE,
    FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    UNIQUE KEY unique_assignment (batch_id, trainer_id)
);

INSERT INTO batch_trainers (batch_id, trainer_id) VALUES
(1, 2),
(2, 1),
(3, 1),
(4, 2),
(5, 1);

-- ------------------------------------------------------
-- 5) members
-- No plan_id, no single batch_id — batches are linked via
-- the member_batches junction table below.
-- ------------------------------------------------------
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    member_code VARCHAR(20) NOT NULL UNIQUE,
    photo VARCHAR(255) DEFAULT 'default-member.png',
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') DEFAULT 'Male',
    dob DATE,
    phone VARCHAR(20) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    address VARCHAR(255),
    emergency_contact VARCHAR(20),
    duration_months INT NOT NULL DEFAULT 1,
    membership_start_date DATE NOT NULL,
    membership_expiry_date DATE NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('Active','Expired','Inactive') DEFAULT 'Active',
    created_by VARCHAR(50),
    created_method ENUM('Request','Admin') DEFAULT 'Admin',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO members (member_code, full_name, gender, dob, phone, email, address, emergency_contact, duration_months, membership_start_date, membership_expiry_date, username, password, status, created_by, created_method) VALUES
('GM0001', 'Amit Verma', 'Male', '1998-05-12', '9111111111', 'amit.member@gympro.com', 'Jamnagar, Gujarat', '9111111112', 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 MONTH), 'member1', 'PLEASE_RUN_seed-passwords.php', 'Active', 'admin', 'Admin'),
('GM0002', 'Sneha Patel', 'Female', '2000-09-03', '9111111113', 'sneha.member@gympro.com', 'Rajkot, Gujarat', '9111111114', 3, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 3 MONTH), 'member2', 'PLEASE_RUN_seed-passwords.php', 'Active', 'admin', 'Admin');

-- ------------------------------------------------------
-- 6) member_batches (many-to-many: members <-> batches)
-- ------------------------------------------------------
CREATE TABLE member_batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    batch_id INT NOT NULL,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE,
    UNIQUE KEY unique_member_batch (member_id, batch_id)
);

-- Amit: Morning Yoga only
INSERT INTO member_batches (member_id, batch_id) VALUES (1, 1);
-- Sneha: Morning Cardio + Evening Zumba (different times, no overlap)
INSERT INTO member_batches (member_id, batch_id) VALUES (2, 3), (2, 4);

-- ------------------------------------------------------
-- 7) requested_members (public registration requests)
-- ------------------------------------------------------
CREATE TABLE requested_members (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') DEFAULT 'Male',
    dob DATE,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    emergency_contact VARCHAR(20),
    duration INT DEFAULT 1,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    status ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    approved_date DATETIME NULL,
    approved_by INT NULL,
    FOREIGN KEY (approved_by) REFERENCES admins(admin_id) ON DELETE SET NULL
);

-- ------------------------------------------------------
-- 8) requested_member_batches (batches requested at signup)
-- ------------------------------------------------------
CREATE TABLE requested_member_batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    batch_id INT NOT NULL,
    FOREIGN KEY (request_id) REFERENCES requested_members(request_id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE
);

-- ------------------------------------------------------
-- 9) renewal_requests
-- ------------------------------------------------------
CREATE TABLE renewal_requests (
    renewal_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    requested_duration INT DEFAULT 1,
    status ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    request_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    approved_date DATETIME NULL,
    approved_by INT NULL,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES admins(admin_id) ON DELETE SET NULL
);

-- ------------------------------------------------------
-- 10) renewal_request_batches (batches requested at renewal)
-- ------------------------------------------------------
CREATE TABLE renewal_request_batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    renewal_id INT NOT NULL,
    batch_id INT NOT NULL,
    FOREIGN KEY (renewal_id) REFERENCES renewal_requests(renewal_id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE
);

-- ------------------------------------------------------
-- 11) equipment
-- ------------------------------------------------------
CREATE TABLE equipment (
    equipment_id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    purchase_date DATE,
    condition_status ENUM('New','Good','Needs Repair','Old') DEFAULT 'New',
    vendor_name VARCHAR(100),
    vendor_location VARCHAR(150),
    vendor_mobile VARCHAR(20)
);

INSERT INTO equipment (equipment_name, quantity, purchase_date, condition_status, vendor_name, vendor_location, vendor_mobile) VALUES
('Treadmill', 4, '2024-01-10', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222'),
('Dumbbell Set (5-25kg)', 10, '2024-02-15', 'New', 'FitGear Traders', 'Jamnagar', '9222222222'),
('Yoga Mats', 25, '2024-03-01', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222');

-- ------------------------------------------------------
-- 12) announcements
-- ------------------------------------------------------
CREATE TABLE announcements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    publish_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    posted_by_role ENUM('Admin','Trainer') DEFAULT 'Admin',
    posted_by_id INT NOT NULL
);

INSERT INTO announcements (title, description, posted_by_role, posted_by_id) VALUES
('Welcome to Gym-Pro', 'You can now join more than one batch — as long as their timings do not overlap. Check the Batches page to see what is available.', 'Admin', 1);

-- ------------------------------------------------------
-- 13) workout_plans (one row per batch, per weekday)
-- ------------------------------------------------------
CREATE TABLE workout_plans (
    workout_id INT AUTO_INCREMENT PRIMARY KEY,
    batch_id INT NOT NULL,
    day_name ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
    focus_area VARCHAR(100),
    details TEXT,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE,
    UNIQUE KEY unique_batch_day (batch_id, day_name)
);

INSERT INTO workout_plans (batch_id, day_name, focus_area, details) VALUES
(2, 'Monday', 'Chest & Triceps', 'Bench press 4x10, Incline dumbbell press 3x12, Tricep pushdown 3x15'),
(2, 'Wednesday', 'Back & Biceps', 'Pull-ups 4x8, Barbell rows 4x10, Bicep curls 3x12'),
(1, 'Tuesday', 'Flexibility & Breathing', 'Sun salutations, standing poses, pranayama 15 min');

-- ------------------------------------------------------
-- 14) attendance
-- ------------------------------------------------------
CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    batch_id INT NOT NULL,
    date DATE NOT NULL,
    status ENUM('Present','Absent') DEFAULT 'Present',
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (batch_id) REFERENCES batches(batch_id) ON DELETE CASCADE,
    UNIQUE KEY unique_attendance (member_id, batch_id, date)
);

INSERT INTO attendance (member_id, batch_id, date, status) VALUES
(1, 1, CURDATE(), 'Present'),
(2, 3, CURDATE(), 'Present');

-- ------------------------------------------------------
-- 15) settings (generic key-value site settings)
-- ------------------------------------------------------
CREATE TABLE settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
);

INSERT INTO settings (setting_key, setting_value) VALUES
('gym_name', 'Gym-Pro'),
('gym_address', 'Jamnagar, Gujarat, India'),
('gym_email', 'contact@gympro.com'),
('gym_phone', '9876543210'),
('max_batches_per_member', '3');

-- ======================================================
-- END OF GYM_PRO DATABASE (v2)
--
-- IMPORTANT ONE-TIME STEP:
-- The password columns above are placeholders (not real hashes),
-- because a hash must be generated by PHP's password_hash().
-- After importing this file, visit seed-passwords.php ONCE in
-- your browser to set real, working passwords. Then log in with:
--   Admin    -> username: admin     password: password
--   Trainer  -> username: trainer1  password: password  (also trainer2)
--   Member   -> username: member1   password: password  (also member2)
-- Delete seed-passwords.php after running it once.
--
-- TEST DATA NOTES:
--   - "Morning Yoga" and "Morning Strength" are BOTH 06:00-07:00 —
--     use these two to test that the app correctly BLOCKS selecting
--     both at once (overlapping times).
--   - "Morning Cardio" (07:15-08:15) and "Evening Zumba" (17:00-18:00)
--     do NOT overlap — member2 (Sneha) is already enrolled in both,
--     proving multi-batch selection works end to end.
-- ======================================================
