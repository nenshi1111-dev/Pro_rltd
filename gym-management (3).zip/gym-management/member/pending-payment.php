<?php
// ==========================================================
// member/pending-payment.php — Payment required to activate
// Shown while a member's status is 'Pending Payment' (right
// after their registration or renewal was approved). Styled
// like a real checkout/booking payment page for clarity, but
// there is NO payment gateway here — Admin logs the actual
// payment in person, and this page's job is purely to explain
// what's owed and unlock automatically once that happens.
// ==========================================================
$allow_restricted = true;
require_once "../includes/config.php";
require_once "../includes/payment-functions.php";
require_once "includes/auth.php";

$page_title = "Complete Your Payment";
$active_menu = "pending_payment";
$member_id = $_SESSION['member_id'];

$stmt = mysqli_prepare($conn, "SELECT full_name, member_code, status FROM members WHERE member_id=?");
mysqli_stmt_bind_param($stmt, "i", $member_id);
mysqli_stmt_execute($stmt);
$member = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// If they're actually Active or Expired/Inactive, this isn't their page
if ($member && $member['status'] === 'Active') {
    header("Location: index.php");
    exit;
}
if ($member && $member['status'] !== 'Pending Payment') {
    header("Location: expired.php");
    exit;
}

// Itemized batches + fees
$batch_stmt = mysqli_prepare($conn, "SELECT b.batch_name, b.monthly_fee FROM member_batches mb JOIN batches b ON mb.batch_id=b.batch_id WHERE mb.member_id=? ORDER BY b.start_time");
mysqli_stmt_bind_param($batch_stmt, "i", $member_id);
mysqli_stmt_execute($batch_stmt);
$batch_res = mysqli_stmt_get_result($batch_stmt);
$batch_rows = array();
while ($row = mysqli_fetch_assoc($batch_res)) { $batch_rows[] = $row; }

$due = get_member_amount_due($conn, $member_id);
$paid = get_member_amount_paid($conn, $member_id);
$pending = get_member_pending_balance($conn, $member_id);

$settings = array();
$res = mysqli_query($conn, "SELECT setting_key, setting_value FROM settings");
while ($row = mysqli_fetch_assoc($res)) { $settings[$row['setting_key']] = $row['setting_value']; }

include "includes/header.php";
include "includes/sidebar.php";
include "includes/topbar.php";
?>

<div class="row justify-content-center">
    <div class="col-lg-8">

        <div class="checkout-card">
            <div class="checkout-header text-center">
                <i class="bi bi-lock-fill fs-2"></i>
                <h4 class="mt-2 mb-0">Complete Your Payment to Activate</h4>
                <p class="mb-0 opacity-75">Hi <?php echo htmlspecialchars($member['full_name']); ?> — one step left</p>
            </div>

            <div class="checkout-body">
                <h6 class="text-muted text-uppercase small mb-3">Order Summary</h6>
                <table class="table table-sm mb-3">
                    <tbody>
                        <?php foreach ($batch_rows as $b): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($b['batch_name']); ?></td>
                            <td class="text-end">Rs. <?php echo number_format($b['monthly_fee'], 2); ?> / month</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($batch_rows)): ?>
                        <tr><td colspan="2" class="text-muted">No batches on file.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="checkout-totals">
                    <div class="d-flex justify-content-between"><span>Amount Due</span><span>Rs. <?php echo number_format($due, 2); ?></span></div>
                    <div class="d-flex justify-content-between"><span>Amount Paid</span><span>Rs. <?php echo number_format($paid, 2); ?></span></div>
                    <hr>
                    <div class="d-flex justify-content-between checkout-grand-total">
                        <span>Pending Balance</span><span>Rs. <?php echo number_format($pending, 2); ?></span>
                    </div>
                </div>

                <h6 class="text-muted text-uppercase small mt-4 mb-3">Payment Method</h6>
                <div class="row g-2 payment-method-row">
                    <div class="col-6 col-md-3">
                        <div class="payment-method-card active" data-target="pmCash">
                            <i class="bi bi-cash-coin"></i><span>Cash</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="payment-method-card" data-target="pmUpi">
                            <i class="bi bi-phone"></i><span>UPI</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="payment-method-card" data-target="pmCard">
                            <i class="bi bi-credit-card"></i><span>Card</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="payment-method-card" data-target="pmBank">
                            <i class="bi bi-bank"></i><span>Bank Transfer</span>
                        </div>
                    </div>
                </div>

                <div class="payment-instructions mt-3">
                    <div id="pmCash" class="pm-instruction">
                        Pay in cash directly at the gym reception. Admin will log the payment and your account activates automatically.
                    </div>
                    <div id="pmUpi" class="pm-instruction" style="display:none;">
                        Pay via UPI to <strong><?php echo htmlspecialchars((isset($settings['gym_upi_id']) ? $settings['gym_upi_id'] : 'gympro@upi')); ?></strong>, then show the payment confirmation to Admin.
                    </div>
                    <div id="pmCard" class="pm-instruction" style="display:none;">
                        Card payments are accepted at the gym reception desk.
                    </div>
                    <div id="pmBank" class="pm-instruction" style="display:none;">
                        Contact Admin at <strong><?php echo htmlspecialchars((isset($settings['gym_phone']) ? $settings['gym_phone'] : '')); ?></strong> for bank transfer details.
                    </div>
                </div>

                <div class="alert alert-info mt-4 mb-0">
                    <i class="bi bi-info-circle me-1"></i>
                    This system does not process online payments directly. Complete your payment with Admin using any
                    of the methods above — once Admin logs it, your account unlocks automatically and you'll see your
                    full dashboard, batches, and more.
                </div>

                <div class="text-center mt-4">
                    <a href="pending-payment.php" class="btn btn-gym-primary"><i class="bi bi-arrow-clockwise me-1"></i>Check Payment Status</a>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
document.querySelectorAll('.payment-method-card').forEach(function (card) {
    card.addEventListener('click', function () {
        document.querySelectorAll('.payment-method-card').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.pm-instruction').forEach(el => el.style.display = 'none');
        card.classList.add('active');
        document.getElementById(card.dataset.target).style.display = 'block';
    });
});
</script>

<?php include "includes/footer.php"; ?>
