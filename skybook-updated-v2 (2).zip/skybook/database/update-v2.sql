-- ================================================================
-- SKY BOOK - INCREMENTAL DATABASE UPDATE (v2)
-- ----------------------------------------------------------------
-- Run this file ONLY if you already have the airline_db database
-- imported from an earlier copy of this project and do not want to
-- re-import the full database/airline_db.sql (which would reset
-- your existing data).
--
-- This adds the ONE new table required for the multi-reply
-- Feedback Conversation feature (Admin and User can now send
-- multiple replies back and forth in the same conversation).
-- No existing table, column, or data is changed or removed.
--
-- HOW TO RUN:
--   phpMyAdmin -> select the "airline_db" database -> "SQL" tab
--   -> paste the contents below (or "Import" this file) -> Go
-- ================================================================

CREATE TABLE IF NOT EXISTS feedback_replies (
    reply_id INT AUTO_INCREMENT PRIMARY KEY,
    feedback_id INT NOT NULL,
    sender ENUM('User','Admin') NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (feedback_id) REFERENCES feedback(feedback_id) ON DELETE CASCADE,
    INDEX idx_feedback (feedback_id)
) ENGINE=InnoDB;
