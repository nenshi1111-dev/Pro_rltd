<header class="admin-topbar d-lg-none">
  <button class="sidebar-toggle" onclick="document.querySelector('.admin-sidebar').classList.toggle('show')">
    <i class="fa-solid fa-bars"></i>
  </button>
</header>
<main class="admin-main">
  <?php showAlert(); ?>
