<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Edit Flight';

$flightId = (int) (isset($_GET['id']) ? $_GET['id'] : (isset($_POST['flight_id']) ? $_POST['flight_id'] : 0));
$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $flightId);
mysqli_stmt_execute($stmt);
$f = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$f) {
    setAlert('Flight not found.', 'danger');
    redirect(BASE_URL . 'admin/flights/flights.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $flightNumber = clean($_POST['flight_number']);
    $airlineName = clean($_POST['airline_name']);
    $source = clean($_POST['source']);
    $destination = clean($_POST['destination']);
    $departureDate = clean($_POST['departure_date']);
    $departureTime = clean($_POST['departure_time']);
    $arrivalTime = clean($_POST['arrival_time']);
    $economyPrice = clean($_POST['economy_price']);
    $businessPrice = clean($_POST['business_price']);
    $status = clean($_POST['status']);

    if ($flightNumber==='' || $source==='' || $destination==='' || $departureDate==='') {
        $errors[] = 'Please fill all required fields.';
    }
    // ---------------- Flight Number: airline code + 1 to 4 digits (e.g. 6E123, AI101, UK955) ----------------
    if ($flightNumber !== '' && !isValidFlightNumber($flightNumber)) {
        $errors[] = 'Flight Number must be an airline code followed by 1 to 4 digits (e.g. 6E123, AI101, UK955).';
    }
    if (strtolower($source) === strtolower($destination)) {
        $errors[] = 'Source and destination cannot be the same.';
    }
    if (!is_numeric($economyPrice) || !is_numeric($businessPrice)) {
        $errors[] = 'Prices must be valid numbers.';
    }

    $duration = $f['duration'];
    if ($departureTime && $arrivalTime) {
        $diff = strtotime($arrivalTime) - strtotime($departureTime);
        if ($diff < 0) $diff += 86400;
        $duration = floor($diff/3600) . 'h ' . str_pad(floor(($diff%3600)/60),2,'0',STR_PAD_LEFT) . 'm';
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "UPDATE flights SET flight_number=?, airline_name=?, source=?, destination=?, departure_date=?, departure_time=?, arrival_time=?, duration=?, economy_price=?, business_price=?, status=? WHERE flight_id=?");
        mysqli_stmt_bind_param($stmt, 'ssssssssddsi', $flightNumber, $airlineName, $source, $destination, $departureDate, $departureTime, $arrivalTime, $duration, $economyPrice, $businessPrice, $status, $flightId);
        mysqli_stmt_execute($stmt);
        setAlert('Flight updated successfully.', 'success');
        redirect(BASE_URL . 'admin/flights/flights.php');
    }
    // Keep entered values on validation failure
    $f = array_merge($f, ['flight_number'=>$flightNumber,'airline_name'=>$airlineName,'source'=>$source,'destination'=>$destination,'departure_date'=>$departureDate,'departure_time'=>$departureTime,'arrival_time'=>$arrivalTime,'economy_price'=>$economyPrice,'business_price'=>$businessPrice,'status'=>$status]);
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:800px;">
  <h5><i class="fa-solid fa-pen"></i> Edit Flight — <?php echo clean($f['flight_number']); ?></h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="edit-flight.php?id=<?php echo $flightId; ?>">
    <div class="row g-3">
      <div class="col-md-4"><label>Flight Number</label><input type="text" name="flight_number" class="form-control" value="<?php echo clean($f['flight_number']); ?>" placeholder="e.g. 6E123" maxlength="7" pattern="[A-Za-z0-9]{2,3}[0-9]{1,4}" title="Airline code followed by 1 to 4 digits, e.g. 6E123, AI101, UK955" oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9]/g,'')" required></div>
      <div class="col-md-8"><label>Airline Name</label><input type="text" name="airline_name" class="form-control" value="<?php echo clean($f['airline_name']); ?>" required></div>
      <div class="col-md-6"><label>Source</label><input type="text" name="source" class="form-control" value="<?php echo clean($f['source']); ?>" required></div>
      <div class="col-md-6"><label>Destination</label><input type="text" name="destination" class="form-control" value="<?php echo clean($f['destination']); ?>" required></div>
      <div class="col-md-4"><label>Departure Date</label><input type="date" name="departure_date" class="form-control" value="<?php echo clean($f['departure_date']); ?>" required></div>
      <div class="col-md-4"><label>Departure Time</label><input type="time" name="departure_time" class="form-control" value="<?php echo clean(substr($f['departure_time'],0,5)); ?>" required></div>
      <div class="col-md-4"><label>Arrival Time</label><input type="time" name="arrival_time" class="form-control" value="<?php echo clean(substr($f['arrival_time'],0,5)); ?>" required></div>
      <div class="col-md-4"><label>Economy Price (₹)</label><input type="number" step="0.01" name="economy_price" class="form-control" value="<?php echo clean($f['economy_price']); ?>" required></div>
      <div class="col-md-4"><label>Business Price (₹)</label><input type="number" step="0.01" name="business_price" class="form-control" value="<?php echo clean($f['business_price']); ?>" required></div>
      <div class="col-md-4">
        <label>Status</label>
        <select name="status" class="form-select">
          <?php foreach (['Scheduled','Delayed','Cancelled','Completed'] as $s): ?>
            <option value="<?php echo $s; ?>" <?php echo $f['status']==$s?'selected':''; ?>><?php echo $s; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6"><small class="text-muted">Economy Seats: <?php echo $f['economy_available_seats']; ?> available / <?php echo $f['economy_total_seats']; ?> total</small></div>
      <div class="col-md-6"><small class="text-muted">Business Seats: <?php echo $f['business_available_seats']; ?> available / <?php echo $f['business_total_seats']; ?> total</small></div>
    </div>
    <div class="mt-4">
      <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Update Flight</button>
      <a href="flights.php" class="btn btn-outline-secondary">Cancel</a>
    </div>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
