<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Add Announcement';

$errors = [];
// Publish date must be a future date, so default to tomorrow instead of today.
$minPublishDate = date('Y-m-d', strtotime('+1 day'));
$title = ''; $description = ''; $publishDate = $minPublishDate;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean(isset($_POST['title']) ? $_POST['title'] : '');
    $description = clean(isset($_POST['description']) ? $_POST['description'] : '');
    $publishDate = clean(isset($_POST['publish_date']) ? $_POST['publish_date'] : $minPublishDate);

    if ($title === '' || $description === '') {
        $errors[] = 'Please fill both title and message.';
    }
    // ---------------- Publish Date: only future dates are allowed ----------------
    if ($publishDate === '' || strtotime($publishDate) === false || strtotime($publishDate) <= strtotime(date('Y-m-d'))) {
        $errors[] = 'Publish date must be a future date. Past dates and today cannot be selected.';
    }

    if (empty($errors)) {
        $adminId = $_SESSION['admin_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO announcements (title, description, publish_date, status, created_by) VALUES (?,?,?, 'Active', ?)");
        mysqli_stmt_bind_param($stmt, 'sssi', $title, $description, $publishDate, $adminId);
        mysqli_stmt_execute($stmt);
        setAlert('Announcement published successfully.', 'success');
        redirect(BASE_URL . 'admin/announcements/announcements.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:700px;">
  <h5><i class="fa-solid fa-bullhorn"></i> Add Announcement</h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="add-announcement.php">
    <div class="mb-3"><label>Title</label><input type="text" name="title" class="form-control" value="<?php echo clean($title); ?>" required></div>
    <div class="mb-3"><label>Message</label><textarea name="description" class="form-control" rows="4" required><?php echo clean($description); ?></textarea></div>
    <div class="mb-3"><label>Publish Date</label><input type="date" name="publish_date" class="form-control" value="<?php echo clean($publishDate); ?>" min="<?php echo $minPublishDate; ?>" required><small class="text-muted">Only future dates can be selected. The announcement will show on the User side for 24 hours starting from this date.</small></div>
    <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Publish</button>
    <a href="announcements.php" class="btn btn-outline-secondary">Cancel</a>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
