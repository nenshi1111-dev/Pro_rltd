<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Edit Announcement';

$id = (int) (isset($_GET['id']) ? $_GET['id'] : (isset($_POST['announcement_id']) ? $_POST['announcement_id'] : 0));
$stmt = mysqli_prepare($conn, "SELECT * FROM announcements WHERE announcement_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$a = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$a) {
    setAlert('Announcement not found.', 'danger');
    redirect(BASE_URL . 'admin/announcements/announcements.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $publishDate = clean($_POST['publish_date']);
    $status = clean($_POST['status']);

    if ($title === '' || $description === '') {
        $errors[] = 'Please fill both title and message.';
    }
    // ---------------- Publish Date: only future dates are allowed (only re-checked if the date was changed) ----------------
    if ($publishDate !== $a['publish_date'] && ($publishDate === '' || strtotime($publishDate) === false || strtotime($publishDate) <= strtotime(date('Y-m-d')))) {
        $errors[] = 'Publish date must be a future date. Past dates and today cannot be selected.';
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "UPDATE announcements SET title=?, description=?, publish_date=?, status=? WHERE announcement_id=?");
        mysqli_stmt_bind_param($stmt, 'ssssi', $title, $description, $publishDate, $status, $id);
        mysqli_stmt_execute($stmt);
        setAlert('Announcement updated successfully.', 'success');
        redirect(BASE_URL . 'admin/announcements/announcements.php');
    }
    $a = array_merge($a, ['title'=>$title,'description'=>$description,'publish_date'=>$publishDate,'status'=>$status]);
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
// The date picker's minimum must never be after the announcement's own current
// publish_date, otherwise the existing value would show as invalid on load.
$minPublishDate = min(date('Y-m-d', strtotime('+1 day')), $a['publish_date']);
?>
<div class="admin-card" style="max-width:700px;">
  <h5><i class="fa-solid fa-pen"></i> Edit Announcement</h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="edit-announcement.php?id=<?php echo $id; ?>">
    <div class="mb-3"><label>Title</label><input type="text" name="title" class="form-control" value="<?php echo clean($a['title']); ?>" required></div>
    <div class="mb-3"><label>Message</label><textarea name="description" class="form-control" rows="4" required><?php echo clean($a['description']); ?></textarea></div>
    <div class="mb-3"><label>Publish Date</label><input type="date" name="publish_date" class="form-control" value="<?php echo clean($a['publish_date']); ?>" min="<?php echo $minPublishDate; ?>" required><small class="text-muted">Only future dates can be selected. Leave unchanged to keep the original publish date.</small></div>
    <div class="mb-3">
      <label>Status</label>
      <select name="status" class="form-select">
        <option value="Active" <?php echo $a['status']=='Active'?'selected':''; ?>>Active</option>
        <option value="Inactive" <?php echo $a['status']=='Inactive'?'selected':''; ?>>Inactive</option>
      </select>
      <small class="text-muted">Current display status: <strong><?php echo clean(announcementDisplayStatus($a)); ?></strong> (automatically becomes Expired 24 hours after the publish date; expired announcements are kept, not deleted).</small>
    </div>
    <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Update</button>
    <a href="announcements.php" class="btn btn-outline-secondary">Cancel</a>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
