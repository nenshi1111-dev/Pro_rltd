<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'User Report';

$result = mysqli_query($conn, "SELECT u.*,
    (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.user_id) AS total_bookings,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.user_id=u.user_id AND b.payment_status='Success') AS total_spent
    FROM users u ORDER BY total_spent DESC");
$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Top 8 spenders, for the chart below
$topUsers = array_slice($users, 0, 8);
$userLabels = [];
$userSpend = [];
foreach ($topUsers as $tu) {
    $userLabels[] = $tu['full_name'];
    $userSpend[] = (float) $tu['total_spent'];
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="user-report.php">User Report</a></li>
</ul>

<div class="row g-3 mb-3">
  <div class="col-12">
    <div class="chart-card">
      <h5><i class="fa-solid fa-crown text-primary"></i> Top Users by Spending</h5>
      <p class="chart-sub">Top 8 users, by total successful payments</p>
      <div class="chart-canvas-wrap h-230">
        <canvas id="userSpendChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <h5><i class="fa-solid fa-users"></i> Top Users by Spending</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Name</th><th>Email</th><th>Total Bookings</th><th>Total Spent</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo clean($u['full_name']); ?></td>
          <td><?php echo clean($u['email']); ?></td>
          <td><?php echo $u['total_bookings']; ?></td>
          <td><?php echo formatMoney($u['total_spent']); ?></td>
          <td><span class="badge bg-<?php echo $u['status']=='Active'?'success':'secondary'; ?>"><?php echo clean($u['status']); ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('userSpendChart'), {
  type: 'bar',
  data: {
    labels: <?php echo json_encode($userLabels); ?>,
    datasets: [{
      label: 'Total Spent (₹)',
      data: <?php echo json_encode($userSpend); ?>,
      backgroundColor: 'rgba(30,144,255,0.6)',
      borderRadius: 6,
      maxBarThickness: 45
    }]
  },
  options: {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { beginAtZero: true, grid: { color: '#eef3fa' } },
      y: { grid: { display: false } }
    }
  }
});
</script>

<?php require_once '../includes/footer.php'; ?>
