=================================================================
 SKY BOOK - PHP 5.4.31 / MySQL 5.6.20 COMPATIBILITY NOTES
=================================================================

This copy of the project has been converted so it runs on:
    PHP    : 5.4.31
    MySQL  : 5.6.20
(the standard versions on many college WAMP servers)

No feature was removed. Only PHP syntax that requires PHP 5.5+/7+
was rewritten in an older-PHP-compatible way, and the database
seed data was adjusted so it imports and logs in correctly.

-----------------------------------------------------------------
1) WHAT WAS CHANGED AND WHY
-----------------------------------------------------------------

a) Null coalescing operator ( ?? ) - added in PHP 7.0, NOT available
   in PHP 5.4. Every "$x ?? $default" in the project was rewritten as
   "isset($x) ? $x : $default", which behaves identically.

b) Spaceship operator ( <=> ) - added in PHP 7.0, NOT available in
   PHP 5.4. The 3 places that used it (sorting flights by AI score in
   flights.php, user/search-flights.php and user/recommendations.php)
   were rewritten using an equivalent if/ternary comparison.

c) password_hash() / password_verify() - only added in PHP 5.5.0,
   NOT available in PHP 5.4.31. A new file,
   includes/password_compat.php, re-implements both functions (plus
   password_needs_rehash() and password_get_info()) using PHP's
   built-in crypt() function with the $2y$ bcrypt identifier, which
   IS supported since PHP 5.3.7. It is loaded automatically by
   includes/config.php, so login, registration and change-password
   all keep working exactly as before - nothing else had to change.

   NOTE: This file only defines the functions "if they don't already
   exist", so it is completely safe even if you later move the
   project to a newer PHP version.

d) Seeded admin/user password hashes in database/airline_db.sql used
   the "$2b$" bcrypt identifier (from a JavaScript hashing tool).
   PHP's crypt() only understands "$2y$" (and "$2a$"/"$2x$"), so the
   sample hashes were changed from "$2b$" to "$2y$" (the bcrypt
   algorithm itself is identical - only the identifier changed).
   The demo logins still work exactly as documented:
        Admin : admin / admin123
        Users : (any sample user) / user123
   (as a second safety net, includes/password_compat.php also
   normalises $2b$/$2a$/$2x$ hashes automatically at verify time)

e) Short array badge-colour lookups such as
        ['Confirmed'=>'success', ...][$status] ?? 'secondary'
   were split into two lines (build the lookup array into a variable,
   then look it up with isset()), since combining ?? with an inline
   array literal is unreliable on PHP 5.4. Visual output is identical.

f) Argument unpacking with "..." - added in PHP 5.6.0, NOT available
   in PHP 5.4.31. Nine files built a dynamic prepared-statement
   parameter list and called
        mysqli_stmt_bind_param($stmt, $types, ...$params);
   which is a hard PARSE ERROR on 5.4.31 (the whole file would fail
   to load - "white screen" / 500 error). A new helper function,
   bindParamsArray($stmt, $types, $params), was added to
   includes/functions.php. It does the exact same job using the
   classic call_user_func_array() + by-reference array technique,
   which has worked since PHP 5.3. Every call site was updated to
   use it instead - no behaviour changed, only the mechanism. Files
   fixed:
        admin/users/users.php
        admin/refunds/refunds.php
        admin/flights/flights.php
        admin/reports/feedback-report.php
        admin/reports/booking-report.php
        admin/reports/refund-report.php
        admin/bookings/bookings.php
        user/search-flights.php
        flights.php

g) database/airline_db.sql was reviewed for MySQL 5.6.20
   compatibility (utf8mb4 collation, multiple DATETIME/TIMESTAMP
   columns with CURRENT_TIMESTAMP defaults, index/key lengths,
   foreign keys, ENUM, InnoDB, etc.) - no changes were required
   there beyond the password hash identifiers above; it already
   imports cleanly on MySQL 5.6.20. The two optional
   database/update_*.sql migration scripts were checked too and
   need no changes.

Everything else in the project (short array syntax "[]" and function
array-dereferencing func()['key'], both added in PHP 5.4.0 itself;
anonymous functions; traits-free procedural mysqli code; prepared
statements; session_status()/PHP_SESSION_NONE; str_pad/STR_PAD_LEFT;
single-type catch (Exception $e), etc.) already worked fine on
PHP 5.4.31 and was left untouched.

-----------------------------------------------------------------
2) SETUP STEPS (same as before)
-----------------------------------------------------------------
1. Copy the "airsmart-ai" folder into: C:\wamp64\www\airsmart-ai
   (or C:\wamp\www\airsmart-ai depending on your WAMP version)
2. Start Apache and MySQL from the WAMP control panel.
3. Open http://localhost/phpmyadmin, click "Import", choose
   database/airline_db.sql, and click "Go".
4. If your MySQL root user has a password, update includes/config.php
   (DB_PASS) accordingly - default is blank, matching WAMP's default.
5. Visit http://localhost/airsmart-ai/ in your browser.

-----------------------------------------------------------------
3) ONE THING TO DOUBLE-CHECK ON YOUR SERVER
-----------------------------------------------------------------
The project uses mysqli_stmt_get_result(), which requires the
"mysqlnd" driver for the mysqli extension. This is enabled by
default on virtually all WAMP/XAMPP builds that ship PHP 5.4, but if
you ever see a "Call to undefined method mysqli_stmt::get_result()"
error, open php.ini and make sure a line like:
    extension=php_mysqli.dll
is present and that mysqlnd (not the old libmysql client library)
is the underlying driver - this is the WAMP default, so in almost
all cases no action is needed.

-----------------------------------------------------------------
4) v2 FEATURE UPDATE - WHAT WAS ADDED (still PHP 5.4.31 / MySQL 5.6.20)
-----------------------------------------------------------------
A later round of changes added: flight number format validation,
alphabet-only name fields (Registration, My Profile, Passenger
Details, Cardholder Name, Admin Edit User, Contact Us), a minimum
age of 18 (Registration + Passenger Details), a round/circular
Announcements widget on the User Dashboard with an automatic
24-hour display window and an Active/Expired status on the Admin
side, a multi-reply Feedback conversation (both Admin and User can
now send more than one reply in the same thread), the "Give
Feedback" flow moved fully inside the User Dashboard instead of
leaving it for a separate page, and tickets now download as a real
.pdf file instead of .html.

All of it was written with the same PHP 5.4.31 constraints as
above: no "??", no "<=>", no "...$args" argument unpacking, and no
Composer packages. Two small additions worth knowing about:

  - The PDF ticket (user/download-ticket.php) is generated by a
    small hand-written PDF writer, generateSimplePdf(), added to
    includes/functions.php. It only uses core string functions
    (no Composer library, no imagick/gd, no zip requirement), so
    it needs nothing beyond a stock PHP 5.4 install.
  - The DateTime class (used by isAtLeast18() in
    includes/functions.php to check the 18-years-old rule) has
    been available since PHP 5.2, so it works unchanged on 5.4.31.

ONE NEW DATABASE TABLE was added for the multi-reply Feedback
conversation: "feedback_replies". If you already have the
"airline_db" database imported from an earlier copy of this
project and do NOT want to lose your existing data by re-importing
the full database/airline_db.sql, just run the small
database/update-v2.sql file instead (phpMyAdmin -> airline_db ->
SQL tab -> paste its contents, or use Import). It only adds the one
new table and touches nothing else. A fresh import of
database/airline_db.sql already includes this table, so brand-new
setups do not need to run update-v2.sql separately.

