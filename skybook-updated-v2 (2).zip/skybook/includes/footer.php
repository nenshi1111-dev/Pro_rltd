<footer class="main-footer">
  <div class="container">
    <div class="row gy-4">
      <div class="col-md-4">
        <h5><i class="fa-solid fa-plane-up"></i> <?php echo SITE_NAME; ?></h5>
        <p>Sky Book — Airline Ticket Booking System</p>
        <p class="small mb-0">Created for BCA College Project</p>
      </div>
      <div class="col-md-4">
        <h6>Quick Links</h6>
        <ul class="list-unstyled footer-links">
          <li><a href="<?php echo BASE_URL; ?>index.php">Home</a></li>
          <li><a href="<?php echo BASE_URL; ?>about.php">About</a></li>
          <li><a href="<?php echo BASE_URL; ?>flights.php">Flights</a></li>
          <li><a href="<?php echo BASE_URL; ?>contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4">
        <h6>Contact Us</h6>
        <ul class="list-unstyled footer-links">
          <li><i class="fa-solid fa-phone"></i> +91 98765 43210</li>
          <li><i class="fa-solid fa-envelope"></i> support@skybook.com</li>
          <li><i class="fa-solid fa-location-dot"></i> Rajkot, Gujarat, India</li>
        </ul>
      </div>
    </div>
    <hr class="border-light opacity-25">
    <p class="text-center small mb-0">&copy; <?php echo date('Y'); ?> Sky Book. All Rights Reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<!-- Project custom JS -->
<script src="<?php echo BASE_URL; ?>js/script.js"></script>
</body>
</html>
