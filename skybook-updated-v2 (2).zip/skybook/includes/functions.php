<?php
/* ============================================================
   AIRSMART AI - COMMON HELPER FUNCTIONS
   Small reusable functions used across user and admin pages.
   ============================================================ */

// Clean user input to prevent XSS when displaying data
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/* ============================================================
   SHARED VALIDATION HELPERS
   Used across Admin + User forms (flight number, names, age)
   so the exact same rule is enforced everywhere it is needed.
   ============================================================ */

// Flight Number: an airline code followed by 1 to 4 digits, e.g. 6E123, AI101, UK955
function isValidFlightNumber($flightNumber) {
    $flightNumber = trim($flightNumber);
    return (bool) preg_match('/^[A-Za-z0-9]{2,3}[0-9]{1,4}$/', $flightNumber);
}

// Name fields (User Name / Full Name / Cardholder Name): alphabet characters and spaces only
function isAlphaName($name) {
    $name = trim($name);
    return $name !== '' && (bool) preg_match('/^[A-Za-z ]+$/', $name);
}

// Returns true if the given date of birth means the person is at least 18 years old today
function isAtLeast18($dob) {
    $dobTime = strtotime($dob);
    if ($dob === '' || $dobTime === false) {
        return false;
    }
    $today = new DateTime('today');
    $birthDate = new DateTime(date('Y-m-d', $dobTime));
    if ($birthDate > $today) {
        return false; // date of birth in the future
    }
    $age = $today->diff($birthDate)->y;
    return $age >= 18;
}

/* ============================================================
   ANNOUNCEMENT HELPERS
   An announcement is shown on the User side only on its exact
   publish_date (a full 24 hour window from publish time, i.e.
   from that date's midnight to the next day's midnight). After
   that it is automatically hidden from the User side, but it is
   never deleted and always stays visible on the Admin side.
   ============================================================ */

// Whether an announcement (given its publish_date) has finished its 24 hour display window
function isAnnouncementExpired($publishDate) {
    $publishStart = strtotime($publishDate . ' 00:00:00');
    if ($publishStart === false) {
        return true;
    }
    return time() >= ($publishStart + 86400);
}

// Admin-side display status: Inactive (manually disabled), Expired (24 hours passed) or Active
function announcementDisplayStatus($announcement) {
    if ($announcement['status'] === 'Inactive') {
        return 'Inactive';
    }
    return isAnnouncementExpired($announcement['publish_date']) ? 'Expired' : 'Active';
}

/* ============================================================
   FEEDBACK CONVERSATION HELPER
   Builds the full back-and-forth timeline for one feedback
   thread in chronological order: the original message the User
   submitted, followed by every reply from either side (stored in
   feedback_replies). This lets both Admin and User send more than
   one reply in the same conversation instead of just a single
   admin_reply. Any legacy admin_reply already saved on the
   feedback row itself (from before this feature existed) is kept
   and shown first, since it always happened before any row in
   feedback_replies could exist.
   ============================================================ */
function getFeedbackConversation($conn, $feedback) {
    $timeline = [];
    $timeline[] = ['sender' => 'User', 'message' => $feedback['message'], 'created_at' => $feedback['created_at']];

    if (!empty($feedback['admin_reply'])) {
        $timeline[] = ['sender' => 'Admin', 'message' => $feedback['admin_reply'], 'created_at' => $feedback['replied_at']];
    }

    $stmt = mysqli_prepare($conn, "SELECT sender, message, created_at FROM feedback_replies WHERE feedback_id = ? ORDER BY created_at ASC, reply_id ASC");
    mysqli_stmt_bind_param($stmt, 'i', $feedback['feedback_id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $timeline[] = $row;
    }
    return $timeline;
}

/* ============================================================
   PHP 5.4 COMPATIBILITY HELPER
   ------------------------------------------------------------
   mysqli_stmt_bind_param($stmt, $types, ...$params) uses the "..."
   argument-unpacking operator, which was only added in PHP 5.6.0
   and is NOT available in PHP 5.4.31 (it causes a parse error).
   This helper does the exact same job the old-fashioned way, using
   call_user_func_array() with by-reference values, which has always
   worked since PHP 5.3.
   ============================================================ */
function bindParamsArray($stmt, $types, $params) {
    if (empty($params)) {
        return true;
    }
    $refs = array();
    $refs[] = $stmt;
    $refs[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        // must be actual references, not copies, for bind_param to work
        $refs[] = &$params[$i];
    }
    return call_user_func_array('mysqli_stmt_bind_param', $refs);
}

// Generate a unique booking reference like AS20260815001
function generateBookingReference($conn) {
    $prefix = 'AS' . date('Ymd');
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_reference LIKE '$prefix%'");
    $row = mysqli_fetch_assoc($result);
    $next = $row['total'] + 1;
    return $prefix . str_pad($next, 3, '0', STR_PAD_LEFT);
}

// Generate a simple transaction id
function generateTransactionId() {
    return 'TXN' . time() . rand(100, 999);
}

// Generate a ticket number from the passenger id, e.g. TKT000001
function generateTicketNumber($passengerId) {
    return 'TKT' . str_pad($passengerId, 6, '0', STR_PAD_LEFT);
}

// Format a date nicely, e.g. 25 Aug 2026
function formatDate($date) {
    return date('d M Y', strtotime($date));
}

// Format time nicely, e.g. 10:30 AM
function formatTime($time) {
    return date('h:i A', strtotime($time));
}

// Format money with Indian Rupee symbol
function formatMoney($amount) {
    return '₹' . number_format($amount, 2);
}

// Redirect helper
function redirect($url) {
    header('Location: ' . $url);
    exit();
}

// Show a bootstrap alert message from session (used after redirects)
function showAlert() {
    if (isset($_SESSION['alert_message'])) {
        $type = isset($_SESSION['alert_type']) ? $_SESSION['alert_type'] : 'info';
        $msg = $_SESSION['alert_message'];
        echo '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">'
            . clean($msg) .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['alert_message']);
        unset($_SESSION['alert_type']);
    }
}

// Set an alert message to show after redirect
function setAlert($message, $type = 'info') {
    $_SESSION['alert_message'] = $message;
    $_SESSION['alert_type'] = $type; // success, danger, warning, info
}

/* ============================================================
   SIMPLE STUDENT-LEVEL "AI" FLIGHT RECOMMENDATION SCORING
   (Section 8 of the project prompt - no external AI API needed)

   Score = Price Score + Availability Score + Time Score + Route Match Score
   Shared by flights.php and user/search-flights.php so the logic
   is written only once (reusable include rule).
   ============================================================ */
function calculateFlightScore($flight, $travelClass, $searchedSource = '', $searchedDestination = '') {
    $price = ($travelClass === 'Business') ? $flight['business_price'] : $flight['economy_price'];
    $available = ($travelClass === 'Business') ? $flight['business_available_seats'] : $flight['economy_available_seats'];

    // Price Score: cheaper flights score higher (max 40 points)
    $priceScore = max(0, 40 - ($price / 200));

    // Availability Score: more available seats score higher (max 25 points)
    $availabilityScore = min(25, $available / 6);

    // Time Score: convenient daytime departure scores higher (max 20 points)
    $hour = (int) date('H', strtotime($flight['departure_time']));
    $timeScore = ($hour >= 6 && $hour <= 21) ? 20 : 10;

    // Route Match Score: exact source/destination match scores higher (max 15 points)
    $routeScore = 0;
    if ($searchedSource !== '' && stripos($flight['source'], $searchedSource) !== false) $routeScore += 8;
    if ($searchedDestination !== '' && stripos($flight['destination'], $searchedDestination) !== false) $routeScore += 7;
    if ($searchedSource === '' && $searchedDestination === '') $routeScore = 10;

    $total = round($priceScore + $availabilityScore + $timeScore + $routeScore, 1);

    // Simple human-readable reason
    $reasons = [];
    if ($priceScore >= 25) $reasons[] = 'lower price';
    if ($availabilityScore >= 15) $reasons[] = 'good seat availability';
    if ($timeScore == 20) $reasons[] = 'convenient departure time';
    if ($routeScore >= 8) $reasons[] = 'matches your searched route';
    if (empty($reasons)) $reasons[] = 'overall balanced score';

    $reasonText = 'Recommended because it has ' . implode(' and ', $reasons) . '.';

    return ['score' => $total, 'reason' => $reasonText];
}

/* ============================================================
   REFUND SYSTEM: percentage-based refund calculation
   Based on how many days remain before the flight's departure
   date at the moment of cancellation. Shared by the user and
   admin cancellation flows so the policy is written only once.
   ============================================================ */
function getRefundPolicyTiers() {
    return [
        ['label' => '7 or more days before departure', 'percentage' => 90],
        ['label' => '3 to 6 days before departure',     'percentage' => 50],
        ['label' => '1 to 2 days before departure',      'percentage' => 25],
        ['label' => 'Less than 24 hours / same day',     'percentage' => 0],
    ];
}

// Returns the refund percentage (0-100) that applies for a given departure date
function calculateRefundPercentage($departureDate) {
    $daysLeft = (strtotime($departureDate) - strtotime(date('Y-m-d'))) / 86400;
    if ($daysLeft >= 7) return 90;
    if ($daysLeft >= 3) return 50;
    if ($daysLeft >= 1) return 25;
    return 0;
}

// Bootstrap badge colour for a refund_status value
function refundStatusBadge($status) {
    $map = ['Pending' => 'warning', 'Processing' => 'info', 'Completed' => 'success', 'Rejected' => 'danger', 'Not Applicable' => 'secondary'];
    return isset($map[$status]) ? $map[$status] : 'secondary';
}

/* ============================================================
   PER-PASSENGER CANCELLATION HELPERS
   A booking can hold more than one passenger (e.g. 4). These
   helpers let a single passenger be cancelled on their own
   without disturbing the other passengers on the same booking.
   ============================================================ */

// How many passengers on this booking are still Active (not cancelled individually)
function countActivePassengers($conn, $bookingId) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ? AND status = 'Active'");
    mysqli_stmt_bind_param($stmt, 'i', $bookingId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return (int) $row['total'];
}

// Fare share of a single passenger, based on the booking's original total amount
// spread evenly across the original passenger_count (so it stays stable even
// after other passengers on the same booking are cancelled one by one).
function passengerFareShare($booking) {
    $count = max(1, (int) $booking['passenger_count']);
    return round($booking['total_amount'] / $count, 2);
}

/* ============================================================
   MINIMAL PDF GENERATOR (no external libraries required)
   Builds a valid PDF file out of plain text pages using the core
   Helvetica font, using only native PHP string functions so it
   keeps working on a plain PHP 5.4 install with no Composer /
   extra extensions. Used by user/download-ticket.php so tickets
   can be downloaded as an actual .pdf file (Section 14).
   ============================================================ */

// Escape a line of text so it is safe to place inside a PDF text string
function pdfEscapeText($text) {
    $text = str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $text);
    // Core (non-embedded) PDF fonts only reliably support this character range
    $text = preg_replace('/[^\x20-\x7E]/', '', $text);
    return $text;
}

// $pages: array of pages, each page itself an array of plain text lines. Returns raw PDF bytes.
function generateSimplePdf($pages) {
    if (empty($pages)) {
        $pages = array(array('No content.'));
    }
    $pageCount = count($pages);
    $fontObjNum = 3 + ($pageCount * 2);

    $objects = array();
    $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';

    $kids = array();
    for ($i = 0; $i < $pageCount; $i++) {
        $kids[] = (3 + $i) . ' 0 R';
    }
    $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $pageCount . ' >>';

    for ($i = 0; $i < $pageCount; $i++) {
        $pageObjNum = 3 + $i;
        $contentObjNum = 3 + $pageCount + $i;

        $objects[$pageObjNum] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] '
            . '/Resources << /Font << /F1 ' . $fontObjNum . ' 0 R >> >> /Contents ' . $contentObjNum . ' 0 R >>';

        $y = 800;
        $stream = "BT /F1 12 Tf\n";
        foreach ($pages[$i] as $line) {
            $safe = pdfEscapeText($line);
            $stream .= "1 0 0 1 50 $y Tm ($safe) Tj\n";
            $y -= 18;
        }
        $stream .= 'ET';

        $objects[$contentObjNum] = '<< /Length ' . strlen($stream) . " >>\nstream\n$stream\nendstream";
    }

    $objects[$fontObjNum] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';

    $pdf = "%PDF-1.4\n";
    $offsets = array();
    $totalObjects = $fontObjNum;

    for ($n = 1; $n <= $totalObjects; $n++) {
        $offsets[$n] = strlen($pdf);
        $pdf .= "$n 0 obj\n" . $objects[$n] . "\nendobj\n";
    }

    $xrefStart = strlen($pdf);
    $pdf .= "xref\n0 " . ($totalObjects + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($n = 1; $n <= $totalObjects; $n++) {
        $pdf .= str_pad($offsets[$n], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
    }
    $pdf .= 'trailer' . "\n" . '<< /Size ' . ($totalObjects + 1) . ' /Root 1 0 R >>' . "\n";
    $pdf .= "startxref\n$xrefStart\n%%EOF";

    return $pdf;
}

// Build the seat map (A-F economy / A-D business) sized to the flight's
// actual total seat count for that class, and mark already booked seats.
function buildSeatMap($conn, $flightId, $travelDate, $travelClass, $totalSeats) {
    $cols = ($travelClass === 'Business') ? ['A','B','C','D'] : ['A','B','C','D','E','F'];
    $colCount = count($cols);
    $rows = (int) ceil($totalSeats / $colCount);

    // Get already booked seats for this exact flight + date + class
    $booked = [];
    $stmt = mysqli_prepare($conn, "SELECT seat_number FROM seats WHERE flight_id = ? AND travel_date = ? AND travel_class = ? AND status = 'Booked'");
    mysqli_stmt_bind_param($stmt, 'iss', $flightId, $travelDate, $travelClass);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $booked[] = $row['seat_number'];
    }

    $map = [];
    $seatCount = 0;
    for ($r = 1; $r <= $rows; $r++) {
        $rowSeats = [];
        foreach ($cols as $c) {
            if ($seatCount >= $totalSeats) break; // stop once we reach the flight's real seat total
            $seatNo = $r . $c;
            $rowSeats[] = ['seat' => $seatNo, 'booked' => in_array($seatNo, $booked)];
            $seatCount++;
        }
        if (!empty($rowSeats)) $map[] = $rowSeats;
    }
    return $map;
}
?>
