<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Register';

if (isset($_SESSION['user_id'])) {
    redirect(BASE_URL . 'user/index.php');
}

$errors = [];
$old = ['full_name' => '', 'gender' => '', 'dob' => '', 'mobile' => '', 'email' => '', 'address' => '', 'username' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean(isset($_POST['full_name']) ? $_POST['full_name'] : '');
    $gender = clean(isset($_POST['gender']) ? $_POST['gender'] : '');
    $dob = clean(isset($_POST['dob']) ? $_POST['dob'] : '');
    $mobile = clean(isset($_POST['mobile']) ? $_POST['mobile'] : '');
    $email = clean(isset($_POST['email']) ? $_POST['email'] : '');
    $address = clean(isset($_POST['address']) ? $_POST['address'] : '');
    $username = clean(isset($_POST['username']) ? $_POST['username'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $old = compact('full_name', 'gender', 'dob', 'mobile', 'email', 'address', 'username');

    // ---------------- Server-side validation ----------------
    if ($full_name === '' || $gender === '' || $dob === '' || $mobile === '' || $email === '' || $username === '' || $password === '') {
        $errors[] = 'Please fill all required fields.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $errors[] = 'Please enter a valid 10 digit mobile number.';
    }
    if (strtotime($dob) > strtotime('-1 year')) {
        $errors[] = 'Please enter a valid date of birth.';
    }
    if ($dob !== '' && strtotime($dob) !== false && strtotime($dob) < strtotime('1900-01-01')) {
        $errors[] = 'Please enter a valid date of birth.';
    }
    // ---------------- Minimum age: 18 years ----------------
    if ($dob !== '' && strtotime($dob) !== false && !isAtLeast18($dob)) {
        $errors[] = 'You must be at least 18 years old to register.';
    }
    if ($username !== '' && !preg_match('/^[A-Za-z0-9_]{4,20}$/', $username)) {
        $errors[] = 'Username must be 4-20 characters long and contain only letters, numbers and underscore.';
    }
    if ($full_name !== '' && strlen($full_name) < 3) {
        $errors[] = 'Full name must be at least 3 characters long.';
    }
    // ---------------- Name field: alphabet characters only ----------------
    if ($full_name !== '' && !isAlphaName($full_name)) {
        $errors[] = 'Full name must contain alphabet characters only.';
    }
    if ($address !== '' && strlen($address) > 255) {
        $errors[] = 'Address is too long (max 255 characters).';
    }
    if ($password !== $confirm_password) {
        $errors[] = 'Password and Confirm Password do not match.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }

    if (empty($errors)) {
        // Check unique username
        $stmt = mysqli_prepare($conn, "SELECT user_id FROM users WHERE username = ?");
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
            $errors[] = 'This username is already taken.';
        }

        // Check unique email
        $stmt = mysqli_prepare($conn, "SELECT user_id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
            $errors[] = 'This email is already registered.';
        }
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, gender, dob, mobile, email, address, username, password) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'ssssssss', $full_name, $gender, $dob, $mobile, $email, $address, $username, $hashedPassword);

        if (mysqli_stmt_execute($stmt)) {
            setAlert('Registration successful! Please login to continue.', 'success');
            redirect(BASE_URL . 'login.php');
        } else {
            $errors[] = 'Something went wrong. Please try again.';
        }
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<div class="auth-wrapper">
  <div class="auth-card" style="max-width:650px;">
    <div class="auth-logo-header">
      <img src="<?php echo BASE_URL; ?>images/register.png" alt="Sky Book" class="auth-logo">
    </div>
    <h3><i class="fa-solid fa-user-plus text-primary"></i> Create Account</h3>
    <p class="sub">Register to start booking flights on Sky Book</p>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="register.php" id="registerForm">
      <div class="row g-3">
        <div class="col-md-6">
          <label>Full Name</label>
          <input type="text" name="full_name" class="form-control" value="<?php echo clean($old['full_name']); ?>" minlength="3" maxlength="100" pattern="[A-Za-z ]+" title="Alphabet characters only" oninput="this.value=this.value.replace(/[^A-Za-z ]/g,'')" required>
        </div>
        <div class="col-md-6">
          <label>Gender</label>
          <select name="gender" class="form-select" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php echo $old['gender']=='Male'?'selected':''; ?>>Male</option>
            <option value="Female" <?php echo $old['gender']=='Female'?'selected':''; ?>>Female</option>
            <option value="Other" <?php echo $old['gender']=='Other'?'selected':''; ?>>Other</option>
          </select>
        </div>
        <div class="col-md-6">
          <label>Date of Birth</label>
          <input type="date" name="dob" class="form-control" value="<?php echo clean($old['dob']); ?>" max="<?php echo date('Y-m-d', strtotime('-18 years')); ?>" min="1900-01-01" title="You must be at least 18 years old to register" required>
        </div>
        <div class="col-md-6">
          <label>Mobile Number</label>
          <input type="text" name="mobile" class="form-control" maxlength="10" pattern="[0-9]{10}" title="Enter a valid 10 digit mobile number" inputmode="numeric" value="<?php echo clean($old['mobile']); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Email</label>
          <input type="email" name="email" class="form-control" value="<?php echo clean($old['email']); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Username</label>
          <input type="text" name="username" class="form-control" pattern="[A-Za-z0-9_]{4,20}" title="4-20 characters: letters, numbers and underscore only" value="<?php echo clean($old['username']); ?>" required>
        </div>
        <div class="col-12">
          <label>Address</label>
          <input type="text" name="address" class="form-control" value="<?php echo clean($old['address']); ?>">
        </div>
        <div class="col-md-6">
          <label>Password</label>
          <div class="password-wrapper">
            <input type="password" name="password" id="regPassword" class="form-control" required minlength="6">
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
        <div class="col-md-6">
          <label>Confirm Password</label>
          <div class="password-wrapper">
            <input type="password" name="confirm_password" id="regConfirmPassword" class="form-control" required minlength="6">
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary-custom w-100 mt-4">Register</button>
    </form>

    <p class="text-center mt-4 mb-0">Already have an account? <a href="login.php">Login here</a></p>
  </div>
</div>
<script>
(function () {
  var pass = document.getElementById('regPassword');
  var confirm = document.getElementById('regConfirmPassword');
  function checkMatch() {
    if (pass.value && confirm.value && pass.value !== confirm.value) {
      confirm.setCustomValidity('Password and Confirm Password do not match.');
    } else {
      confirm.setCustomValidity('');
    }
  }
  if (pass && confirm) {
    pass.addEventListener('input', checkMatch);
    confirm.addEventListener('input', checkMatch);
  }
})();
</script>

<?php require_once 'includes/footer.php'; ?>
