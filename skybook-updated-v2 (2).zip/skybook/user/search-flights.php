<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Search Flights';

/* Same search + AI scoring logic as the public flights.php page,
   shown here inside the logged-in user dashboard layout. */
$source = isset($_GET['source']) ? clean($_GET['source']) : '';
$destination = isset($_GET['destination']) ? clean($_GET['destination']) : '';
$departureDate = isset($_GET['departure_date']) ? clean($_GET['departure_date']) : '';
$travelClass = isset($_GET['travel_class']) ? clean($_GET['travel_class']) : 'Economy';
$passengers = isset($_GET['passengers']) ? (int) $_GET['passengers'] : 1;
$searchDone = ($source !== '' || $destination !== '' || $departureDate !== '');

$errors = [];
if ($searchDone) {
    if ($source === '' || $destination === '') {
        $errors[] = 'Please enter both source and destination.';
    } elseif (strtolower($source) === strtolower($destination)) {
        $errors[] = 'Source and destination cannot be the same.';
    }
    if ($departureDate !== '' && strtotime($departureDate) < strtotime(date('Y-m-d'))) {
        $errors[] = 'Departure date cannot be in the past.';
    }
    if ($passengers < 1 || $passengers > 9) {
        $errors[] = 'Number of passengers must be between 1 and 9.';
    }
}

$flights = [];
if (empty($errors) && $searchDone) {
    $sql = "SELECT * FROM flights WHERE status != 'Cancelled' AND source LIKE ? AND destination LIKE ?";
    $params = ['%' . $source . '%', '%' . $destination . '%'];
    $types = 'ss';

    if ($departureDate !== '') {
        $sql .= " AND departure_date = ?";
        $params[] = $departureDate;
        $types .= 's';
    } else {
        $sql .= " AND departure_date >= CURDATE()";
    }
    $sql .= " ORDER BY departure_date ASC, departure_time ASC";

    $stmt = mysqli_prepare($conn, $sql);
    bindParamsArray($stmt, $types, $params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        // Check enough seats exist for the requested passenger count
        $available = ($travelClass === 'Business') ? $row['business_available_seats'] : $row['economy_available_seats'];
        $row['enough_seats'] = ($available >= $passengers);
        $flights[] = $row;
    }
}

foreach ($flights as &$f) {
    $scoreData = calculateFlightScore($f, $travelClass, $source, $destination);
    $f['ai_score'] = $scoreData['score'];
    $f['ai_reason'] = $scoreData['reason'];
}
unset($f);
usort($flights, function ($a, $b) { if ($b['ai_score'] == $a['ai_score']) return 0; return ($b['ai_score'] < $a['ai_score']) ? -1 : 1; });

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="section-title text-start mb-4"><h2>Search Flights</h2></div>

    <div class="search-card mb-5" style="margin-top:0;">
      <form action="search-flights.php" method="GET">
        <div class="row g-3">
          <div class="col-md-3">
            <label>From</label>
            <input type="text" name="source" class="form-control" value="<?php echo clean($source); ?>" placeholder="e.g. Rajkot" required>
          </div>
          <div class="col-md-3">
            <label>To</label>
            <input type="text" name="destination" class="form-control" value="<?php echo clean($destination); ?>" placeholder="e.g. Mumbai" required>
          </div>
          <div class="col-md-2">
            <label>Departure Date</label>
            <input type="date" name="departure_date" class="form-control" value="<?php echo clean($departureDate); ?>" min="<?php echo date('Y-m-d'); ?>" required>
          </div>
          <div class="col-md-2">
            <label>Class</label>
            <select name="travel_class" class="form-select">
              <option value="Economy" <?php echo $travelClass=='Economy'?'selected':''; ?>>Economy</option>
              <option value="Business" <?php echo $travelClass=='Business'?'selected':''; ?>>Business</option>
            </select>
          </div>
          <div class="col-md-2">
            <label>Passengers</label>
            <input type="number" name="passengers" class="form-control" value="<?php echo (int)$passengers; ?>" min="1" max="9">
          </div>
        </div>
        <div class="text-center mt-4">
          <button type="submit" class="btn btn-dark-blue px-5"><i class="fa-solid fa-magnifying-glass"></i> Search Flights</button>
        </div>
      </form>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
    <?php endif; ?>

    <?php if ($searchDone && empty($errors)): ?>
      <?php if (count($flights) === 0): ?>
        <div class="text-center text-muted py-5"><i class="fa-solid fa-plane-slash fs-1 mb-3 d-block"></i>No flights found for your search. Try different dates or route.</div>
      <?php endif; ?>
      <?php foreach ($flights as $index => $f): ?>
        <div class="flight-card">
          <div class="row align-items-center">
            <div class="col-md-2">
              <span class="flight-number"><?php echo clean($f['flight_number']); ?></span><br>
              <small class="text-muted"><?php echo clean($f['airline_name']); ?></small>
              <?php if ($index === 0 && $f['enough_seats']): ?><br><span class="badge-recommend mt-1 d-inline-block">Recommended For You ⭐</span><?php endif; ?>
            </div>
            <div class="col-md-4">
              <div class="route-time"><?php echo clean($f['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($f['destination']); ?></div>
              <small class="text-muted"><?php echo formatDate($f['departure_date']); ?> &nbsp;|&nbsp; <?php echo formatTime($f['departure_time']); ?> - <?php echo formatTime($f['arrival_time']); ?> (<?php echo clean($f['duration']); ?>)</small>
            </div>
            <div class="col-md-3">
              <small class="text-muted d-block">Economy: <?php echo formatMoney($f['economy_price']); ?> (<?php echo $f['economy_available_seats']; ?> left)</small>
              <small class="text-muted d-block">Business: <?php echo formatMoney($f['business_price']); ?> (<?php echo $f['business_available_seats']; ?> left)</small>
            </div>
            <div class="col-md-3 text-md-end mt-3 mt-md-0">
              <?php if ($f['enough_seats']): ?>
                <a href="booking.php?flight_id=<?php echo $f['flight_id']; ?>&class=<?php echo urlencode($travelClass); ?>&passengers=<?php echo (int)$passengers; ?>" class="btn btn-primary-custom w-100">Book Now</a>
              <?php else: ?>
                <button class="btn btn-secondary w-100" disabled>No seats available</button>
              <?php endif; ?>
            </div>
          </div>
          <p class="small text-muted mt-2 mb-0"><i class="fa-solid fa-circle-info"></i> <?php echo clean($f['ai_reason']); ?></p>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
