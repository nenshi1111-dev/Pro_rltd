<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'My Feedback';

$userId = $_SESSION['user_id'];
$errors = [];
$oldMessage = '';
$oldRating = 0;

// ---------------- Handle: submit brand new feedback (Section 7/8 - stays inside the User Dashboard, rating is optional) ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_feedback'])) {
    $message = trim(isset($_POST['message']) ? $_POST['message'] : '');
    $rating = isset($_POST['rating']) && $_POST['rating'] !== '' ? (int) $_POST['rating'] : null;
    $oldMessage = $message;
    $oldRating = (int) $rating;

    if ($message === '') {
        $errors[] = 'Please enter your feedback message.';
    } elseif (mb_strlen($message) < 5) {
        $errors[] = 'Your feedback message is too short. Please share a few more details.';
    } elseif (mb_strlen($message) > 1000) {
        $errors[] = 'Your feedback message is too long (maximum 1000 characters).';
    }
    // Rating is optional (Section 8: feedback submission is not compulsory to include a star rating).
    if ($rating !== null && ($rating < 1 || $rating > 5)) {
        $errors[] = 'Please select a star rating between 1 and 5, or leave it blank.';
    }

    if (empty($errors)) {
        $message = clean($message);
        $stmt = mysqli_prepare($conn, "INSERT INTO feedback (user_id, message, rating) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'isi', $userId, $message, $rating);
        if (mysqli_stmt_execute($stmt)) {
            setAlert('Thank you! Your feedback has been submitted.', 'success');
            redirect(BASE_URL . 'user/feedback-history.php');
        } else {
            $errors[] = 'Something went wrong while submitting your feedback. Please try again.';
        }
    }
}

// ---------------- Handle: continue an existing conversation (Section 6 - User can reply multiple times too) ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_feedback_id'])) {
    $feedbackId = (int) $_POST['reply_feedback_id'];
    $reply = clean(isset($_POST['user_reply']) ? $_POST['user_reply'] : '');

    // Make sure this feedback conversation actually belongs to the logged-in user
    $stmt = mysqli_prepare($conn, "SELECT feedback_id FROM feedback WHERE feedback_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, 'ii', $feedbackId, $userId);
    mysqli_stmt_execute($stmt);
    $owns = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$owns) {
        setAlert('Feedback not found.', 'danger');
    } elseif ($reply === '') {
        setAlert('Reply message cannot be empty.', 'danger');
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO feedback_replies (feedback_id, sender, message) VALUES (?, 'User', ?)");
        mysqli_stmt_bind_param($stmt, 'is', $feedbackId, $reply);
        if (mysqli_stmt_execute($stmt)) {
            // A new message from the User means it is now waiting on the Admin again
            $stmt = mysqli_prepare($conn, "UPDATE feedback SET status = 'Pending' WHERE feedback_id = ?");
            mysqli_stmt_bind_param($stmt, 'i', $feedbackId);
            mysqli_stmt_execute($stmt);
            setAlert('Your reply has been sent.', 'success');
        } else {
            setAlert('Something went wrong. Please try again.', 'danger');
        }
    }
    redirect(BASE_URL . 'user/feedback-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM feedback WHERE user_id = ? ORDER BY created_at DESC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$myFeedback = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="section-title text-start mb-4"><h2 class="mb-0">My Feedback</h2></div>
    <?php showAlert(); ?>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?></ul>
      </div>
    <?php endif; ?>

    <!-- ---------------- Give New Feedback (stays inside the dashboard, no redirect to index.php) ---------------- -->
    <div class="dash-card mb-4" id="new-feedback">
      <h5 class="mb-3"><i class="fa-solid fa-comment-dots text-primary"></i> Give Feedback</h5>
      <form method="POST" action="feedback-history.php#new-feedback">
        <input type="hidden" name="new_feedback" value="1">
        <div class="mb-3 text-center">
          <label class="d-block mb-2 fw-semibold">How was your experience? <span class="text-muted small">(optional)</span></label>
          <div class="star-rating">
            <input type="radio" name="rating" id="star5" value="5" <?php echo $oldRating==5?'checked':''; ?>><label for="star5"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star4" value="4" <?php echo $oldRating==4?'checked':''; ?>><label for="star4"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star3" value="3" <?php echo $oldRating==3?'checked':''; ?>><label for="star3"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star2" value="2" <?php echo $oldRating==2?'checked':''; ?>><label for="star2"><i class="fa-solid fa-star"></i></label>
            <input type="radio" name="rating" id="star1" value="1" <?php echo $oldRating==1?'checked':''; ?>><label for="star1"><i class="fa-solid fa-star"></i></label>
          </div>
        </div>
        <div class="mb-3">
          <label>Your Feedback</label>
          <textarea name="message" rows="3" class="form-control" placeholder="Tell us what you liked, or what we can improve..." required><?php echo clean($oldMessage); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-paper-plane"></i> Submit Feedback</button>
      </form>
    </div>

    <?php if (empty($myFeedback)): ?>
      <div class="dash-card text-center py-5">
        <i class="fa-solid fa-comment-dots fs-1 text-muted mb-3 d-block"></i>
        <p class="text-muted mb-0">You have not submitted any feedback yet. Use the form above to share your thoughts.</p>
      </div>
    <?php endif; ?>

    <?php foreach ($myFeedback as $fb): ?>
      <div class="feedback-card">
        <div class="d-flex justify-content-between flex-wrap gap-2">
          <div>
            <small class="text-muted"><i class="fa-solid fa-clock"></i> Submitted on <?php echo date('d M Y, h:i A', strtotime($fb['created_at'])); ?></small>
          </div>
          <div class="text-end">
            <?php if ($fb['rating']): ?>
              <div class="feedback-stars-display">
                <?php for ($i = 1; $i <= 5; $i++) echo $i <= $fb['rating'] ? '★' : '☆'; ?>
              </div>
            <?php endif; ?>
            <span class="badge bg-<?php echo $fb['status'] == 'Replied' ? 'success' : 'warning'; ?>">
              <?php echo clean($fb['status']); ?>
            </span>
          </div>
        </div>

        <!-- Conversation-style layout: every message from either side, in chronological order -->
        <?php $conversation = getFeedbackConversation($conn, $fb); ?>
        <?php foreach ($conversation as $msg): ?>
          <?php if ($msg['sender'] === 'User'): ?>
            <div class="feedback-msg-bubble mine mt-3">
              <div class="label"><i class="fa-solid fa-user"></i> You — <?php echo date('d M Y, h:i A', strtotime($msg['created_at'])); ?></div>
              <p class="mb-0"><?php echo nl2br(clean($msg['message'])); ?></p>
            </div>
          <?php else: ?>
            <div class="feedback-msg-bubble theirs">
              <div class="label"><i class="fa-solid fa-headset"></i> Admin Reply — <?php echo date('d M Y, h:i A', strtotime($msg['created_at'])); ?></div>
              <p class="mb-0"><?php echo nl2br(clean($msg['message'])); ?></p>
            </div>
          <?php endif; ?>
        <?php endforeach; ?>

        <?php if ($fb['status'] != 'Replied'): ?>
          <div class="feedback-msg-bubble waiting">
            <i class="fa-solid fa-hourglass-half"></i> Waiting for admin's reply...
          </div>
        <?php endif; ?>

        <!-- Continue the conversation -->
        <form method="POST" action="feedback-history.php" class="mt-3">
          <input type="hidden" name="reply_feedback_id" value="<?php echo (int) $fb['feedback_id']; ?>">
          <div class="mb-2">
            <label class="small fw-semibold">Reply</label>
            <textarea name="user_reply" class="form-control" rows="2" placeholder="Type your reply..." required></textarea>
          </div>
          <button type="submit" class="btn btn-outline-custom btn-sm"><i class="fa-solid fa-paper-plane"></i> Send Reply</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
