<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Cancel Passenger';

$userId = $_SESSION['user_id'];
$bookingId = (int) (isset($_POST['booking_id']) ? $_POST['booking_id'] : (isset($_GET['booking_id']) ? $_GET['booking_id'] : 0));
$passengerId = (int) (isset($_POST['passenger_id']) ? $_POST['passenger_id'] : (isset($_GET['passenger_id']) ? $_GET['passenger_id'] : 0));

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_id, f.flight_number, f.source, f.destination, f.departure_date
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE passenger_id = ? AND booking_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $passengerId, $bookingId);
mysqli_stmt_execute($stmt);
$passenger = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$passenger) {
    setAlert('Passenger not found on this booking.', 'danger');
    redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
}

// Only meaningful when the booking has more than one passenger. A booking
// with a single passenger should use the normal "Cancel Booking" flow.
$canCancelPassenger = ($booking['booking_status'] === 'Confirmed')
    && ($passenger['status'] === 'Active')
    && ((int) $booking['passenger_count'] > 1)
    && (strtotime($booking['departure_date']) >= strtotime(date('Y-m-d')));

if (!$canCancelPassenger) {
    setAlert('This passenger is not eligible for individual cancellation.', 'warning');
    redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
}

$fareShare = passengerFareShare($booking);
$refundPercentage = calculateRefundPercentage($booking['departure_date']);
$refundAmount = round($fareShare * $refundPercentage / 100, 2);
$daysLeft = max(0, (int) ceil((strtotime($booking['departure_date']) - strtotime(date('Y-m-d'))) / 86400));
$activeCount = countActivePassengers($conn, $bookingId);
$isLastPassenger = ($activeCount <= 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    mysqli_begin_transaction($conn);
    try {
        // 1) Mark this passenger as cancelled
        $stmt = mysqli_prepare($conn, "UPDATE passengers SET status='Cancelled' WHERE passenger_id=? AND booking_id=?");
        mysqli_stmt_bind_param($stmt, 'ii', $passengerId, $bookingId);
        mysqli_stmt_execute($stmt);

        // 2) Free this passenger's seat only
        $stmt = mysqli_prepare($conn, "DELETE FROM seats WHERE booking_id=? AND seat_number=?");
        mysqli_stmt_bind_param($stmt, 'is', $bookingId, $passenger['seat_number']);
        mysqli_stmt_execute($stmt);

        if ($passenger['travel_class'] === 'Business') {
            mysqli_query($conn, "UPDATE flights SET business_available_seats = business_available_seats + 1 WHERE flight_id = " . (int) $booking['flight_id']);
        } else {
            mysqli_query($conn, "UPDATE flights SET economy_available_seats = economy_available_seats + 1 WHERE flight_id = " . (int) $booking['flight_id']);
        }

        // 3) Log this individual cancellation with its own refund share
        $refundStatus = ($refundPercentage > 0) ? 'Pending' : 'Rejected';
        $reason = 'Individually cancelled by user: ' . $passenger['full_name'];
        $stmt = mysqli_prepare($conn, "INSERT INTO cancellations (booking_id, passenger_id, reason, cancelled_by, refund_amount, refund_percentage, refund_status, updated_at)
            VALUES (?, ?, ?, 'User', ?, ?, ?, NOW())");
        mysqli_stmt_bind_param($stmt, 'iisdds', $bookingId, $passengerId, $reason, $refundAmount, $refundPercentage, $refundStatus);
        mysqli_stmt_execute($stmt);

        // 4) If this was the last Active passenger, the whole booking becomes Cancelled.
        //    Otherwise just reduce the booking total by this passenger's fare share.
        $remainingActive = countActivePassengers($conn, $bookingId);
        if ($remainingActive <= 0) {
            $newPaymentStatus = ($refundPercentage > 0) ? 'Refunded' : $booking['payment_status'];
            $stmt = mysqli_prepare($conn, "UPDATE bookings SET booking_status='Cancelled', payment_status=?, cancellation_date=NOW() WHERE booking_id=?");
            mysqli_stmt_bind_param($stmt, 'si', $newPaymentStatus, $bookingId);
            mysqli_stmt_execute($stmt);
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE bookings SET total_amount = GREATEST(0, total_amount - ?) WHERE booking_id=?");
            mysqli_stmt_bind_param($stmt, 'di', $fareShare, $bookingId);
            mysqli_stmt_execute($stmt);
        }

        mysqli_commit($conn);
        setAlert('Passenger ' . $passenger['full_name'] . ' has been cancelled. Refund calculated: ' . formatMoney($refundAmount) . ' (' . $refundPercentage . '%).', 'success');
        redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        setAlert('Something went wrong while cancelling this passenger. Please try again.', 'danger');
        redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:650px;">
    <div class="dash-card text-center mb-4">
      <i class="fa-solid fa-user-slash text-danger fs-1 mb-3"></i>
      <h4>Cancel Passenger: <?php echo clean($passenger['full_name']); ?>?</h4>
      <p class="text-muted mb-0">You are about to cancel only this passenger from booking
        <?php echo clean($booking['booking_reference']); ?> (flight <?php echo clean($booking['flight_number']); ?>,
        seat <?php echo clean($passenger['seat_number']); ?>). The other passengers on this booking will not be affected.
        This action cannot be undone.</p>
      <?php if ($isLastPassenger): ?>
        <div class="alert alert-warning mt-3 mb-0"><i class="fa-solid fa-triangle-exclamation"></i> This is the last active passenger on this booking, so the entire booking will be cancelled.</div>
      <?php endif; ?>
    </div>

    <div class="dash-card mb-4">
      <h5 class="mb-3"><i class="fa-solid fa-receipt text-primary"></i> Refund Breakdown (this passenger only)</h5>
      <div class="ticket-row"><span class="label">Passenger's Fare Share</span><span class="value"><?php echo formatMoney($fareShare); ?></span></div>
      <div class="ticket-row"><span class="label">Days Left Before Departure</span><span class="value"><?php echo $daysLeft; ?> day(s)</span></div>
      <div class="ticket-row"><span class="label">Refund Percentage</span><span class="value"><?php echo $refundPercentage; ?>%</span></div>
      <div class="ticket-row"><span class="label">Refund Amount</span><span class="value"><?php echo formatMoney($refundAmount); ?></span></div>

      <hr>
      <p class="small text-muted mb-1"><i class="fa-solid fa-circle-info"></i> Our cancellation policy:</p>
      <ul class="small text-muted mb-0">
        <?php foreach (getRefundPolicyTiers() as $tier): ?>
          <li><?php echo clean($tier['label']); ?> - <strong><?php echo $tier['percentage']; ?>% refund</strong></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="dash-card text-center">
      <form method="POST" action="cancel-passenger.php">
        <input type="hidden" name="booking_id" value="<?php echo $bookingId; ?>">
        <input type="hidden" name="passenger_id" value="<?php echo $passengerId; ?>">
        <button type="submit" class="btn btn-danger me-2">Yes, Cancel This Passenger</button>
        <a href="view-booking.php?id=<?php echo $bookingId; ?>" class="btn btn-outline-secondary">No, Go Back</a>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
