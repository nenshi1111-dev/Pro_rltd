<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Booking Details';

$bookingId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
$userId = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.airline_name, f.source, f.destination, f.departure_date, f.departure_time, f.arrival_time, f.duration
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE booking_id = ? ORDER BY passenger_id");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$passengers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

// A single passenger inside a multi-passenger booking can be cancelled on
// their own, as long as the booking itself is still Confirmed and in the future.
$canCancelSinglePassenger = ($booking['booking_status'] === 'Confirmed')
    && ((int) $booking['passenger_count'] > 1)
    && (strtotime($booking['departure_date']) >= strtotime(date('Y-m-d')));

$stmt = mysqli_prepare($conn, "SELECT * FROM payments WHERE booking_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$payment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// A booking can be cancelled by the user only while it is Confirmed and still in the future
$canCancel = ($booking['booking_status'] === 'Confirmed') && (strtotime($booking['departure_date']) >= strtotime(date('Y-m-d')));

// Refund details, if this booking was cancelled
$cancellation = null;
if ($booking['booking_status'] === 'Cancelled') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM cancellations WHERE booking_id = ? ORDER BY cancellation_id DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $bookingId);
    mysqli_stmt_execute($stmt);
    $cancellation = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:850px;">
    <a href="booking-history.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to My Bookings</a>

    <div class="dash-card mb-4">
      <div class="d-flex justify-content-between flex-wrap">
        <h4>Booking <?php echo clean($booking['booking_reference']); ?></h4>
        <?php
          $badgeMap = array('Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'); $badge = isset($badgeMap[$booking['booking_status']]) ? $badgeMap[$booking['booking_status']] : 'secondary';
        ?>
        <span class="badge bg-<?php echo $badge; ?> align-self-start fs-6"><?php echo clean($booking['booking_status']); ?></span>
      </div>
      <hr>
      <div class="row">
        <div class="col-md-6">
          <div class="ticket-row"><span class="label">Flight</span><span class="value"><?php echo clean($booking['flight_number']); ?> (<?php echo clean($booking['airline_name']); ?>)</span></div>
          <div class="ticket-row"><span class="label">Route</span><span class="value"><?php echo clean($booking['source']); ?> → <?php echo clean($booking['destination']); ?></span></div>
          <div class="ticket-row"><span class="label">Date</span><span class="value"><?php echo formatDate($booking['departure_date']); ?></span></div>
          <div class="ticket-row"><span class="label">Time</span><span class="value"><?php echo formatTime($booking['departure_time']); ?> - <?php echo formatTime($booking['arrival_time']); ?></span></div>
        </div>
        <div class="col-md-6">
          <div class="ticket-row"><span class="label">Class</span><span class="value"><?php echo clean($booking['travel_class']); ?></span></div>
          <div class="ticket-row"><span class="label">Passengers</span><span class="value"><?php echo (int)$booking['passenger_count']; ?></span></div>
          <div class="ticket-row"><span class="label">Total Amount</span><span class="value"><?php echo formatMoney($booking['total_amount']); ?></span></div>
          <div class="ticket-row"><span class="label">Payment Status</span><span class="value"><?php echo clean($booking['payment_status']); ?></span></div>
        </div>
      </div>
    </div>

    <div class="dash-card mb-4">
      <h5 class="mb-3">Passenger & Seat Details</h5>
      <div class="table-responsive">
        <table class="table table-custom">
          <thead><tr><th>#</th><th>Name</th><th>Gender</th><th>DOB</th><th>ID Number</th><th>Seat</th><th>Status</th><?php if ($canCancelSinglePassenger): ?><th>Action</th><?php endif; ?></tr></thead>
          <tbody>
          <?php foreach ($passengers as $i => $p): ?>
            <tr>
              <td><?php echo $i+1; ?></td>
              <td><?php echo clean($p['full_name']); ?></td>
              <td><?php echo clean($p['gender']); ?></td>
              <td><?php echo formatDate($p['dob']); ?></td>
              <td><?php echo clean($p['id_number']); ?></td>
              <td><?php echo clean($p['seat_number']); ?></td>
              <td><span class="badge bg-<?php echo $p['status']==='Cancelled' ? 'danger' : 'success'; ?>"><?php echo clean($p['status']); ?></span></td>
              <?php if ($canCancelSinglePassenger): ?>
                <td>
                  <?php if ($p['status'] === 'Active'): ?>
                    <a href="cancel-passenger.php?booking_id=<?php echo $bookingId; ?>&passenger_id=<?php echo $p['passenger_id']; ?>" class="btn btn-sm btn-outline-danger confirm-cancel"><i class="fa-solid fa-user-slash"></i> Cancel</a>
                  <?php else: ?>
                    <span class="text-muted small">—</span>
                  <?php endif; ?>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if ($canCancelSinglePassenger): ?>
        <p class="small text-muted mb-0"><i class="fa-solid fa-circle-info"></i> You can cancel any one passenger individually without cancelling the whole booking.</p>
      <?php endif; ?>
    </div>

    <?php if ($cancellation): ?>
    <div class="dash-card mb-4">
      <h5 class="mb-3"><i class="fa-solid fa-receipt text-primary"></i> Refund Details</h5>
      <div class="row">
        <div class="col-md-6">
          <div class="ticket-row"><span class="label">Original Payment Amount</span><span class="value"><?php echo formatMoney($booking['total_amount']); ?></span></div>
          <div class="ticket-row"><span class="label">Refund Percentage</span><span class="value"><?php echo (float) $cancellation['refund_percentage']; ?>%</span></div>
        </div>
        <div class="col-md-6">
          <div class="ticket-row"><span class="label">Refund Amount</span><span class="value"><?php echo formatMoney($cancellation['refund_amount']); ?></span></div>
          <div class="ticket-row"><span class="label">Refund Status</span><span class="value"><span class="badge bg-<?php echo refundStatusBadge($cancellation['refund_status']); ?>"><?php echo clean($cancellation['refund_status']); ?></span></span></div>
        </div>
      </div>
      <p class="small text-muted mb-0 mt-2"><i class="fa-solid fa-clock"></i> Cancelled on <?php echo date('d M Y, h:i A', strtotime($cancellation['cancellation_date'])); ?></p>
    </div>
    <?php endif; ?>

    <div class="d-flex gap-2 flex-wrap">
      <?php if ($booking['booking_status'] === 'Confirmed'): ?>
        <a href="ticket.php?booking_id=<?php echo $booking['booking_id']; ?>" class="btn btn-primary-custom"><i class="fa-solid fa-ticket"></i> View / Print Ticket</a>
        <a href="download-ticket.php?booking_id=<?php echo $booking['booking_id']; ?>" class="btn btn-outline-primary"><i class="fa-solid fa-download"></i> Download Ticket</a>
      <?php endif; ?>
      <?php if ($canCancel): ?>
        <a href="cancel-booking.php?id=<?php echo $booking['booking_id']; ?>" class="btn btn-outline-danger confirm-cancel"><i class="fa-solid fa-ban"></i> Cancel Whole Booking</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
