<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Cancel Booking';

$userId = $_SESSION['user_id'];
$bookingId = (int) (isset($_POST['booking_id']) ? $_POST['booking_id'] : (isset($_GET['id']) ? $_GET['id'] : 0));

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_date, f.economy_available_seats, f.business_available_seats
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$canCancel = ($booking['booking_status'] === 'Confirmed') && (strtotime($booking['departure_date']) >= strtotime(date('Y-m-d')));
if (!$canCancel) {
    setAlert('This booking is not eligible for cancellation.', 'warning');
    redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
}

// ---------------- Refund calculation (percentage-based on cancellation time) ----------------
$refundPercentage = calculateRefundPercentage($booking['departure_date']);
$refundAmount = round($booking['total_amount'] * $refundPercentage / 100, 2);
$daysLeft = max(0, (int) ceil((strtotime($booking['departure_date']) - strtotime(date('Y-m-d'))) / 86400));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    mysqli_begin_transaction($conn);
    try {
        // Mark booking cancelled. Payment status only flips to "Refunded" once a
        // refund is actually applicable; otherwise the original payment stands.
        $newPaymentStatus = ($refundPercentage > 0) ? 'Refunded' : $booking['payment_status'];
        $stmt = mysqli_prepare($conn, "UPDATE bookings SET booking_status='Cancelled', payment_status=?, cancellation_date=NOW() WHERE booking_id=?");
        mysqli_stmt_bind_param($stmt, 'si', $newPaymentStatus, $bookingId);
        mysqli_stmt_execute($stmt);

        // Log the cancellation with the calculated refund percentage/amount
        $refundStatus = ($refundPercentage > 0) ? 'Pending' : 'Rejected';
        $reason = 'Cancelled by user from booking history.';
        $stmt = mysqli_prepare($conn, "INSERT INTO cancellations (booking_id, reason, cancelled_by, refund_amount, refund_percentage, refund_status, updated_at)
            VALUES (?, ?, 'User', ?, ?, ?, NOW())");
        mysqli_stmt_bind_param($stmt, 'isdds', $bookingId, $reason, $refundAmount, $refundPercentage, $refundStatus);
        mysqli_stmt_execute($stmt);

        // Mark every passenger on this booking as cancelled too, so per-passenger
        // status stays consistent with the overall booking status
        mysqli_query($conn, "UPDATE passengers SET status='Cancelled' WHERE booking_id = " . (int)$bookingId);

        // Free up the seats
        mysqli_query($conn, "DELETE FROM seats WHERE booking_id = " . (int)$bookingId);

        // Give the seats back to the correct class only (Section 9)
        if ($booking['travel_class'] === 'Business') {
            mysqli_query($conn, "UPDATE flights SET business_available_seats = business_available_seats + " . (int)$booking['passenger_count'] . " WHERE flight_id = " . (int)$booking['flight_id']);
        } else {
            mysqli_query($conn, "UPDATE flights SET economy_available_seats = economy_available_seats + " . (int)$booking['passenger_count'] . " WHERE flight_id = " . (int)$booking['flight_id']);
        }

        mysqli_commit($conn);

        if ($refundPercentage > 0) {
            setAlert('Booking cancelled successfully. Refund calculated: ' . formatMoney($refundAmount) . ' (' . $refundPercentage . '%) - it is now Pending with our team.', 'success');
        } else {
            setAlert('Booking cancelled successfully. As this was cancelled less than 24 hours before departure, it is not eligible for a refund.', 'warning');
        }
        redirect(BASE_URL . 'user/booking-history.php');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        setAlert('Something went wrong while cancelling. Please try again.', 'danger');
        redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:650px;">
    <div class="dash-card text-center mb-4">
      <i class="fa-solid fa-triangle-exclamation text-danger fs-1 mb-3"></i>
      <h4>Cancel Booking <?php echo clean($booking['booking_reference']); ?>?</h4>
      <p class="text-muted mb-0">You are about to cancel your booking for flight <?php echo clean($booking['flight_number']); ?>
        (<?php echo clean($booking['source']); ?> &rarr; <?php echo clean($booking['destination']); ?>) on <?php echo formatDate($booking['departure_date']); ?>.
        This action cannot be undone.</p>
    </div>

    <div class="dash-card mb-4">
      <h5 class="mb-3"><i class="fa-solid fa-receipt text-primary"></i> Refund Breakdown</h5>
      <div class="ticket-row"><span class="label">Original Payment Amount</span><span class="value"><?php echo formatMoney($booking['total_amount']); ?></span></div>
      <div class="ticket-row"><span class="label">Days Left Before Departure</span><span class="value"><?php echo $daysLeft; ?> day(s)</span></div>
      <div class="ticket-row"><span class="label">Refund Percentage</span><span class="value"><?php echo $refundPercentage; ?>%</span></div>
      <div class="ticket-row"><span class="label">Refund Amount</span><span class="value"><?php echo formatMoney($refundAmount); ?></span></div>
      <div class="ticket-row">
        <span class="label">Refund Status (after cancellation)</span>
        <span class="value">
          <?php if ($refundPercentage > 0): ?>
            <span class="badge bg-warning">Pending</span>
          <?php else: ?>
            <span class="badge bg-danger">Rejected - Not Eligible</span>
          <?php endif; ?>
        </span>
      </div>

      <hr>
      <p class="small text-muted mb-1"><i class="fa-solid fa-circle-info"></i> Our cancellation policy:</p>
      <ul class="small text-muted mb-0">
        <?php foreach (getRefundPolicyTiers() as $tier): ?>
          <li><?php echo clean($tier['label']); ?> - <strong><?php echo $tier['percentage']; ?>% refund</strong></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="dash-card text-center">
      <form method="POST" action="cancel-booking.php">
        <input type="hidden" name="booking_id" value="<?php echo $bookingId; ?>">
        <button type="submit" class="btn btn-danger me-2">Yes, Cancel Booking</button>
        <a href="view-booking.php?id=<?php echo $bookingId; ?>" class="btn btn-outline-secondary">No, Go Back</a>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
