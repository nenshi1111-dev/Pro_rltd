<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'E-Ticket';

$bookingId = (int) (isset($_GET['booking_id']) ? $_GET['booking_id'] : 0);
$userId = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.airline_name, f.source, f.destination, f.departure_date, f.departure_time, f.arrival_time
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE booking_id = ? AND status = 'Active' ORDER BY passenger_id");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$passengers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$fareEach = passengerFareShare($booking);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <div class="no-print d-flex justify-content-between flex-wrap gap-2 mb-4">
      <a href="booking-history.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to My Bookings</a>
      <div class="d-flex gap-2 flex-wrap">
        <a href="view-booking.php?id=<?php echo $bookingId; ?>" class="btn btn-outline-secondary"><i class="fa-solid fa-circle-info"></i> Booking Details</a>
        <a href="download-ticket.php?booking_id=<?php echo $bookingId; ?>" class="btn btn-outline-primary"><i class="fa-solid fa-download"></i> Download Ticket</a>
        <button onclick="window.print()" class="btn btn-primary-custom"><i class="fa-solid fa-print"></i> Print Ticket</button>
      </div>
    </div>

    <?php if ($booking['booking_status'] === 'Confirmed' && !empty($passengers)): ?>
    <?php foreach ($passengers as $p): ?>
      <div class="ticket-card mb-4">
        <div class="ticket-header">
          <h3><?php echo SITE_NAME; ?></h3>
          <p class="mb-0 text-muted">BOARDING TICKET</p>
        </div>
        <div class="ticket-row"><span class="label">Booking ID</span><span class="value"><?php echo clean($booking['booking_reference']); ?></span></div>
        <div class="ticket-row"><span class="label">Ticket Number</span><span class="value"><?php echo generateTicketNumber($p['passenger_id']); ?></span></div>
        <div class="ticket-row"><span class="label">Passenger</span><span class="value"><?php echo clean($p['full_name']); ?></span></div>
        <div class="ticket-row"><span class="label">Flight</span><span class="value"><?php echo clean($booking['flight_number']); ?></span></div>
        <div class="ticket-row"><span class="label">From</span><span class="value"><?php echo clean($booking['source']); ?></span></div>
        <div class="ticket-row"><span class="label">To</span><span class="value"><?php echo clean($booking['destination']); ?></span></div>
        <div class="ticket-row"><span class="label">Date</span><span class="value"><?php echo formatDate($booking['departure_date']); ?></span></div>
        <div class="ticket-row"><span class="label">Departure</span><span class="value"><?php echo formatTime($booking['departure_time']); ?></span></div>
        <div class="ticket-row"><span class="label">Arrival</span><span class="value"><?php echo formatTime($booking['arrival_time']); ?></span></div>
        <div class="ticket-row"><span class="label">Class</span><span class="value"><?php echo clean($p['travel_class']); ?></span></div>
        <div class="ticket-row"><span class="label">Seat</span><span class="value"><?php echo clean($p['seat_number']); ?></span></div>
        <div class="ticket-row"><span class="label">Fare</span><span class="value"><?php echo formatMoney($fareEach); ?></span></div>
        <div class="ticket-row" style="border-bottom:none;"><span class="label">Payment</span><span class="value text-success">PAID</span></div>
        <div class="ticket-status-confirmed"><i class="fa-solid fa-circle-check"></i> BOOKING CONFIRMED</div>
      </div>
    <?php endforeach; ?>
    <?php else: ?>
      <div class="alert alert-warning text-center">This booking is <?php echo clean($booking['booking_status']); ?> and no ticket is available.</div>
    <?php endif; ?>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
