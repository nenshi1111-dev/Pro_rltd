<?php
/* ============================================================
   AIRSMART AI - COMMON HELPER FUNCTIONS
   Small reusable functions used across user and admin pages.
   ============================================================ */

// Clean user input to prevent XSS when displaying data
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/* ============================================================
   PHP 5.4 COMPATIBILITY HELPER
   ------------------------------------------------------------
   mysqli_stmt_bind_param($stmt, $types, ...$params) uses the "..."
   argument-unpacking operator, which was only added in PHP 5.6.0
   and is NOT available in PHP 5.4.31 (it causes a parse error).
   This helper does the exact same job the old-fashioned way, using
   call_user_func_array() with by-reference values, which has always
   worked since PHP 5.3.
   ============================================================ */
function bindParamsArray($stmt, $types, $params) {
    if (empty($params)) {
        return true;
    }
    $refs = array();
    $refs[] = $stmt;
    $refs[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        // must be actual references, not copies, for bind_param to work
        $refs[] = &$params[$i];
    }
    return call_user_func_array('mysqli_stmt_bind_param', $refs);
}

// Generate a unique booking reference like AS20260815001
function generateBookingReference($conn) {
    $prefix = 'AS' . date('Ymd');
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_reference LIKE '$prefix%'");
    $row = mysqli_fetch_assoc($result);
    $next = $row['total'] + 1;
    return $prefix . str_pad($next, 3, '0', STR_PAD_LEFT);
}

// Generate a simple transaction id
function generateTransactionId() {
    return 'TXN' . time() . rand(100, 999);
}

// Generate a ticket number from the passenger id, e.g. TKT000001
function generateTicketNumber($passengerId) {
    return 'TKT' . str_pad($passengerId, 6, '0', STR_PAD_LEFT);
}

// Format a date nicely, e.g. 25 Aug 2026
function formatDate($date) {
    return date('d M Y', strtotime($date));
}

// Format time nicely, e.g. 10:30 AM
function formatTime($time) {
    return date('h:i A', strtotime($time));
}

// Format money with Indian Rupee symbol
function formatMoney($amount) {
    return '₹' . number_format($amount, 2);
}

// Redirect helper
function redirect($url) {
    header('Location: ' . $url);
    exit();
}

// Show a bootstrap alert message from session (used after redirects)
function showAlert() {
    if (isset($_SESSION['alert_message'])) {
        $type = isset($_SESSION['alert_type']) ? $_SESSION['alert_type'] : 'info';
        $msg = $_SESSION['alert_message'];
        echo '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">'
            . clean($msg) .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['alert_message']);
        unset($_SESSION['alert_type']);
    }
}

// Set an alert message to show after redirect
function setAlert($message, $type = 'info') {
    $_SESSION['alert_message'] = $message;
    $_SESSION['alert_type'] = $type; // success, danger, warning, info
}

/* ============================================================
   SIMPLE STUDENT-LEVEL "AI" FLIGHT RECOMMENDATION SCORING
   (Section 8 of the project prompt - no external AI API needed)

   Score = Price Score + Availability Score + Time Score + Route Match Score
   Shared by flights.php and user/search-flights.php so the logic
   is written only once (reusable include rule).
   ============================================================ */
function calculateFlightScore($flight, $travelClass, $searchedSource = '', $searchedDestination = '') {
    $price = ($travelClass === 'Business') ? $flight['business_price'] : $flight['economy_price'];
    $available = ($travelClass === 'Business') ? $flight['business_available_seats'] : $flight['economy_available_seats'];

    // Price Score: cheaper flights score higher (max 40 points)
    $priceScore = max(0, 40 - ($price / 200));

    // Availability Score: more available seats score higher (max 25 points)
    $availabilityScore = min(25, $available / 6);

    // Time Score: convenient daytime departure scores higher (max 20 points)
    $hour = (int) date('H', strtotime($flight['departure_time']));
    $timeScore = ($hour >= 6 && $hour <= 21) ? 20 : 10;

    // Route Match Score: exact source/destination match scores higher (max 15 points)
    $routeScore = 0;
    if ($searchedSource !== '' && stripos($flight['source'], $searchedSource) !== false) $routeScore += 8;
    if ($searchedDestination !== '' && stripos($flight['destination'], $searchedDestination) !== false) $routeScore += 7;
    if ($searchedSource === '' && $searchedDestination === '') $routeScore = 10;

    $total = round($priceScore + $availabilityScore + $timeScore + $routeScore, 1);

    // Simple human-readable reason
    $reasons = [];
    if ($priceScore >= 25) $reasons[] = 'lower price';
    if ($availabilityScore >= 15) $reasons[] = 'good seat availability';
    if ($timeScore == 20) $reasons[] = 'convenient departure time';
    if ($routeScore >= 8) $reasons[] = 'matches your searched route';
    if (empty($reasons)) $reasons[] = 'overall balanced score';

    $reasonText = 'Recommended because it has ' . implode(' and ', $reasons) . '.';

    return ['score' => $total, 'reason' => $reasonText];
}

/* ============================================================
   REFUND SYSTEM: percentage-based refund calculation
   Based on how many days remain before the flight's departure
   date at the moment of cancellation. Shared by the user and
   admin cancellation flows so the policy is written only once.
   ============================================================ */
function getRefundPolicyTiers() {
    return [
        ['label' => '7 or more days before departure', 'percentage' => 90],
        ['label' => '3 to 6 days before departure',     'percentage' => 50],
        ['label' => '1 to 2 days before departure',      'percentage' => 25],
        ['label' => 'Less than 24 hours / same day',     'percentage' => 0],
    ];
}

// Returns the refund percentage (0-100) that applies for a given departure date
function calculateRefundPercentage($departureDate) {
    $daysLeft = (strtotime($departureDate) - strtotime(date('Y-m-d'))) / 86400;
    if ($daysLeft >= 7) return 90;
    if ($daysLeft >= 3) return 50;
    if ($daysLeft >= 1) return 25;
    return 0;
}

// Bootstrap badge colour for a refund_status value
function refundStatusBadge($status) {
    $map = ['Pending' => 'warning', 'Processing' => 'info', 'Completed' => 'success', 'Rejected' => 'danger', 'Not Applicable' => 'secondary'];
    return isset($map[$status]) ? $map[$status] : 'secondary';
}

/* ============================================================
   PER-PASSENGER CANCELLATION HELPERS
   A booking can hold more than one passenger (e.g. 4). These
   helpers let a single passenger be cancelled on their own
   without disturbing the other passengers on the same booking.
   ============================================================ */

// How many passengers on this booking are still Active (not cancelled individually)
function countActivePassengers($conn, $bookingId) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ? AND status = 'Active'");
    mysqli_stmt_bind_param($stmt, 'i', $bookingId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return (int) $row['total'];
}

// Fare share of a single passenger, based on the booking's original total amount
// spread evenly across the original passenger_count (so it stays stable even
// after other passengers on the same booking are cancelled one by one).
function passengerFareShare($booking) {
    $count = max(1, (int) $booking['passenger_count']);
    return round($booking['total_amount'] / $count, 2);
}

// Build the seat map (A-F economy / A-D business) sized to the flight's
// actual total seat count for that class, and mark already booked seats.
function buildSeatMap($conn, $flightId, $travelDate, $travelClass, $totalSeats) {
    $cols = ($travelClass === 'Business') ? ['A','B','C','D'] : ['A','B','C','D','E','F'];
    $colCount = count($cols);
    $rows = (int) ceil($totalSeats / $colCount);

    // Get already booked seats for this exact flight + date + class
    $booked = [];
    $stmt = mysqli_prepare($conn, "SELECT seat_number FROM seats WHERE flight_id = ? AND travel_date = ? AND travel_class = ? AND status = 'Booked'");
    mysqli_stmt_bind_param($stmt, 'iss', $flightId, $travelDate, $travelClass);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $booked[] = $row['seat_number'];
    }

    $map = [];
    $seatCount = 0;
    for ($r = 1; $r <= $rows; $r++) {
        $rowSeats = [];
        foreach ($cols as $c) {
            if ($seatCount >= $totalSeats) break; // stop once we reach the flight's real seat total
            $seatNo = $r . $c;
            $rowSeats[] = ['seat' => $seatNo, 'booked' => in_array($seatNo, $booked)];
            $seatCount++;
        }
        if (!empty($rowSeats)) $map[] = $rowSeats;
    }
    return $map;
}

/* ============================================================
   VALIDATION HELPERS
   ============================================================ */

// Full/cardholder/passenger names: alphabet characters and spaces only
function isAlphaName($name) {
    return preg_match('/^[A-Za-z ]+$/', $name) === 1;
}

// Airline flight numbers like 6E123, AI101, UK955:
// a 2-character airline code (letters and/or digits) followed by 1-4 digits
function isValidFlightNumber($flightNumber) {
    return preg_match('/^[A-Za-z0-9]{2}[0-9]{1,4}$/', $flightNumber) === 1;
}

// Whole years of age as of today for a given date of birth
function calculateAge($dob) {
    $dobTime = strtotime($dob);
    if ($dobTime === false) return 0;
    $today = new DateTime(date('Y-m-d'));
    $birth = new DateTime(date('Y-m-d', $dobTime));
    $diff = $today->diff($birth);
    return (int) $diff->y;
}

/* ============================================================
   FEEDBACK CONVERSATION HELPERS
   Feedback and its replies (from either the user or the admin)
   are stored separately in `feedback_replies` so the same thread
   can hold any number of back-and-forth replies, shown in
   chronological order, with no one-reply limit either side.
   ============================================================ */

// All replies for one feedback thread, oldest first
function getFeedbackReplies($conn, $feedbackId) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM feedback_replies WHERE feedback_id = ? ORDER BY created_at ASC, reply_id ASC");
    mysqli_stmt_bind_param($stmt, 'i', $feedbackId);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}

// Add a new message to a feedback thread. When the admin replies for the
// first time, the thread's status flips from Pending to Replied.
function insertFeedbackReply($conn, $feedbackId, $sender, $message) {
    $stmt = mysqli_prepare($conn, "INSERT INTO feedback_replies (feedback_id, sender, message) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'iss', $feedbackId, $sender, $message);
    $ok = mysqli_stmt_execute($stmt);
    if ($ok && $sender === 'admin') {
        mysqli_query($conn, "UPDATE feedback SET status = 'Replied' WHERE feedback_id = " . (int) $feedbackId . " AND status = 'Pending'");
    }
    return $ok;
}

/* ============================================================
   MINIMAL PDF GENERATOR (no external library needed)
   ------------------------------------------------------------
   Builds a small, valid multi-page PDF directly from raw PDF
   syntax so tickets can be downloaded as real .pdf files
   (Section 10) without needing Composer, cURL/internet access,
   or any third-party library - just core PHP string functions,
   which works fine on PHP 5.4.31.
   ============================================================ */

// Make a string safe to place inside a PDF text string: convert to a
// single-byte encoding the base PDF fonts understand, then escape the
// characters that are special inside PDF "(...)" strings.
function pdfEscapeText($text) {
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        if ($converted !== false) $text = $converted;
    }
    // Drop anything the base font still can't render, so the PDF stays valid
    $text = preg_replace('/[^\x20-\x7E]/', '', $text);
    $text = str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $text);
    return $text;
}

// One absolutely-positioned line of text as a PDF content-stream operator.
// $font is 'F1' (Helvetica) or 'F2' (Helvetica-Bold).
function pdfTextLine($font, $size, $x, $y, $text) {
    return 'BT /' . $font . ' ' . (int) $size . ' Tf 1 0 0 1 ' . (int) $x . ' ' . (int) $y . ' Tm (' . pdfEscapeText($text) . ') Tj ET';
}

// Format money for a PDF (the base Helvetica font has no Rupee glyph)
function formatMoneyPdf($amount) {
    return 'Rs. ' . number_format($amount, 2);
}

// Build a complete PDF file (as a raw byte string) from an array of pages,
// where each page is an array of content-stream operator lines (see
// pdfTextLine() above). Returns the finished PDF ready to be echoed with
// a Content-Type: application/pdf header.
function buildSimplePdf($pages) {
    $objects = array();
    $fontRegularNum = 3;
    $fontBoldNum = 4;
    $objects[$fontRegularNum] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
    $objects[$fontBoldNum]    = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";

    $nextObjNum = 5;
    $pageContentPairs = array();
    foreach ($pages as $pageLines) {
        $pageObjNum = $nextObjNum++;
        $contentObjNum = $nextObjNum++;
        $stream = implode("\n", $pageLines);
        $objects[$contentObjNum] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream";
        $pageContentPairs[$pageObjNum] = $contentObjNum;
    }

    $kids = array();
    foreach ($pageContentPairs as $pageObjNum => $contentObjNum) {
        $kids[] = "$pageObjNum 0 R";
    }
    $objects[2] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count " . count($kids) . " >>";
    $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";

    foreach ($pageContentPairs as $pageObjNum => $contentObjNum) {
        $objects[$pageObjNum] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            . "/Resources << /Font << /F1 $fontRegularNum 0 R /F2 $fontBoldNum 0 R >> >> "
            . "/Contents $contentObjNum 0 R >>";
    }

    ksort($objects);

    $pdf = "%PDF-1.4\n";
    $offsets = array();
    foreach ($objects as $num => $body) {
        $offsets[$num] = strlen($pdf);
        $pdf .= "$num 0 obj\n$body\nendobj\n";
    }

    $maxObj = max(array_keys($objects));
    $xrefOffset = strlen($pdf);
    $pdf .= "xref\n0 " . ($maxObj + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= $maxObj; $i++) {
        if (isset($offsets[$i])) {
            $pdf .= str_pad($offsets[$i], 10, '0', STR_PAD_LEFT) . " 00000 n \n";
        } else {
            $pdf .= "0000000000 00000 f \n";
        }
    }
    $pdf .= "trailer\n<< /Size " . ($maxObj + 1) . " /Root 1 0 R >>\n";
    $pdf .= "startxref\n$xrefOffset\n%%EOF";

    return $pdf;
}
?>
