<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Add Flight';

$errors = [];
$f = ['flight_number'=>'','airline_name'=>'Sky Book Airlines','source'=>'','destination'=>'','departure_date'=>'','departure_time'=>'','arrival_time'=>'','duration'=>'','economy_total_seats'=>150,'economy_price'=>'','business_total_seats'=>30,'business_price'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($f as $key => $val) {
        $f[$key] = clean(isset($_POST[$key]) ? $_POST[$key] : '');
    }

    if ($f['flight_number']==='' || $f['source']==='' || $f['destination']==='' || $f['departure_date']==='' || $f['departure_time']==='' || $f['arrival_time']==='' || $f['economy_price']==='' || $f['business_price']==='') {
        $errors[] = 'Please fill all required fields.';
    }
    if ($f['flight_number'] !== '') {
        $f['flight_number'] = strtoupper($f['flight_number']);
        if (!isValidFlightNumber($f['flight_number'])) {
            $errors[] = 'Flight number must be an airline code followed by 1-4 digits, e.g. 6E123, AI101, UK955.';
        }
    }
    if (strtolower($f['source']) === strtolower($f['destination'])) {
        $errors[] = 'Source and destination cannot be the same.';
    }
    if ($f['departure_date'] !== '' && strtotime($f['departure_date']) < strtotime(date('Y-m-d'))) {
        $errors[] = 'Departure date cannot be in the past.';
    }
    if (!is_numeric($f['economy_price']) || !is_numeric($f['business_price']) || $f['economy_price'] <= 0 || $f['business_price'] <= 0) {
        $errors[] = 'Prices must be valid positive numbers.';
    }
    $economySeats = (int)($f['economy_total_seats'] ?: 150);
    $businessSeats = (int)($f['business_total_seats'] ?: 30);
    if ($economySeats < 1 || $businessSeats < 1) {
        $errors[] = 'Seat counts must be at least 1.';
    }

    // Auto calculate duration if not provided
    $duration = $f['duration'];
    if ($duration === '' && $f['departure_time'] && $f['arrival_time']) {
        $diff = strtotime($f['arrival_time']) - strtotime($f['departure_time']);
        if ($diff < 0) $diff += 86400;
        $duration = floor($diff/3600) . 'h ' . str_pad(floor(($diff%3600)/60),2,'0',STR_PAD_LEFT) . 'm';
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "INSERT INTO flights (flight_number, airline_name, source, destination, departure_date, departure_time, arrival_time, duration, economy_total_seats, economy_available_seats, economy_price, business_total_seats, business_available_seats, business_price) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'ssssssssiidiid',
            $f['flight_number'], $f['airline_name'], $f['source'], $f['destination'], $f['departure_date'],
            $f['departure_time'], $f['arrival_time'], $duration,
            $economySeats, $economySeats, $f['economy_price'],
            $businessSeats, $businessSeats, $f['business_price']
        );
        mysqli_stmt_execute($stmt);
        setAlert('Flight added successfully.', 'success');
        redirect(BASE_URL . 'admin/flights/flights.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:800px;">
  <h5><i class="fa-solid fa-plane"></i> Add New Flight</h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="add-flight.php">
    <div class="row g-3">
      <div class="col-md-4"><label>Flight Number</label><input type="text" name="flight_number" class="form-control js-flight-number" style="text-transform:uppercase;" maxlength="6" pattern="[A-Za-z0-9]{2}[0-9]{1,4}" title="Airline code + 1-4 digits, e.g. 6E123, AI101, UK955" placeholder="e.g. 6E123" value="<?php echo clean($f['flight_number']); ?>" required></div>
      <div class="col-md-8"><label>Airline Name</label><input type="text" name="airline_name" class="form-control" value="<?php echo clean($f['airline_name']); ?>" required></div>
      <div class="col-md-6"><label>Source</label><input type="text" name="source" class="form-control" value="<?php echo clean($f['source']); ?>" required></div>
      <div class="col-md-6"><label>Destination</label><input type="text" name="destination" class="form-control" value="<?php echo clean($f['destination']); ?>" required></div>
      <div class="col-md-4"><label>Departure Date</label><input type="date" name="departure_date" class="form-control" value="<?php echo clean($f['departure_date']); ?>" min="<?php echo date('Y-m-d'); ?>" required></div>
      <div class="col-md-4"><label>Departure Time</label><input type="time" name="departure_time" class="form-control" value="<?php echo clean($f['departure_time']); ?>" required></div>
      <div class="col-md-4"><label>Arrival Time</label><input type="time" name="arrival_time" class="form-control" value="<?php echo clean($f['arrival_time']); ?>" required></div>
      <div class="col-md-6"><label>Economy Total Seats</label><input type="number" name="economy_total_seats" class="form-control" value="<?php echo clean($f['economy_total_seats']); ?>" min="1" required></div>
      <div class="col-md-6"><label>Economy Price (₹)</label><input type="number" step="0.01" name="economy_price" class="form-control" value="<?php echo clean($f['economy_price']); ?>" required></div>
      <div class="col-md-6"><label>Business Total Seats</label><input type="number" name="business_total_seats" class="form-control" value="<?php echo clean($f['business_total_seats']); ?>" min="1" required></div>
      <div class="col-md-6"><label>Business Price (₹)</label><input type="number" step="0.01" name="business_price" class="form-control" value="<?php echo clean($f['business_price']); ?>" required></div>
    </div>
    <div class="mt-4">
      <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Save Flight</button>
      <a href="flights.php" class="btn btn-outline-secondary">Cancel</a>
    </div>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
