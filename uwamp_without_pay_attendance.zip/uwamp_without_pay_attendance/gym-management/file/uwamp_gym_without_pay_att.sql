-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 20, 2026 at 04:00 PM
-- Server version: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `full_name`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$PaKz/Pl4SPGw4s7GGJROreeTdbO7DgSnaMVQhd2VRbDkiQX0E0ohq', 'Super Admin', 'admin@gympro.com', '2026-08-18 17:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `publish_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `posted_by_role` enum('Admin','Trainer') DEFAULT 'Admin',
  `posted_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `title`, `description`, `publish_date`, `posted_by_role`, `posted_by_id`) VALUES
(1, 'Welcome to Gym-Pro', 'You can now join more than one batch — as long as their timings do not overlap. Check the Batches page to see what is available.', '2026-08-18 17:33:21', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('Present','Absent') DEFAULT 'Present'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `member_id`, `batch_id`, `date`, `status`) VALUES
(1, 1, 1, '2026-08-18', 'Present'),
(2, 2, 3, '2026-08-18', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT '20',
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batches`
--

INSERT INTO `batches` (`batch_id`, `batch_name`, `start_time`, `end_time`, `capacity`, `status`) VALUES
(1, 'Morning Yoga', '06:00:00', '07:00:00', 20, 'Active'),
(2, 'Morning Strength', '06:00:00', '07:00:00', 25, 'Active'),
(3, 'Morning Cardio', '07:15:00', '08:15:00', 20, 'Active'),
(4, 'Evening Zumba', '17:00:00', '18:00:00', 20, 'Active'),
(5, 'Evening Strength', '18:15:00', '19:15:00', 25, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `batch_trainers`
--

CREATE TABLE `batch_trainers` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_trainers`
--

INSERT INTO `batch_trainers` (`id`, `batch_id`, `trainer_id`) VALUES
(1, 1, 2),
(2, 2, 1),
(3, 3, 1),
(4, 4, 2),
(5, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `equipment_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `purchase_date` date DEFAULT NULL,
  `condition_status` enum('New','Good','Needs Repair','Old') DEFAULT 'New',
  `vendor_name` varchar(100) DEFAULT NULL,
  `vendor_location` varchar(150) DEFAULT NULL,
  `vendor_mobile` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `equipment_name`, `quantity`, `purchase_date`, `condition_status`, `vendor_name`, `vendor_location`, `vendor_mobile`) VALUES
(1, 'Treadmill', 4, '2024-01-10', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222'),
(2, 'Dumbbell Set (5-25kg)', 10, '2024-02-15', 'New', 'FitGear Traders', 'Jamnagar', '9222222222'),
(3, 'Yoga Mats', 25, '2024-03-01', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `member_code` varchar(20) NOT NULL,
  `photo` varchar(255) DEFAULT 'default-member.png',
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration_months` int(11) NOT NULL DEFAULT '1',
  `membership_start_date` date NOT NULL,
  `membership_expiry_date` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Expired','Inactive') DEFAULT 'Active',
  `created_by` varchar(50) DEFAULT NULL,
  `created_method` enum('Request','Admin') DEFAULT 'Admin',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `member_code`, `photo`, `full_name`, `gender`, `dob`, `phone`, `email`, `address`, `emergency_contact`, `duration_months`, `membership_start_date`, `membership_expiry_date`, `username`, `password`, `status`, `created_by`, `created_method`, `created_at`) VALUES
(1, 'GM0001', 'default-member.png', 'Amit Verma', 'Male', '1998-05-12', '9111111111', 'amit.member@gympro.com', 'Jamnagar, Gujarat', '9111111112', 1, '2026-08-18', '2026-09-18', 'member1', '$2y$10$PaKz/Pl4SPGw4s7GGJROreeTdbO7DgSnaMVQhd2VRbDkiQX0E0ohq', 'Active', 'admin', 'Admin', '2026-08-18 17:33:18'),
(2, 'GM0002', 'default-member.png', 'Sneha Patel', 'Female', '2000-09-03', '9111111113', 'sneha.member@gympro.com', 'Rajkot, Gujarat', '9111111114', 3, '2026-08-18', '2026-11-18', 'member2', '$2y$10$PaKz/Pl4SPGw4s7GGJROreeTdbO7DgSnaMVQhd2VRbDkiQX0E0ohq', 'Active', 'admin', 'Admin', '2026-08-18 17:33:18');

-- --------------------------------------------------------

--
-- Table structure for table `member_batches`
--

CREATE TABLE `member_batches` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member_batches`
--

INSERT INTO `member_batches` (`id`, `member_id`, `batch_id`) VALUES
(1, 1, 1),
(2, 2, 3),
(3, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `renewal_requests`
--

CREATE TABLE `renewal_requests` (
  `renewal_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `requested_duration` int(11) DEFAULT '1',
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `renewal_request_batches`
--

CREATE TABLE `renewal_request_batches` (
  `id` int(11) NOT NULL,
  `renewal_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requested_members`
--

CREATE TABLE `requested_members` (
  `request_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT '1',
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requested_member_batches`
--

CREATE TABLE `requested_member_batches` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `setting_key`, `setting_value`) VALUES
(1, 'gym_name', 'Gym-Pro'),
(2, 'gym_address', 'Jamnagar, Gujarat, India'),
(3, 'gym_email', 'contact@gympro.com'),
(4, 'gym_phone', '9876543210'),
(5, 'max_batches_per_member', '3');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `trainer_id` int(11) NOT NULL,
  `trainer_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT 'default-trainer.png',
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`trainer_id`, `trainer_code`, `full_name`, `gender`, `phone`, `email`, `specialization`, `photo`, `username`, `password`, `status`, `created_at`) VALUES
(1, 'TR0001', 'Rahul Sharma', 'Male', '9000000001', 'rahul.trainer@gympro.com', 'Strength & Conditioning', 'default-trainer.png', 'trainer1', '$2y$10$PaKz/Pl4SPGw4s7GGJROreeTdbO7DgSnaMVQhd2VRbDkiQX0E0ohq', 'Active', '2026-08-18 17:33:16'),
(2, 'TR0002', 'Priya Nair', 'Female', '9000000002', 'priya.trainer@gympro.com', 'Yoga & Flexibility', 'default-trainer.png', 'trainer2', '$2y$10$PaKz/Pl4SPGw4s7GGJROreeTdbO7DgSnaMVQhd2VRbDkiQX0E0ohq', 'Active', '2026-08-18 17:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `workout_plans`
--

CREATE TABLE `workout_plans` (
  `workout_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `day_name` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `focus_area` varchar(100) DEFAULT NULL,
  `details` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workout_plans`
--

INSERT INTO `workout_plans` (`workout_id`, `batch_id`, `day_name`, `focus_area`, `details`) VALUES
(1, 2, 'Monday', 'Chest & Triceps', 'Bench press 4x10, Incline dumbbell press 3x12, Tricep pushdown 3x15'),
(2, 2, 'Wednesday', 'Back & Biceps', 'Pull-ups 4x8, Barbell rows 4x10, Bicep curls 3x12'),
(3, 1, 'Tuesday', 'Flexibility & Breathing', 'Sun salutations, standing poses, pranayama 15 min');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_attendance` (`member_id`,`batch_id`,`date`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_assignment` (`batch_id`,`trainer_id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `member_code` (`member_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_member_batch` (`member_id`,`batch_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD PRIMARY KEY (`renewal_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `renewal_id` (`renewal_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`trainer_id`),
  ADD UNIQUE KEY `trainer_code` (`trainer_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD PRIMARY KEY (`workout_id`),
  ADD UNIQUE KEY `unique_batch_day` (`batch_id`,`day_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `batches`
--
ALTER TABLE `batches`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `member_batches`
--
ALTER TABLE `member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  MODIFY `renewal_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `requested_members`
--
ALTER TABLE `requested_members`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `trainer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `workout_plans`
--
ALTER TABLE `workout_plans`
  MODIFY `workout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD CONSTRAINT `batch_trainers_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `batch_trainers_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`trainer_id`) ON DELETE CASCADE;

--
-- Constraints for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD CONSTRAINT `member_batches_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD CONSTRAINT `renewal_requests_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD CONSTRAINT `renewal_request_batches_ibfk_1` FOREIGN KEY (`renewal_id`) REFERENCES `renewal_requests` (`renewal_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_request_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD CONSTRAINT `requested_members_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD CONSTRAINT `requested_member_batches_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `requested_members` (`request_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `requested_member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD CONSTRAINT `workout_plans_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
