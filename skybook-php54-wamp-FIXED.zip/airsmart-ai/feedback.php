<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Feedback';

// A user must be logged in to submit feedback. Send them to login and
// bring them straight back here afterwards.
if (!isset($_SESSION['user_id'])) {
    setAlert('Please login to share your feedback with us.', 'info');
    redirect(BASE_URL . 'login.php');
}

$errors = [];
$oldMessage = '';
$oldRating = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = trim(isset($_POST['message']) ? $_POST['message'] : '');
    $rating = (int) (isset($_POST['rating']) ? $_POST['rating'] : 0);
    $oldMessage = $message;
    $oldRating = $rating;

    // ---------------- Validation ----------------
    if ($message === '') {
        $errors[] = 'Please enter your feedback message.';
    } elseif (mb_strlen($message) < 5) {
        $errors[] = 'Your feedback message is too short. Please share a few more details.';
    } elseif (mb_strlen($message) > 1000) {
        $errors[] = 'Your feedback message is too long (maximum 1000 characters).';
    }

    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Please select a star rating between 1 and 5.';
    }

    if (empty($errors)) {
        $message = clean($message);
        $userId = (int) $_SESSION['user_id'];
        $stmt = mysqli_prepare($conn, "INSERT INTO feedback (user_id, message, rating) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'isi', $userId, $message, $rating);

        if (mysqli_stmt_execute($stmt)) {
            redirect(BASE_URL . 'thank-you.php');
        } else {
            $errors[] = 'Something went wrong while submitting your feedback. Please try again.';
        }
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<section class="hero-section" style="padding:80px 0;">
  <div class="container">
    <h1><i class="fa-solid fa-comment-dots"></i> Share Your Feedback</h1>
    <p class="lead">Your experience helps us improve Sky Book for every traveller</p>
  </div>
</section>

<section class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-7">
      <div class="auth-card mx-0" style="max-width:100%;">

        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <ul class="mb-0">
              <?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="POST" action="feedback.php">
          <div class="mb-4 text-center">
            <label class="d-block mb-2 fw-semibold">How was your experience?</label>
            <div class="star-rating">
              <input type="radio" name="rating" id="star5" value="5" <?php echo $oldRating==5?'checked':''; ?>><label for="star5"><i class="fa-solid fa-star"></i></label>
              <input type="radio" name="rating" id="star4" value="4" <?php echo $oldRating==4?'checked':''; ?>><label for="star4"><i class="fa-solid fa-star"></i></label>
              <input type="radio" name="rating" id="star3" value="3" <?php echo $oldRating==3?'checked':''; ?>><label for="star3"><i class="fa-solid fa-star"></i></label>
              <input type="radio" name="rating" id="star2" value="2" <?php echo $oldRating==2?'checked':''; ?>><label for="star2"><i class="fa-solid fa-star"></i></label>
              <input type="radio" name="rating" id="star1" value="1" <?php echo $oldRating==1?'checked':''; ?>><label for="star1"><i class="fa-solid fa-star"></i></label>
            </div>
          </div>

          <div class="mb-3">
            <label>Your Feedback</label>
            <textarea name="message" rows="5" class="form-control" placeholder="Tell us what you liked, or what we can improve..." required><?php echo clean($oldMessage); ?></textarea>
          </div>

          <button type="submit" class="btn btn-primary-custom w-100 mt-2"><i class="fa-solid fa-paper-plane"></i> Submit Feedback</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
