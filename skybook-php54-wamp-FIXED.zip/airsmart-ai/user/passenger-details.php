<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Passenger Details';

// Must have started the booking wizard first
if (!isset($_SESSION['booking'])) {
    setAlert('Please search and select a flight first.', 'warning');
    redirect(BASE_URL . 'user/search-flights.php');
}
$booking = $_SESSION['booking'];
$passengerCount = (int) $booking['passenger_count'];

$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $booking['flight_id']);
mysqli_stmt_execute($stmt);
$flight = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passengers = [];
    for ($i = 0; $i < $passengerCount; $i++) {
        $name = clean(isset($_POST['full_name'][$i]) ? $_POST['full_name'][$i] : '');
        $gender = clean(isset($_POST['gender'][$i]) ? $_POST['gender'][$i] : '');
        $dob = clean(isset($_POST['dob'][$i]) ? $_POST['dob'][$i] : '');
        $idNumber = clean(isset($_POST['id_number'][$i]) ? $_POST['id_number'][$i] : '');

        if ($name === '' || $gender === '' || $dob === '' || $idNumber === '') {
            $errors[] = 'Please fill all fields for Passenger ' . ($i + 1) . '.';
            continue;
        }
        if (strtotime($dob) > time()) {
            $errors[] = 'Date of birth for Passenger ' . ($i + 1) . ' cannot be in the future.';
            continue;
        }
        $passengers[] = ['full_name' => $name, 'gender' => $gender, 'dob' => $dob, 'id_number' => $idNumber];
    }

    if (empty($errors)) {
        $_SESSION['booking']['passengers'] = $passengers;
        redirect(BASE_URL . 'user/seat-selection.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:850px;">
    <a href="booking.php?flight_id=<?php echo (int)$flight['flight_id']; ?>&class=<?php echo urlencode($booking['travel_class']); ?>&passengers=<?php echo $passengerCount; ?>" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back</a>

    <div class="dash-card">
      <h4 class="mb-1"><i class="fa-solid fa-users"></i> Passenger Details</h4>
      <p class="text-muted">Flight <?php echo clean($flight['flight_number']); ?> — <?php echo clean($flight['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($flight['destination']); ?> — <?php echo clean($booking['travel_class']); ?> Class — <?php echo $passengerCount; ?> Passenger(s)</p>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
      <?php endif; ?>

      <form method="POST" action="passenger-details.php">
        <?php for ($i = 0; $i < $passengerCount; $i++): ?>
          <div class="border rounded p-3 mb-3">
            <h6 class="text-primary mb-3">Passenger <?php echo $i + 1; ?></h6>
            <div class="row g-3">
              <div class="col-md-6">
                <label>Full Name</label>
                <input type="text" name="full_name[]" class="form-control" required>
              </div>
              <div class="col-md-3">
                <label>Gender</label>
                <select name="gender[]" class="form-select" required>
                  <option value="">Select</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div class="col-md-3">
                <label>Date of Birth</label>
                <input type="date" name="dob[]" class="form-control" max="<?php echo date('Y-m-d'); ?>" required>
              </div>
              <div class="col-md-6">
                <label>Passport / ID Number</label>
                <input type="text" name="id_number[]" class="form-control" placeholder="e.g. PAS1234567" required>
              </div>
            </div>
          </div>
        <?php endfor; ?>
        <button type="submit" class="btn btn-primary-custom w-100">Continue to Seat Selection <i class="fa-solid fa-arrow-right"></i></button>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
