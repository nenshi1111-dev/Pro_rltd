<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Recommended Flights';

/* Show top AI-scored upcoming flights (Section 8), without requiring
   the user to type a search first - a simple "smart picks" page. */
$travelClass = isset($_GET['travel_class']) ? clean($_GET['travel_class']) : 'Economy';

$result = mysqli_query($conn, "SELECT * FROM flights WHERE status='Scheduled' AND departure_date >= CURDATE()");
$flights = [];
while ($row = mysqli_fetch_assoc($result)) {
    $scoreData = calculateFlightScore($row, $travelClass);
    $row['ai_score'] = $scoreData['score'];
    $row['ai_reason'] = $scoreData['reason'];
    $flights[] = $row;
}
usort($flights, function ($a, $b) { if ($b['ai_score'] == $a['ai_score']) return 0; return ($b['ai_score'] < $a['ai_score']) ? -1 : 1; });
$flights = array_slice($flights, 0, 6);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="section-title text-start mb-2"><h2><i class="fa-solid fa-star text-warning"></i> Recommended For You</h2></div>
    <p class="text-muted mb-4">Top flights picked by Sky Book's simple recommendation algorithm, based on price, seat availability and departure time.</p>

    <form class="mb-4" method="GET">
      <label class="me-2 fw-semibold">Preferred Class:</label>
      <select name="travel_class" class="form-select d-inline-block w-auto" onchange="this.form.submit()">
        <option value="Economy" <?php echo $travelClass=='Economy'?'selected':''; ?>>Economy</option>
        <option value="Business" <?php echo $travelClass=='Business'?'selected':''; ?>>Business</option>
      </select>
    </form>

    <div class="row">
      <?php if (empty($flights)): ?>
        <p class="text-muted">No upcoming flights available right now.</p>
      <?php endif; ?>
      <?php foreach ($flights as $f): ?>
        <div class="col-md-6">
          <div class="flight-card">
            <span class="flight-number"><?php echo clean($f['flight_number']); ?></span>
            <span class="badge-recommend float-end">Score: <?php echo $f['ai_score']; ?>/100</span>
            <div class="route-time mt-2"><?php echo clean($f['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($f['destination']); ?></div>
            <small class="text-muted"><?php echo formatDate($f['departure_date']); ?> | <?php echo formatTime($f['departure_time']); ?></small>
            <p class="price mt-2 mb-1"><?php echo formatMoney($travelClass=='Business' ? $f['business_price'] : $f['economy_price']); ?></p>
            <p class="small text-muted"><?php echo clean($f['ai_reason']); ?></p>
            <a href="booking.php?flight_id=<?php echo $f['flight_id']; ?>&class=<?php echo urlencode($travelClass); ?>&passengers=1" class="btn btn-primary-custom w-100">Book Now</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <p class="text-center text-muted small mt-3"><i class="fa-solid fa-circle-info"></i> This is a project-level recommendation algorithm and does not use a real external AI API.</p>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
