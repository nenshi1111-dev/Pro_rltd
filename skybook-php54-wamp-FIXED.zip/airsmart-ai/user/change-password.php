<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Change Password';

$userId = $_SESSION['user_id'];
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $new = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirm = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

    $stmt = mysqli_prepare($conn, "SELECT password FROM users WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$row || !password_verify($current, $row['password'])) {
        $errors[] = 'Current password is incorrect.';
    }
    if (strlen($new) < 6) {
        $errors[] = 'New password must be at least 6 characters long.';
    }
    if ($new !== $confirm) {
        $errors[] = 'New password and confirm password do not match.';
    }

    if (empty($errors)) {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $hashed, $userId);
        mysqli_stmt_execute($stmt);
        $success = true;
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="auth-wrapper" style="min-height:auto;">
    <div class="auth-card">
      <h3><i class="fa-solid fa-key text-primary"></i> Change Password</h3>
      <p class="sub">Update your account password</p>

      <?php if ($success): ?>
        <div class="alert alert-success">Password updated successfully.</div>
      <?php endif; ?>
      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
      <?php endif; ?>

      <form method="POST" action="change-password.php">
        <div class="mb-3">
          <label>Current Password</label>
          <div class="password-wrapper">
            <input type="password" name="current_password" class="form-control" required>
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
        <div class="mb-3">
          <label>New Password</label>
          <div class="password-wrapper">
            <input type="password" name="new_password" class="form-control" required>
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
        <div class="mb-3">
          <label>Confirm New Password</label>
          <div class="password-wrapper">
            <input type="password" name="confirm_password" class="form-control" required>
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
        <button type="submit" class="btn btn-primary-custom w-100">Update Password</button>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
