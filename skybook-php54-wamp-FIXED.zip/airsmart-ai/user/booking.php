<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Book Flight';

$userId = $_SESSION['user_id'];
$errors = [];

// Flight id can come from GET (first visit) or POST (form resubmit)
$flightId = isset($_POST['flight_id']) ? (int)$_POST['flight_id'] : (int) (isset($_GET['flight_id']) ? $_GET['flight_id'] : 0);
$travelClass = clean(isset($_POST['travel_class']) ? $_POST['travel_class'] : (isset($_GET['class']) ? $_GET['class'] : 'Economy'));
$passengerCount = (int)(isset($_POST['passengers']) ? $_POST['passengers'] : (isset($_GET['passengers']) ? $_GET['passengers'] : 1));

// ---------------- Load flight ----------------
$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ? AND status != 'Cancelled'");
mysqli_stmt_bind_param($stmt, 'i', $flightId);
mysqli_stmt_execute($stmt);
$flight = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$flight) {
    setAlert('Selected flight was not found.', 'danger');
    redirect(BASE_URL . 'user/search-flights.php');
}

// ---------------- Rule 1: Future date only ----------------
$departureDateTime = strtotime($flight['departure_date'] . ' ' . $flight['departure_time']);
if ($departureDateTime < time()) {
    $errors[] = 'This flight has already departed and cannot be booked.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($travelClass !== 'Economy' && $travelClass !== 'Business') {
        $errors[] = 'Please select a valid travel class.';
    }
    if ($passengerCount < 1 || $passengerCount > 9) {
        $errors[] = 'Number of passengers must be between 1 and 9.';
    }

    // ---------------- Rule 3 & 4: Seat availability ----------------
    $availableSeats = ($travelClass === 'Business') ? $flight['business_available_seats'] : $flight['economy_available_seats'];
    if (empty($errors) && $availableSeats < $passengerCount) {
        $errors[] = "No seats available in this class for $passengerCount passenger(s). Only $availableSeats seat(s) left.";
    }

    // ---------------- Rule 7: One booking per day (if enabled in settings) ----------------
    if (empty($errors) && getSetting($conn, 'one_booking_per_day', '0') === '1') {
        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings b JOIN flights f ON b.flight_id = f.flight_id
            WHERE b.user_id = ? AND f.departure_date = ? AND b.booking_status IN ('Pending','Confirmed')");
        mysqli_stmt_bind_param($stmt, 'is', $userId, $flight['departure_date']);
        mysqli_stmt_execute($stmt);
        $already = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];
        if ($already > 0) {
            $errors[] = 'You have already made a booking for this travel date.';
        }
    }

    if (empty($errors)) {
        // Save the booking wizard data in session and move to passenger details
        $_SESSION['booking'] = [
            'flight_id' => $flightId,
            'travel_class' => $travelClass,
            'passenger_count' => $passengerCount,
            'passengers' => [],
            'seats' => []
        ];
        redirect(BASE_URL . 'user/passenger-details.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:750px;">
    <a href="search-flights.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Search</a>

    <div class="dash-card">
      <h4 class="mb-3"><i class="fa-solid fa-plane"></i> Confirm Flight & Class</h4>

      <div class="flight-card mb-4">
        <span class="flight-number"><?php echo clean($flight['flight_number']); ?></span> - <?php echo clean($flight['airline_name']); ?>
        <div class="route-time"><?php echo clean($flight['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($flight['destination']); ?></div>
        <small class="text-muted"><?php echo formatDate($flight['departure_date']); ?> | <?php echo formatTime($flight['departure_time']); ?> - <?php echo formatTime($flight['arrival_time']); ?> (<?php echo clean($flight['duration']); ?>)</small>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
      <?php endif; ?>

      <form method="POST" action="booking.php">
        <input type="hidden" name="flight_id" value="<?php echo (int)$flight['flight_id']; ?>">
        <div class="mb-3">
          <label class="form-label fw-semibold">Travel Class</label>
          <select name="travel_class" class="form-select">
            <option value="Economy" <?php echo $travelClass=='Economy'?'selected':''; ?>>Economy - <?php echo formatMoney($flight['economy_price']); ?> (<?php echo $flight['economy_available_seats']; ?> seats left)</option>
            <option value="Business" <?php echo $travelClass=='Business'?'selected':''; ?>>Business - <?php echo formatMoney($flight['business_price']); ?> (<?php echo $flight['business_available_seats']; ?> seats left)</option>
          </select>
        </div>
        <div class="mb-4">
          <label class="form-label fw-semibold">Number of Passengers</label>
          <input type="number" name="passengers" class="form-control" min="1" max="9" value="<?php echo (int)$passengerCount; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary-custom w-100">Continue to Passenger Details <i class="fa-solid fa-arrow-right"></i></button>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
