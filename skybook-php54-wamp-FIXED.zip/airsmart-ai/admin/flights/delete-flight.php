<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';

$flightId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);

// Do not delete a flight that already has bookings - cancel it instead
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $flightId);
mysqli_stmt_execute($stmt);
$hasBookings = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] > 0;

if ($hasBookings) {
    mysqli_query($conn, "UPDATE flights SET status='Cancelled' WHERE flight_id=" . (int)$flightId);
    setAlert('This flight has existing bookings, so it was marked Cancelled instead of being deleted.', 'warning');
} else {
    $stmt = mysqli_prepare($conn, "DELETE FROM flights WHERE flight_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $flightId);
    mysqli_stmt_execute($stmt);
    setAlert('Flight deleted successfully.', 'success');
}
redirect(BASE_URL . 'admin/flights/flights.php');
