<header class="admin-topbar">
  <button class="sidebar-toggle d-lg-none" onclick="document.querySelector('.admin-sidebar').classList.toggle('show')">
    <i class="fa-solid fa-bars"></i>
  </button>
  <h5 class="mb-0"><?php echo isset($pageTitle) ? clean($pageTitle) : 'Dashboard'; ?></h5>
  <div class="admin-user">
    <i class="fa-solid fa-circle-user"></i> <?php echo clean(isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Admin'); ?>
  </div>
</header>
<main class="admin-main">
  <?php showAlert(); ?>
