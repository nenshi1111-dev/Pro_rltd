<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';

$userId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);

// Deleting a user will also delete their bookings (ON DELETE CASCADE),
// so as a safer default we simply deactivate the account instead.
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$hasBookings = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'] > 0;

if ($hasBookings) {
    mysqli_query($conn, "UPDATE users SET status='Inactive' WHERE user_id=" . (int)$userId);
    setAlert('This user has booking history, so the account was deactivated instead of deleted.', 'warning');
} else {
    $stmt = mysqli_prepare($conn, "DELETE FROM users WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    setAlert('User deleted successfully.', 'success');
}
redirect(BASE_URL . 'admin/users/users.php');
