<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Manage Users';

$search = clean(isset($_GET['search']) ? $_GET['search'] : '');
$sql = "SELECT * FROM users WHERE 1=1";
$params = []; $types = '';
if ($search !== '') {
    $sql .= " AND (full_name LIKE ? OR email LIKE ? OR username LIKE ?)";
    $like = "%$search%";
    $params = [$like, $like, $like];
    $types = 'sss';
}
$sql .= " ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) bindParamsArray($stmt, $types, $params);
mysqli_stmt_execute($stmt);
$users = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <form method="GET" class="d-flex gap-2 mb-3">
    <input type="text" name="search" class="form-control" placeholder="Search name / email / username" value="<?php echo clean($search); ?>">
    <button class="btn btn-dark-blue"><i class="fa-solid fa-magnifying-glass"></i></button>
  </form>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Mobile</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (empty($users)): ?><tr><td colspan="7" class="text-center text-muted py-4">No users found.</td></tr><?php endif; ?>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo clean($u['full_name']); ?></td>
          <td><?php echo clean($u['username']); ?></td>
          <td><?php echo clean($u['email']); ?></td>
          <td><?php echo clean($u['mobile']); ?></td>
          <td><span class="badge bg-<?php echo $u['status']=='Active'?'success':'secondary'; ?>"><?php echo clean($u['status']); ?></span></td>
          <td><?php echo formatDate($u['created_at']); ?></td>
          <td>
            <a href="view-user.php?id=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i></a>
            <a href="edit-user.php?id=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-pen"></i></a>
            <a href="delete-user.php?id=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-outline-danger confirm-delete"><i class="fa-solid fa-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
