<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Edit User';

$userId = (int) (isset($_GET['id']) ? $_GET['id'] : (isset($_POST['user_id']) ? $_POST['user_id'] : 0));
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$u = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$u) {
    setAlert('User not found.', 'danger');
    redirect(BASE_URL . 'admin/users/users.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = clean($_POST['full_name']);
    $mobile = clean($_POST['mobile']);
    $address = clean($_POST['address']);
    $status = clean($_POST['status']);

    if ($fullName === '' || $mobile === '') {
        $errors[] = 'Full name and mobile number are required.';
    }
    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $errors[] = 'Mobile number must be exactly 10 digits.';
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "UPDATE users SET full_name=?, mobile=?, address=?, status=? WHERE user_id=?");
        mysqli_stmt_bind_param($stmt, 'ssssi', $fullName, $mobile, $address, $status, $userId);
        mysqli_stmt_execute($stmt);
        setAlert('User updated successfully.', 'success');
        redirect(BASE_URL . 'admin/users/users.php');
    }
    $u = array_merge($u, ['full_name'=>$fullName,'mobile'=>$mobile,'address'=>$address,'status'=>$status]);
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:700px;">
  <h5><i class="fa-solid fa-pen"></i> Edit User</h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="edit-user.php?id=<?php echo $userId; ?>">
    <div class="mb-3"><label>Full Name</label><input type="text" name="full_name" class="form-control" value="<?php echo clean($u['full_name']); ?>" required></div>
    <div class="mb-3"><label>Email (cannot be changed)</label><input type="email" class="form-control" value="<?php echo clean($u['email']); ?>" disabled></div>
    <div class="mb-3"><label>Mobile Number</label><input type="text" name="mobile" class="form-control" value="<?php echo clean($u['mobile']); ?>" maxlength="10" required></div>
    <div class="mb-3"><label>Address</label><textarea name="address" class="form-control" rows="2"><?php echo clean($u['address']); ?></textarea></div>
    <div class="mb-3">
      <label>Account Status</label>
      <select name="status" class="form-select">
        <option value="Active" <?php echo $u['status']=='Active'?'selected':''; ?>>Active</option>
        <option value="Inactive" <?php echo $u['status']=='Inactive'?'selected':''; ?>>Inactive (Blocked)</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Update User</button>
    <a href="users.php" class="btn btn-outline-secondary">Cancel</a>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
