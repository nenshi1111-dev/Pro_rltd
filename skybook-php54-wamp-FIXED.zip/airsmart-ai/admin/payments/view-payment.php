<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'View Payment';

$paymentId = (int) (isset($_GET['id']) ? $_GET['id'] : 0);
$stmt = mysqli_prepare($conn, "SELECT p.*, b.booking_reference, b.travel_class, u.full_name, u.email
    FROM payments p JOIN bookings b ON p.booking_id=b.booking_id JOIN users u ON b.user_id=u.user_id WHERE p.payment_id=?");
mysqli_stmt_bind_param($stmt, 'i', $paymentId);
mysqli_stmt_execute($stmt);
$p = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$p) {
    setAlert('Payment record not found.', 'danger');
    redirect(BASE_URL . 'admin/payments/payments.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:600px;">
  <h5><i class="fa-solid fa-credit-card"></i> Payment <?php echo clean($p['transaction_id']); ?></h5>
  <div class="ticket-row"><span class="label">Booking Ref</span><span class="value"><?php echo clean($p['booking_reference']); ?></span></div>
  <div class="ticket-row"><span class="label">User</span><span class="value"><?php echo clean($p['full_name']); ?> (<?php echo clean($p['email']); ?>)</span></div>
  <div class="ticket-row"><span class="label">Class</span><span class="value"><?php echo clean($p['travel_class']); ?></span></div>
  <div class="ticket-row"><span class="label">Card Number</span><span class="value"><?php echo clean($p['masked_card_number']); ?></span></div>
  <div class="ticket-row"><span class="label">Amount</span><span class="value"><?php echo formatMoney($p['amount']); ?></span></div>
  <div class="ticket-row"><span class="label">Status</span><span class="value"><?php echo clean($p['payment_status']); ?></span></div>
  <div class="ticket-row" style="border-bottom:none;"><span class="label">Date</span><span class="value"><?php echo formatDate($p['payment_date']); ?></span></div>
  <a href="payments.php" class="btn btn-outline-secondary mt-3">Back</a>
</div>
<?php require_once '../includes/footer.php'; ?>
