<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Manage Bookings';

$status = clean(isset($_GET['status']) ? $_GET['status'] : '');
$sql = "SELECT b.*, u.full_name, f.flight_number, f.source, f.destination FROM bookings b
    JOIN users u ON b.user_id=u.user_id JOIN flights f ON b.flight_id=f.flight_id WHERE 1=1";
$params = []; $types = '';
if ($status !== '') {
    $sql .= " AND b.booking_status = ?";
    $params[] = $status; $types .= 's';
}
$sql .= " ORDER BY b.booking_date DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) bindParamsArray($stmt, $types, $params);
mysqli_stmt_execute($stmt);
$bookings = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <form method="GET" class="d-flex gap-2 mb-3">
    <select name="status" class="form-select w-auto" onchange="this.form.submit()">
      <option value="">All Status</option>
      <?php foreach (['Pending','Confirmed','Completed','Cancelled'] as $s): ?>
        <option value="<?php echo $s; ?>" <?php echo $status==$s?'selected':''; ?>><?php echo $s; ?></option>
      <?php endforeach; ?>
    </select>
  </form>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Flight</th><th>Route</th><th>Class</th><th>Passengers</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (empty($bookings)): ?><tr><td colspan="9" class="text-center text-muted py-4">No bookings found.</td></tr><?php endif; ?>
      <?php foreach ($bookings as $b): ?>
        <?php $badgeMap = array('Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'); $badge = isset($badgeMap[$b['booking_status']]) ? $badgeMap[$b['booking_status']] : 'secondary'; ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['full_name']); ?></td>
          <td><?php echo clean($b['flight_number']); ?></td>
          <td><?php echo clean($b['source']); ?> → <?php echo clean($b['destination']); ?></td>
          <td><?php echo clean($b['travel_class']); ?></td>
          <td><?php echo (int)$b['passenger_count']; ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($b['booking_status']); ?></span></td>
          <td>
            <a href="view-booking.php?id=<?php echo $b['booking_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i></a>
            <?php if ($b['booking_status'] === 'Confirmed'): ?>
              <a href="cancel-booking.php?id=<?php echo $b['booking_id']; ?>" class="btn btn-sm btn-outline-danger confirm-cancel"><i class="fa-solid fa-ban"></i></a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
