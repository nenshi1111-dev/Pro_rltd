<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
$pageTitle = 'Admin Login';

if (isset($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin/index.php');
}

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean(isset($_POST['username']) ? $_POST['username'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if ($username === '' || $password === '') {
        $errorMsg = 'Invalid username or password.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT * FROM admins WHERE username = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $admin = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            redirect(BASE_URL . 'admin/index.php');
        } else {
            $errorMsg = 'Invalid username or password.';
        }
    }
}
require_once '../includes/header.php';
?>
<div class="auth-wrapper">
  <div class="auth-card">
    <h3><i class="fa-solid fa-user-shield text-primary"></i> Admin Login</h3>
    <p class="sub"><?php echo SITE_NAME; ?> Administration Panel</p>

    <?php if ($errorMsg): ?>
      <div class="alert alert-danger"><?php echo clean($errorMsg); ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
      <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required autofocus>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <div class="password-wrapper">
          <input type="password" name="password" class="form-control" required>
          <i class="fa-solid fa-eye toggle-eye"></i>
        </div>
      </div>
      <button type="submit" class="btn btn-primary-custom w-100 mt-2">Login</button>
    </form>
    <p class="text-center mt-4 mb-0"><a href="<?php echo BASE_URL; ?>index.php" class="small text-muted"><i class="fa-solid fa-arrow-left"></i> Back to Website</a></p>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASE_URL; ?>js/script.js"></script>
</body>
</html>
