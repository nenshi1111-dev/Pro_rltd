# CYBER-REPORT
### Cyber Crime Reporting & Case Management System
**Tagline:** "Report. Track. Protect."
**Created by:** Rachna & Yagni

A college final-year project built with PHP, MySQL (mysqli), HTML, CSS, JavaScript,
Bootstrap 5, and Chart.js — no framework required.

Tested and confirmed working on **XAMPP**, **WAMP**, and **UwAmp**.

---

## 1. Requirements

- XAMPP, WAMP, or UwAmp (PHP 7.4+ / 8.x, MySQL/MariaDB)
- A browser

## 2. Installation (all three servers work the same way)

1. **Copy the project folder** into your server's web root:
   - XAMPP: `C:\xampp\htdocs\cyber-report`
   - WAMP: `C:\wamp64\www\cyber-report`
   - UwAmp: `C:\UwAmp\www\cyber-report`

2. **Start Apache and MySQL** from your server's control panel.
   - In UwAmp, click the Apache and MySQL power icons in the main UwAmp window.

3. **Create the database**
   - Open phpMyAdmin (`http://localhost/phpmyadmin`, or the "phpMyAdmin" button
     in UwAmp's control panel).
   - Click **Import**, choose `sql/cyber_report.sql`, and run it.
   - This creates the `cyber_report` database, all tables, and dummy demo data.

4. **Visit the diagnostic page first**
   Before opening the site, open:
   `http://localhost/cyber-report/test-connection.php`

   This checks PHP version, required extensions, MySQL connectivity, folder
   permissions, and sessions — and tells you exactly which one is failing if
   something's wrong, instead of a raw PHP error. Fix anything marked **FAIL**,
   then re-load the page until everything shows **PASS**.

5. **Visit the site**
   `http://localhost/cyber-report/index.php`

   You do **not** need to edit any "base URL" setting — the project detects
   its own path automatically, so it works whether Apache's document root
   is `htdocs`, `www`, or anything else.

## 3. UwAmp-specific notes

UwAmp is lighter than XAMPP/WAMP and a few of its defaults differ, which is
the most common source of "works on XAMPP, breaks on UwAmp" issues. This
project has been adjusted to handle all of them automatically, but if
`test-connection.php` still shows a failure, check:

- **MySQL port**: UwAmp sometimes runs MySQL on a non-default port (e.g.
  3307) if another MySQL service (like a separate XAMPP install) is already
  using port 3306. Open UwAmp's control panel → MySQL tab to see the actual
  port, then update `DB_PORT` in `config/db.php` to match.
- **MySQL root password**: some UwAmp bundles set a default root password
  (often `root`) instead of leaving it blank. If `test-connection.php` shows
  "Access denied for user 'root'", open `config/db.php` and change:
  ```php
  define('DB_PASS', '');   // try 'root' here instead
  ```
- **PHP version selector**: UwAmp lets you switch PHP versions from its
  control panel. Any version from 7.4 up works; if you're unsure, pick the
  latest one offered.
- **mysqli exception crashes**: on PHP 8.1+, a failed database connection
  normally causes an uncaught fatal error instead of a friendly message.
  This project explicitly disables that behavior (`mysqli_report(MYSQLI_REPORT_OFF)`
  in `config/db.php`), so you'll always get the readable error page instead
  of a raw crash — on UwAmp, XAMPP, or WAMP alike.

## 4. Demo Login Credentials

| Role         | Username  | Password     |
|--------------|-----------|--------------|
| Admin        | admin     | Admin@123    |
| Citizen      | rahulm    | Citizen@123  |
| Investigator | vikramr   | Invest@123   |

(All dummy citizens use `Citizen@123`; all dummy investigators use `Invest@123`.)

If login ever fails with these credentials (rare cross-server bcrypt issue),
visit `http://localhost/cyber-report/reset_admin_password.php` once in your
browser to regenerate the admin hash correctly, then delete that file.

## 5. Folder Structure

```
cyber-report/
├── admin/                 Admin panel pages
├── investigator/          Investigator panel pages
├── citizen/                Citizen panel pages
├── includes/                Shared header/footer/sidebar includes
├── assets/                   CSS, JS
├── config/                    db.php, functions.php (helpers, auth, CSRF, auto BASE_URL)
├── uploads/
│   ├── evidence/            Uploaded complaint evidence (protected via .htaccess)
│   └── photos/              Reserved for profile photos
├── sql/cyber_report.sql       Full schema + dummy data
├── test-connection.php          Environment diagnostic — run this first
├── index.php, about.php, cyber-crimes.php, safety-tips.php,
│   complaint-guide.php, records.php, contact.php   Public site
├── register.php, login.php, logout.php
└── reset_admin_password.php     One-time utility (delete after use)
```

## 6. Key Features Implemented

- Role-based auth for Citizen / Investigator / Admin (separate tables & dashboards)
- Citizen: register, submit complaint with evidence upload, track status, respond to
  info requests, profile & password management
- Investigator: view only assigned complaints, add investigation updates, move status
  through the permitted workflow, profile & password management
- Admin: manage citizens, investigators (add/edit/activate/deactivate), assign
  complaints (assignment history preserved), manage crime categories, publish
  announcements, view reports/statistics with Chart.js, manage system settings
- Auto-generated complaint reference numbers (e.g. `CR2026000001`)
- Full status history log for every complaint
- Secure evidence upload: extension whitelist, blocked executable/script types,
  5 MB size limit, randomized stored filenames, `.htaccess` execution block
  (compatible with both Apache 2.2 and 2.4+, covering all three server bundles)
- CSRF tokens on all forms, prepared statements everywhere, `password_hash()` /
  `password_verify()`, `htmlspecialchars()` output escaping
- Public Records & Statistics page with live Chart.js visualizations (safe
  aggregate data only — no personal or case data)
- Search, filter, and pagination on all complaint listing screens
- Self-detecting base URL and cross-version-safe MySQL connection handling,
  so the same codebase runs unmodified on XAMPP, WAMP, and UwAmp

## 7. Notes

- This project intentionally implements **defensive** case-management functionality
  only — no offensive security tooling.
- Change `DB_PASS` and delete `reset_admin_password.php` and `test-connection.php`
  before any public deployment.
