<?php
/**
 * CYBER-REPORT :: Core Helper Functions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

/*
 * BASE_URL is detected automatically from the request path, so the project
 * works no matter what you name the project folder or which server
 * (XAMPP/htdocs, WAMP/www, UwAmp/www) you drop it into — no manual editing
 * needed. It walks up from whichever script is running (even one inside
 * admin/, citizen/, or investigator/) to find the project root.
 */
if (!defined('BASE_URL')) {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    // If we're inside a role subfolder, go up one level to the project root
    if (preg_match('#/(admin|citizen|investigator)$#', $scriptDir)) {
        $scriptDir = dirname($scriptDir);
    }
    $base = rtrim($scriptDir, '/') . '/';
    define('BASE_URL', $base === '//' ? '/' : $base);
}
define('EVIDENCE_DIR', __DIR__ . '/../uploads/evidence/');
define('PHOTO_DIR', __DIR__ . '/../uploads/photos/');
define('MAX_EVIDENCE_SIZE', 5 * 1024 * 1024); // 5 MB
define('ALLOWED_EVIDENCE_EXT', ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx']);

/* ---------------------------------------------------------------------
 * Sanitization / Output helpers
 * --------------------------------------------------------------------- */
function clean($str) {
    return htmlspecialchars(trim($str ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header('Location: ' . BASE_URL . ltrim($path, '/'));
    exit;
}

/* ---------------------------------------------------------------------
 * CSRF Protection
 * --------------------------------------------------------------------- */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        die('Security check failed. Please go back and try again.');
    }
}

/* ---------------------------------------------------------------------
 * Auth / Role Guards
 * --------------------------------------------------------------------- */
function is_logged_in() {
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

function current_role() {
    return $_SESSION['role'] ?? null;
}

function current_id() {
    return $_SESSION['user_id'] ?? null;
}

function current_name() {
    return $_SESSION['user_name'] ?? '';
}

function require_login($role = null) {
    if (!is_logged_in()) {
        redirect('login.php');
    }
    if ($role !== null && current_role() !== $role) {
        redirect('login.php');
    }
}

function require_role_prefix($prefix) {
    // Used inside admin/, investigator/, citizen/ folders
    require_login($prefix);
}

/* ---------------------------------------------------------------------
 * Complaint reference number generator -> CR2026000001
 * --------------------------------------------------------------------- */
function generate_complaint_number($conn) {
    $year = date('Y');
    $prefix = 'CR' . $year;
    $res = $conn->query("SELECT complaint_number FROM complaints WHERE complaint_number LIKE '{$prefix}%' ORDER BY id DESC LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $last = $res->fetch_assoc()['complaint_number'];
        $seq = (int) substr($last, strlen($prefix)) + 1;
    } else {
        $seq = 1;
    }
    return $prefix . str_pad($seq, 6, '0', STR_PAD_LEFT);
}

/* ---------------------------------------------------------------------
 * Status workflow
 * --------------------------------------------------------------------- */
function status_list() {
    return ['Submitted', 'Under Review', 'Assigned', 'Investigation In Progress',
            'Additional Information Required', 'Resolved', 'Closed', 'Rejected'];
}

function status_badge_class($status) {
    $map = [
        'Submitted' => 'secondary',
        'Under Review' => 'info',
        'Assigned' => 'primary',
        'Investigation In Progress' => 'warning',
        'Additional Information Required' => 'warning',
        'Resolved' => 'success',
        'Closed' => 'dark',
        'Rejected' => 'danger',
    ];
    return $map[$status] ?? 'secondary';
}

/**
 * Record a status change in status_history and update the complaints table.
 */
function change_complaint_status($conn, $complaint_id, $new_status, $changed_by_name, $user_role, $remarks = '') {
    $stmt = $conn->prepare("SELECT status FROM complaints WHERE id = ?");
    $stmt->bind_param('i', $complaint_id);
    $stmt->execute();
    $old = $stmt->get_result()->fetch_assoc();
    $old_status = $old['status'] ?? null;

    $stmt = $conn->prepare("UPDATE complaints SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $new_status, $complaint_id);
    $stmt->execute();

    $stmt = $conn->prepare("INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, user_role, remarks) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param('isssss', $complaint_id, $old_status, $new_status, $changed_by_name, $user_role, $remarks);
    $stmt->execute();
}

/* ---------------------------------------------------------------------
 * File upload: evidence (safe, randomized filenames, extension checks)
 * --------------------------------------------------------------------- */
function handle_evidence_upload($conn, $complaint_id, $file) {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'skipped' => true];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => 'Upload error occurred.'];
    }
    if ($file['size'] > MAX_EVIDENCE_SIZE) {
        return ['ok' => false, 'message' => 'File exceeds the 5 MB size limit.'];
    }

    $original = $file['name'];
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));

    if (!in_array($ext, ALLOWED_EVIDENCE_EXT, true)) {
        return ['ok' => false, 'message' => 'Only JPG, PNG, PDF, DOC, DOCX files are allowed.'];
    }
    // Explicitly block executable / script-like extensions regardless of the allow-list above
    $blocked = ['php', 'php3', 'php4', 'php5', 'phtml', 'exe', 'sh', 'bat', 'js', 'cmd', 'msi'];
    if (in_array($ext, $blocked, true)) {
        return ['ok' => false, 'message' => 'This file type is not permitted.'];
    }

    if (!is_dir(EVIDENCE_DIR)) {
        mkdir(EVIDENCE_DIR, 0755, true);
    }

    $stored = bin2hex(random_bytes(16)) . '.' . $ext;
    $target = EVIDENCE_DIR . $stored;

    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return ['ok' => false, 'message' => 'Failed to store the uploaded file.'];
    }

    $stmt = $conn->prepare("INSERT INTO evidence (complaint_id, original_name, stored_name, file_type, file_size) VALUES (?,?,?,?,?)");
    $stmt->bind_param('isssi', $complaint_id, $original, $stored, $ext, $file['size']);
    $stmt->execute();

    return ['ok' => true, 'skipped' => false];
}

/* ---------------------------------------------------------------------
 * Small utility: time-ago style formatting
 * --------------------------------------------------------------------- */
function format_date($datetime) {
    return date('d M Y, h:i A', strtotime($datetime));
}

function paginate($total_rows, $per_page, $current_page) {
    $total_pages = max(1, (int) ceil($total_rows / $per_page));
    $current_page = max(1, min($current_page, $total_pages));
    $offset = ($current_page - 1) * $per_page;
    return compact('total_pages', 'current_page', 'offset');
}
