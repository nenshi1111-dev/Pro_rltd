<?php
/**
 * CYBER-REPORT :: Database Connection
 * ------------------------------------------------------------------
 * Works with XAMPP, WAMP, and UwAmp out of the box using the defaults
 * below. If your local server uses different MySQL credentials or a
 * different port, just edit the four constants below — nothing else
 * in the project needs to change.
 *
 * Common defaults:
 *   XAMPP  -> host: localhost | user: root | pass: (empty)   | port: 3306
 *   WAMP   -> host: localhost | user: root | pass: (empty or 'root') | port: 3306
 *   UwAmp  -> host: localhost | user: root | pass: (empty or 'root') | port: 3306
 *             (UwAmp sometimes runs MySQL on 3307/3308 if another
 *              MySQL/XAMPP service is already using 3306 — check
 *              UwAmp's control panel > MySQL tab if the port below
 *              doesn't work.)
 * ------------------------------------------------------------------
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // try 'root' here if empty doesn't work
define('DB_NAME', 'cyber_report');
define('DB_PORT', 3306);        // change if your server uses a different MySQL port

/*
 * IMPORTANT: mysqli defaults to "exception mode" on PHP 8.1+, which means
 * a failed connection throws a fatal, uncaught error instead of letting us
 * show a friendly message. Turning this off keeps behaviour identical
 * across PHP 5.6 - 8.x, which is what lets this same codebase run on
 * XAMPP, WAMP, and UwAmp regardless of which PHP version each one bundles.
 */
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

if (!$conn || $conn->connect_error) {
    $err = $conn ? $conn->connect_error : 'Could not initialize MySQL connection.';
    http_response_code(500);
    echo '<div style="font-family:sans-serif;max-width:700px;margin:60px auto;padding:24px;border:1px solid #e2e8f0;border-radius:10px;background:#fff;">';
    echo '<h2 style="color:#b91c1c;margin-top:0;">Database Connection Failed</h2>';
    echo '<p><strong>Error reported by MySQL:</strong> ' . htmlspecialchars($err) . '</p>';
    echo '<p>This almost always means one of the following:</p>';
    echo '<ol style="line-height:1.7;">';
    echo '<li>MySQL is not running yet in your control panel (XAMPP / WAMP / UwAmp) — start it and refresh this page.</li>';
    echo '<li>The <code>cyber_report</code> database has not been imported yet — import <code>sql/cyber_report.sql</code> via phpMyAdmin.</li>';
    echo '<li>Your MySQL username/password/port differ from the defaults — edit <code>config/db.php</code> (currently: host <code>' . DB_HOST . '</code>, port <code>' . DB_PORT . '</code>, user <code>' . DB_USER . '</code>).</li>';
    echo '<li>Another server (XAMPP/WAMP/UwAmp) is already using port 3306 — check your control panel for the actual MySQL port and update <code>DB_PORT</code> in <code>config/db.php</code>.</li>';
    echo '</ol>';
    echo '<p>You can also open <a href="' . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\') . '/test-connection.php">test-connection.php</a> (adjust the link to your project folder) for a full environment diagnostic.</p>';
    echo '</div>';
    exit;
}

$conn->set_charset('utf8mb4');
