<?php
/**
 * CYBER-REPORT :: Environment Diagnostic
 * ------------------------------------------------------------------
 * Open this file directly in your browser, e.g.:
 *   http://localhost/cyber-report/test-connection.php
 *
 * It checks everything the project needs (PHP version, extensions,
 * MySQL connectivity, folder permissions) and tells you exactly what
 * to fix. Works the same way on XAMPP, WAMP, and UwAmp.
 *
 * Delete this file once everything shows green, for security.
 */

// Deliberately does NOT require config/functions.php, so this page still
// works even if the database connection itself is the thing that's broken.
error_reporting(E_ALL);
ini_set('display_errors', '1');

$rows = [];

function row(&$rows, $label, $ok, $detail = '') {
    $rows[] = [$label, $ok, $detail];
}

// 1. PHP version
$phpOk = version_compare(PHP_VERSION, '7.4.0', '>=');
row($rows, 'PHP version', $phpOk, 'Detected PHP ' . PHP_VERSION . ($phpOk ? ' (OK — 7.4+ required)' : ' (needs 7.4 or newer)'));

// 2. Required extensions
foreach (['mysqli', 'session', 'fileinfo'] as $ext) {
    row($rows, "PHP extension: {$ext}", extension_loaded($ext), extension_loaded($ext) ? 'Loaded' : 'Missing — enable it in php.ini and restart your server');
}

// 3. mysqli reporting mode sanity check
mysqli_report(MYSQLI_REPORT_OFF);
row($rows, 'mysqli exception mode disabled', true, 'Prevents fatal crashes on PHP 8.1+ when the DB is unreachable');

// 4. Database connection using the project's own config
$dbConfigFound = file_exists(__DIR__ . '/config/db.php');
row($rows, 'config/db.php present', $dbConfigFound);

$dbOk = false; $dbDetail = 'Could not read config/db.php';
if ($dbConfigFound) {
    // Read constants without triggering the friendly-error exit() in db.php
    $src = file_get_contents(__DIR__ . '/config/db.php');
    preg_match("/define\('DB_HOST',\s*'([^']*)'\)/", $src, $mHost);
    preg_match("/define\('DB_USER',\s*'([^']*)'\)/", $src, $mUser);
    preg_match("/define\('DB_PASS',\s*'([^']*)'\)/", $src, $mPass);
    preg_match("/define\('DB_NAME',\s*'([^']*)'\)/", $src, $mName);
    preg_match("/define\('DB_PORT',\s*(\d+)\)/", $src, $mPort);

    $host = $mHost[1] ?? 'localhost';
    $user = $mUser[1] ?? 'root';
    $pass = $mPass[1] ?? '';
    $name = $mName[1] ?? 'cyber_report';
    $port = isset($mPort[1]) ? (int)$mPort[1] : 3306;

    $testConn = @new mysqli($host, $user, $pass, '', $port);
    if ($testConn && !$testConn->connect_error) {
        row($rows, "MySQL server reachable ({$host}:{$port})", true, "Connected successfully as '{$user}'");
        $dbExists = $testConn->query("SHOW DATABASES LIKE '{$name}'");
        if ($dbExists && $dbExists->num_rows > 0) {
            row($rows, "Database '{$name}' exists", true);
            $testConn->select_db($name);
            $tableCheck = $testConn->query("SHOW TABLES LIKE 'complaints'");
            $tablesOk = $tableCheck && $tableCheck->num_rows > 0;
            row($rows, 'Tables imported (checked: complaints)', $tablesOk, $tablesOk ? 'Schema looks imported.' : "Run sql/cyber_report.sql via phpMyAdmin.");
            $dbOk = $tablesOk;
        } else {
            row($rows, "Database '{$name}' exists", false, "Import sql/cyber_report.sql — it will create this database automatically.");
        }
    } else {
        $connErr = $testConn ? $testConn->connect_error : 'Unknown connection error';
        row($rows, "MySQL server reachable ({$host}:{$port})", false, htmlspecialchars($connErr) . ' — check that MySQL is started in your control panel, and that host/port/user/password in config/db.php match it.');
    }
}

// 5. Writable folders
foreach (['uploads/evidence', 'uploads/photos'] as $dir) {
    $path = __DIR__ . '/' . $dir;
    $writable = is_dir($path) && is_writable($path);
    row($rows, "Folder writable: {$dir}", $writable, $writable ? 'OK' : 'Create the folder and/or grant write permission.');
}

// 6. Sessions
session_start();
$_SESSION['diagnostic_test'] = 1;
row($rows, 'PHP sessions working', isset($_SESSION['diagnostic_test']), 'Needed for login to work.');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cyber-Report — Environment Diagnostic</title>
<style>
  body{font-family:Arial,Helvetica,sans-serif;background:#f4f6fb;margin:0;padding:40px 20px;}
  .wrap{max-width:760px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 10px 30px rgba(0,0,0,.08);}
  h1{color:#0b1330;font-size:1.4rem;}
  table{width:100%;border-collapse:collapse;margin-top:16px;}
  td{padding:10px 8px;border-bottom:1px solid #e5e9f2;font-size:.92rem;vertical-align:top;}
  .ok{color:#16a34a;font-weight:bold;}
  .bad{color:#dc2626;font-weight:bold;}
  .detail{color:#64748b;font-size:.85rem;}
  .badge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:.75rem;}
  .badge.ok{background:#dcfce7;}
  .badge.bad{background:#fee2e2;}
</style>
</head>
<body>
<div class="wrap">
  <h1>Cyber-Report — Environment Diagnostic</h1>
  <p style="color:#64748b;font-size:.9rem;">This checks whether your XAMPP / WAMP / UwAmp setup meets everything the project needs.</p>
  <table>
    <?php foreach ($rows as [$label, $ok, $detail]): ?>
      <tr>
        <td style="width:45%;"><?= htmlspecialchars($label) ?></td>
        <td style="width:15%;"><span class="badge <?= $ok ? 'ok' : 'bad' ?>"><?= $ok ? 'PASS' : 'FAIL' ?></span></td>
        <td class="detail"><?= $detail ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <p style="margin-top:24px;font-size:.85rem;color:#64748b;">
    Once every row shows <strong>PASS</strong>, go to
    <a href="index.php">index.php</a> — the site is ready.
    Delete this file (<code>test-connection.php</code>) afterwards.
  </p>
</div>
</body>
</html>
