-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2026 at 01:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `full_name`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$FZfUHv3guye7/YgduByiROzfnJYJHqiekWExa2fzB1KofHRZUfa82', 'Super Admin', 'admin@gympro.com', '2026-09-10 10:14:21');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `publish_date` datetime DEFAULT current_timestamp(),
  `posted_by_role` enum('Admin','Trainer') DEFAULT 'Admin',
  `posted_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `title`, `description`, `publish_date`, `posted_by_role`, `posted_by_id`) VALUES
(1, 'Welcome to Gym-Pro', 'You can now join more than one batch — as long as their timings do not overlap. Check the Batches page to see what is available.', '2026-09-10 10:14:21', 'Admin', 1),
(2, 'New Trainer Joined', 'We are happy to welcome our new professional trainer to the gym.', '2026-09-11 17:05:38', 'Admin', 1),
(3, 'Yoga Session', 'A special yoga session will be conducted every morning from 6:00 AM to 7:00 AM.', '2026-09-11 17:06:12', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('Present','Absent') DEFAULT 'Present'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `member_id`, `batch_id`, `date`, `status`) VALUES
(1, 1, 1, '2026-09-10', 'Present'),
(2, 1, 1, '2026-09-09', 'Present'),
(3, 1, 1, '2026-09-08', 'Absent'),
(4, 1, 1, '2026-09-07', 'Present'),
(5, 2, 3, '2026-09-10', 'Present'),
(6, 2, 3, '2026-09-09', 'Present'),
(7, 2, 3, '2026-09-08', 'Present'),
(8, 2, 4, '2026-09-09', 'Absent'),
(9, 2, 4, '2026-09-08', 'Present'),
(10, 3, 3, '2026-09-11', 'Present'),
(11, 4, 3, '2026-09-11', 'Present'),
(12, 2, 3, '2026-09-11', 'Present'),
(13, 3, 5, '2026-09-11', 'Present'),
(14, 5, 5, '2026-09-11', 'Present'),
(15, 8, 5, '2026-09-11', 'Present'),
(16, 10, 5, '2026-09-11', 'Present'),
(17, 11, 5, '2026-09-11', 'Present'),
(18, 12, 2, '2026-09-11', 'Present'),
(19, 4, 2, '2026-09-11', 'Absent'),
(20, 8, 2, '2026-09-11', 'Present'),
(21, 11, 2, '2026-09-11', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 20,
  `monthly_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batches`
--

INSERT INTO `batches` (`batch_id`, `batch_name`, `start_time`, `end_time`, `capacity`, `monthly_fee`, `status`) VALUES
(1, 'Morning Yoga', '06:00:00', '07:00:00', 20, 800.00, 'Active'),
(2, 'Morning Strength', '06:00:00', '07:00:00', 25, 1000.00, 'Active'),
(3, 'Morning Cardio', '07:15:00', '08:15:00', 20, 700.00, 'Active'),
(4, 'Evening Zumba', '17:00:00', '18:00:00', 20, 900.00, 'Active'),
(5, 'Evening Strength', '18:15:00', '19:15:00', 25, 1000.00, 'Active'),
(6, 'CrossFit Training', '19:30:00', '20:30:00', 20, 1500.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `batch_trainers`
--

CREATE TABLE `batch_trainers` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_trainers`
--

INSERT INTO `batch_trainers` (`id`, `batch_id`, `trainer_id`) VALUES
(14, 1, 2),
(15, 1, 4),
(16, 2, 1),
(17, 2, 3),
(18, 2, 6),
(10, 3, 3),
(11, 3, 4),
(6, 4, 2),
(7, 4, 5),
(8, 5, 3),
(9, 5, 6),
(19, 6, 4),
(20, 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `equipment_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `purchase_date` date DEFAULT NULL,
  `condition_status` enum('New','Good','Needs Repair','Old') DEFAULT 'New',
  `vendor_name` varchar(100) DEFAULT NULL,
  `vendor_location` varchar(150) DEFAULT NULL,
  `vendor_mobile` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `equipment_name`, `quantity`, `purchase_date`, `condition_status`, `vendor_name`, `vendor_location`, `vendor_mobile`) VALUES
(1, 'Treadmill', 4, '2024-01-10', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222'),
(2, 'Dumbbell Set (5-25kg)', 10, '2024-02-15', 'New', 'FitGear Traders', 'Jamnagar', '9222222222'),
(3, 'Yoga Mats', 25, '2024-03-01', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `member_code` varchar(20) NOT NULL,
  `photo` varchar(255) DEFAULT 'default-member.png',
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration_months` int(11) NOT NULL DEFAULT 1,
  `membership_start_date` date NOT NULL,
  `membership_expiry_date` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Expired','Inactive') DEFAULT 'Active',
  `created_by` varchar(50) DEFAULT NULL,
  `created_method` enum('Request','Admin') DEFAULT 'Admin',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `member_code`, `photo`, `full_name`, `gender`, `dob`, `phone`, `email`, `address`, `emergency_contact`, `duration_months`, `membership_start_date`, `membership_expiry_date`, `username`, `password`, `status`, `created_by`, `created_method`, `created_at`) VALUES
(1, 'GM0001', 'default-member.png', 'Amit Verma', 'Male', '1998-05-12', '9111111111', 'amit.member@gympro.com', 'Jamnagar, Gujarat', '9111111112', 1, '2026-09-10', '2026-10-10', 'member1', '$2y$10$FZfUHv3guye7/YgduByiROzfnJYJHqiekWExa2fzB1KofHRZUfa82', 'Active', 'admin', 'Admin', '2026-09-10 10:14:21'),
(2, 'GM0002', 'default-member.png', 'Sneha Patel', 'Female', '2000-09-03', '9111111113', 'sneha.member@gympro.com', 'Rajkot, Gujarat', '9111111114', 3, '2026-09-10', '2026-12-10', 'member2', '$2y$10$FZfUHv3guye7/YgduByiROzfnJYJHqiekWExa2fzB1KofHRZUfa82', 'Active', 'admin', 'Admin', '2026-09-10 10:14:21'),
(3, 'GM0003', 'default-member.png', 'Arjun Shah', 'Male', '1988-06-02', '9988776655', 'arjun.shah@example.com', 'Navagadh Road, Jetpur', '9988776655', 1, '2026-09-11', '2026-10-11', 'Arjun', '$2y$10$KWg3oSsyq.08L7w/iEtai.NoKxkLGvqNTWAUM.8p946uOs80RAX/.', 'Active', 'Super Admin', 'Request', '2026-09-11 16:37:44'),
(4, 'GM0004', 'default-member.png', 'Karan Desai', 'Male', '1998-06-23', '9098765432', 'karan.desai@example.com', 'Gondal Road, Jetpur', '9098765432', 1, '2026-09-11', '2026-10-11', 'Karan', '$2y$10$8EYaR2d9Glu5I4ZCj2OMp.dBM2.uJg.NxS2ZRmEPV1.2Si5WZecbu', 'Active', 'Super Admin', 'Request', '2026-09-11 16:37:47'),
(5, 'GM0005', 'default-member.png', 'Priya Mehta', 'Female', '2001-02-11', 'Jetpur 9123456780', 'priya.mehta@example.com', 'Dhebar Road, Jetpur', 'Jetpur 9123456780', 3, '2026-09-11', '2026-12-11', 'Priya', '$2y$10$4aEgTJPT1tfyvkigIxAfM.v54oG07U7sDVYi05ftgjv.YSJjXcWYW', 'Active', 'Super Admin', 'Request', '2026-09-11 16:37:51'),
(7, 'GM0006', 'default-member.png', 'dhruti rupapara', 'Female', '2002-08-05', '5454545454', 'dhruti@gmail.com', 'navagadh road, jetpur', '5454545454', 1, '2026-08-18', '2026-09-18', 'dhruti', '$2y$10$HlW9ojhmShy8VF3GpZ0FDuumdNkVawDs3QAMLUmFAM7ED1BjqrRiK', 'Expired', 'admin', 'Request', '2026-09-11 16:42:56'),
(8, 'GM0007', 'default-member.png', 'rajveer rathod', 'Male', '1991-11-29', '7676767676', 'rajveer@gmail.com', 'jetpur', '7676767676', 1, '2026-08-16', '2026-09-16', 'rajveer', '$2y$10$BqqDCic2AE1AtrJr0/diLuugnlNCAibJdo0PVvIHivlJCnHj4.dTC', 'Active', 'admin', 'Admin', '2026-09-11 16:46:28'),
(9, 'GM0008', 'default-member.png', 'anju Shah', 'Male', '2002-08-05', '5555555555', 'anju@gmail.com', 'patel nagar,jetpur', '5555555555', 1, '2026-08-05', '2026-09-05', 'anju', '$2y$10$YdaVAXB0k5UKXnRPD7KMdeb2MA85FIHd/P4c6RwTKJZPfatwdx1jS', 'Expired', 'admin', 'Admin', '2026-09-11 16:50:19'),
(10, 'GM0010', 'default-member.png', 'Vishal Shah', 'Male', '2010-11-02', '2323232323', 'vishal@gmail.com', 'takuli,para jetpur', '2323232323', 1, '2026-09-11', '2026-10-11', 'vishal', '$2y$10$Pimu5ESAIPUvF2Bw/Ztvfup4c8UDUCM1m6oeCMP3SGHhSWRc9djXW', 'Active', 'Super Admin', 'Admin', '2026-09-11 17:08:16'),
(11, 'GM0011', 'default-member.png', 'vyas rachna', 'Female', '2001-06-26', '9000000078', 'rachna@gmail.com', 'jithudi road,jrtpur', '9000000078', 12, '2026-09-11', '2027-09-11', 'rachna', '$2y$10$PXfalAvRSUhoa3CBxWQXQOFCNa8maEO4LyAUbrHI2/OSmOu2OI9Fq', 'Active', 'Super Admin', 'Admin', '2026-09-11 17:09:20'),
(12, 'GM0012', 'default-member.png', 'Jay Patel', 'Male', '1990-06-12', '1212121212', 'jay@gmail.com', 'amarnagr road,jetpur', '1212121212', 1, '2026-09-11', '2026-10-11', 'jay', '$2y$10$JWScaIjiRGR.a4JJsh7Mou0mllkMxhhgUOS41NDwonNEqiYJ2cjZm', 'Active', 'Super Admin', 'Admin', '2026-09-11 17:10:40');

-- --------------------------------------------------------

--
-- Table structure for table `member_batches`
--

CREATE TABLE `member_batches` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member_batches`
--

INSERT INTO `member_batches` (`id`, `member_id`, `batch_id`) VALUES
(1, 1, 1),
(2, 2, 3),
(3, 2, 4),
(4, 3, 1),
(5, 3, 3),
(6, 3, 5),
(7, 4, 2),
(8, 4, 3),
(9, 4, 6),
(10, 5, 1),
(11, 5, 4),
(12, 5, 5),
(13, 8, 2),
(14, 8, 5),
(15, 10, 4),
(16, 10, 5),
(17, 10, 6),
(18, 11, 2),
(19, 11, 5),
(20, 11, 6),
(21, 12, 2),
(22, 12, 4),
(23, 12, 6);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `member_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('Cash','UPI','Card','Bank Transfer','Other') DEFAULT 'Cash',
  `notes` varchar(255) DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `receipt_number`, `member_id`, `amount`, `payment_date`, `payment_method`, `notes`, `recorded_by`, `created_at`) VALUES
(1, 'RC0001', 1, 800.00, '2026-09-10', 'Cash', 'First month payment', 1, '2026-09-10 10:14:21'),
(2, 'RC0002', 2, 3000.00, '2026-09-10', 'UPI', 'Partial payment for 3-month renewal', 1, '2026-09-10 10:14:21'),
(3, 'RC0003', 2, 1800.00, '2026-09-11', 'Cash', 'complete payment', 1, '2026-09-11 16:26:17'),
(4, 'RC0004', 8, 1400.00, '2026-09-11', 'Cash', 'first payment', 1, '2026-09-11 16:51:11'),
(5, 'RC0005', 5, 2000.00, '2026-09-11', 'Cash', 'first month', 1, '2026-09-11 16:51:43'),
(6, 'RC0006', 5, 4000.00, '2026-09-11', 'Cash', 'second payment', 1, '2026-09-11 16:52:04'),
(7, 'RC0007', 3, 2500.00, '2026-09-11', 'Cash', 'complete payment', 1, '2026-09-11 16:52:22'),
(8, 'RC0008', 8, 600.00, '2026-09-11', 'Cash', 'complete payment', 1, '2026-09-11 16:52:38');

-- --------------------------------------------------------

--
-- Table structure for table `renewal_requests`
--

CREATE TABLE `renewal_requests` (
  `renewal_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `requested_duration` int(11) DEFAULT 1,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT current_timestamp(),
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `renewal_requests`
--

INSERT INTO `renewal_requests` (`renewal_id`, `member_id`, `requested_duration`, `status`, `request_date`, `approved_date`, `approved_by`) VALUES
(1, 7, 3, 'Pending', '2026-09-11 17:03:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `renewal_request_batches`
--

CREATE TABLE `renewal_request_batches` (
  `id` int(11) NOT NULL,
  `renewal_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `renewal_request_batches`
--

INSERT INTO `renewal_request_batches` (`id`, `renewal_id`, `batch_id`) VALUES
(1, 1, 1),
(2, 1, 3),
(3, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `requested_members`
--

CREATE TABLE `requested_members` (
  `request_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT 1,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT current_timestamp(),
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requested_members`
--

INSERT INTO `requested_members` (`request_id`, `full_name`, `gender`, `dob`, `phone`, `email`, `address`, `emergency_contact`, `duration`, `username`, `password`, `status`, `request_date`, `approved_date`, `approved_by`) VALUES
(1, 'Priya Mehta', 'Female', '2001-02-11', 'Jetpur 9123456780', 'priya.mehta@example.com', 'Dhebar Road, Jetpur', 'Jetpur 9123456780', 3, 'Priya', '$2y$10$4aEgTJPT1tfyvkigIxAfM.v54oG07U7sDVYi05ftgjv.YSJjXcWYW', 'Approved', '2026-09-11 16:32:02', '2026-09-11 16:37:51', 1),
(2, 'Karan Desai', 'Male', '1998-06-23', '9098765432', 'karan.desai@example.com', 'Gondal Road, Jetpur', '9098765432', 1, 'Karan', '$2y$10$8EYaR2d9Glu5I4ZCj2OMp.dBM2.uJg.NxS2ZRmEPV1.2Si5WZecbu', 'Approved', '2026-09-11 16:33:57', '2026-09-11 16:37:47', 1),
(3, 'Arjun Shah', 'Male', '1988-06-02', '9988776655', 'arjun.shah@example.com', 'Navagadh Road, Jetpur', '9988776655', 1, 'Arjun', '$2y$10$KWg3oSsyq.08L7w/iEtai.NoKxkLGvqNTWAUM.8p946uOs80RAX/.', 'Approved', '2026-09-11 16:35:49', '2026-09-11 16:37:44', 1),
(4, 'Pooja Desai', 'Female', '2002-10-28', '9654321098', 'pooja.desai@example.com', 'Railway Colony, Jetpur', '9654321098', 6, 'Pooja', '$2y$10$swsQYY7tJ4DduLczq90AtO66NFeisDQXyUbEDzdJ.mlAhI/K1pVmm', 'Pending', '2026-09-11 16:37:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requested_member_batches`
--

CREATE TABLE `requested_member_batches` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requested_member_batches`
--

INSERT INTO `requested_member_batches` (`id`, `request_id`, `batch_id`) VALUES
(1, 1, 1),
(2, 1, 4),
(3, 1, 5),
(4, 2, 2),
(5, 2, 3),
(6, 2, 6),
(7, 3, 1),
(8, 3, 3),
(9, 3, 5),
(10, 4, 1),
(11, 4, 4),
(12, 4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `setting_key`, `setting_value`) VALUES
(1, 'gym_name', 'Gym-Pro'),
(2, 'gym_address', 'Jamnagar, Gujarat, India'),
(3, 'gym_email', 'contact@gympro.com'),
(4, 'gym_phone', '9876543210'),
(5, 'max_batches_per_member', '3');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `trainer_id` int(11) NOT NULL,
  `trainer_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT 'default-trainer.png',
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`trainer_id`, `trainer_code`, `full_name`, `gender`, `phone`, `email`, `specialization`, `photo`, `username`, `password`, `status`, `created_at`) VALUES
(1, 'TR0001', 'Rahul Sharma', 'Male', '9000000001', 'rahul.trainer@gympro.com', 'Strength & Conditioning', 'default-trainer.png', 'trainer1', '$2y$10$FZfUHv3guye7/YgduByiROzfnJYJHqiekWExa2fzB1KofHRZUfa82', 'Active', '2026-09-10 10:14:21'),
(2, 'TR0002', 'Priya Nair', 'Female', '9000000002', 'priya.trainer@gympro.com', 'Yoga & Flexibility', 'default-trainer.png', 'trainer2', '$2y$10$FZfUHv3guye7/YgduByiROzfnJYJHqiekWExa2fzB1KofHRZUfa82', 'Active', '2026-09-10 10:14:21'),
(3, 'TR0003', 'krish gujrati', 'Male', '9824923299', 'krish@gmail.com', 'Cardio, Strength', 'default-trainer.png', 'krish', '$2y$10$TDtH1Zm1v9usWWxhtRwkRuWeXeVBst0wQfjmKT8oH/JAbY1qZtJOS', 'Active', '2026-09-11 16:07:54'),
(4, 'TR0004', 'nenshi rathod', 'Female', '9274923299', 'nenshi@gmail.com', 'Weight Management and Chakra Healing Yoga', 'default-trainer.png', 'nenshi', '$2y$10$k.VkYU19wGrpgktEQw/7aOM.VUxifgDVvaU3xirA8bS12K65jRe9m', 'Active', '2026-09-11 16:11:24'),
(5, 'TR0005', 'pal nandaniya', 'Female', '1212121212', 'pal@gmail.com', 'Mind–Body Fitness and Zumba', 'default-trainer.png', 'pal', '$2y$10$4P/DPX3IJsu2hcWLp0Ip/O5fM9zeQpO8mZoYqxVNRv6aCC4GPXPSW', 'Active', '2026-09-11 16:13:12'),
(6, 'TR0006', 'nick joy', 'Male', '2323232323', 'nick@gmail.com', 'Fat Loss Coaching and Muscle Sculpting', 'default-trainer.png', 'nick', '$2y$10$9VxxF1qBKWojDBSoJijUJuhczhVIm6S7H07B0zN629ouf2r4yBote', 'Active', '2026-09-11 16:16:57');

-- --------------------------------------------------------

--
-- Table structure for table `workout_plans`
--

CREATE TABLE `workout_plans` (
  `workout_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `day_name` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `focus_area` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workout_plans`
--

INSERT INTO `workout_plans` (`workout_id`, `batch_id`, `day_name`, `focus_area`, `details`) VALUES
(1, 2, 'Monday', 'Chest & Triceps', 'Bench press 4x10, Incline dumbbell press 3x12, Tricep pushdown 3x15'),
(2, 2, 'Wednesday', 'Back & Biceps', 'Pull-ups 4x8, Barbell rows 4x10, Bicep curls 3x12'),
(3, 1, 'Tuesday', 'Flexibility & Breathing', 'Sun salutations, standing poses, pranayama 15 min');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_attendance` (`member_id`,`batch_id`,`date`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_assignment` (`batch_id`,`trainer_id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `member_code` (`member_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_member_batch` (`member_id`,`batch_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD PRIMARY KEY (`renewal_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `renewal_id` (`renewal_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`trainer_id`),
  ADD UNIQUE KEY `trainer_code` (`trainer_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD PRIMARY KEY (`workout_id`),
  ADD UNIQUE KEY `unique_batch_day` (`batch_id`,`day_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `batches`
--
ALTER TABLE `batches`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `member_batches`
--
ALTER TABLE `member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  MODIFY `renewal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `requested_members`
--
ALTER TABLE `requested_members`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `trainer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `workout_plans`
--
ALTER TABLE `workout_plans`
  MODIFY `workout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD CONSTRAINT `batch_trainers_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `batch_trainers_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`trainer_id`) ON DELETE CASCADE;

--
-- Constraints for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD CONSTRAINT `member_batches_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD CONSTRAINT `renewal_requests_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD CONSTRAINT `renewal_request_batches_ibfk_1` FOREIGN KEY (`renewal_id`) REFERENCES `renewal_requests` (`renewal_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_request_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD CONSTRAINT `requested_members_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD CONSTRAINT `requested_member_batches_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `requested_members` (`request_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `requested_member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD CONSTRAINT `workout_plans_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
