<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Contact Us';

$successMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $phone = clean($_POST['phone'] ?? '');
    $subject = clean($_POST['subject'] ?? '');
    $message = clean($_POST['message'] ?? '');

    if ($name !== '' && $email !== '' && $message !== '') {
        $stmt = mysqli_prepare($conn, "INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sssss', $name, $email, $phone, $subject, $message);
        mysqli_stmt_execute($stmt);
        $successMsg = 'Thank you for contacting Sky Book. We will get back to you soon.';
    } else {
        $successMsg = '';
        $errorMsg = 'Please fill all required fields.';
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<section class="hero-section" style="padding:80px 0;">
  <div class="container">
    <h1>Contact Us</h1>
    <p class="lead">We would love to hear from you</p>
  </div>
</section>

<section class="container my-5">
  <div class="row g-5">
    <div class="col-md-5">
      <h4 class="mb-4">Get In Touch</h4>
      <div class="feature-card stack mb-3 text-start">
        <i class="fa-solid fa-phone"></i>
        <h6>Phone</h6>
        <p class="mb-0">+91 98765 43210</p>
      </div>
      <div class="feature-card stack mb-3 text-start">
        <i class="fa-solid fa-envelope"></i>
        <h6>Email</h6>
        <p class="mb-0">support@skybook.com</p>
      </div>
      <div class="feature-card stack text-start">
        <i class="fa-solid fa-location-dot"></i>
        <h6>Address</h6>
        <p class="mb-0">Sky Book HQ, Rajkot, Gujarat, India</p>
      </div>
    </div>
    <div class="col-md-7">
      <div class="auth-card mx-0" style="max-width:100%;">
        <?php if (!empty($successMsg)): ?>
          <div class="alert alert-success"><?php echo clean($successMsg); ?></div>
        <?php endif; ?>
        <?php if (!empty($errorMsg)): ?>
          <div class="alert alert-danger"><?php echo clean($errorMsg); ?></div>
        <?php endif; ?>
        <form method="POST" action="contact.php">
          <div class="row g-3">
            <div class="col-md-6">
              <label>Name</label>
              <input type="text" name="name" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label>Email</label>
              <input type="email" name="email" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label>Phone</label>
              <input type="text" name="phone" class="form-control">
            </div>
            <div class="col-md-6">
              <label>Subject</label>
              <input type="text" name="subject" class="form-control">
            </div>
            <div class="col-12">
              <label>Message</label>
              <textarea name="message" rows="4" class="form-control" required></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary-custom mt-4 w-100">Send Message</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
