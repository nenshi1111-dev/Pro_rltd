<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once 'includes/auth.php';
$pageTitle = 'Dashboard';

// ---------------- Summary counts ----------------
$totalFlights = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM flights"))['total'];
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'];
$totalBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings"))['total'];
$totalRevenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_amount),0) AS total FROM bookings WHERE payment_status='Success'"))['total'];
$confirmedBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Confirmed'"))['total'];
$cancelledBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Cancelled'"))['total'];

// ---------------- Recent bookings ----------------
$recent = mysqli_query($conn, "SELECT b.*, u.full_name, f.flight_number FROM bookings b
    JOIN users u ON b.user_id = u.user_id JOIN flights f ON b.flight_id = f.flight_id
    ORDER BY b.booking_date DESC LIMIT 8");

// ---------------- Graph data: bookings & revenue trend, last 6 months ----------------
$trendResult = mysqli_query($conn, "SELECT DATE_FORMAT(booking_date,'%b %y') AS label, DATE_FORMAT(booking_date,'%Y-%m') AS ym,
    COUNT(*) AS bookings, SUM(CASE WHEN payment_status='Success' THEN total_amount ELSE 0 END) AS revenue
    FROM bookings WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym ORDER BY ym ASC");
$trendLabels = [];
$trendBookings = [];
$trendRevenue = [];
while ($row = mysqli_fetch_assoc($trendResult)) {
    $trendLabels[] = $row['label'];
    $trendBookings[] = (int) $row['bookings'];
    $trendRevenue[] = (float) $row['revenue'];
}

// ---------------- Graph data: booking status distribution ----------------
$statusCounts = ['Pending' => 0, 'Confirmed' => 0, 'Completed' => 0, 'Cancelled' => 0];
$statusResult = mysqli_query($conn, "SELECT booking_status, COUNT(*) AS total FROM bookings GROUP BY booking_status");
while ($row = mysqli_fetch_assoc($statusResult)) {
    $statusCounts[$row['booking_status']] = (int) $row['total'];
}

// ---------------- Graph data: top 5 routes by bookings ----------------
$routeResult = mysqli_query($conn, "SELECT CONCAT(f.source,' -> ',f.destination) AS route, COUNT(*) AS total
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id
    GROUP BY route ORDER BY total DESC LIMIT 5");
$routeLabels = [];
$routeCounts = [];
while ($row = mysqli_fetch_assoc($routeResult)) {
    $routeLabels[] = $row['route'];
    $routeCounts[] = (int) $row['total'];
}

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
require_once 'includes/topbar.php';
?>
<div class="row g-4 mb-4">
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-plane"></i></div>
      <div><h3><?php echo $totalFlights; ?></h3><p>Total Flights</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-users"></i></div>
      <div><h3><?php echo $totalUsers; ?></h3><p>Registered Users</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-ticket"></i></div>
      <div><h3><?php echo $totalBookings; ?></h3><p>Total Bookings</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div>
      <div><h3><?php echo formatMoney($totalRevenue); ?></h3><p>Total Revenue</p></div></div>
  </div>
</div>

<div class="row g-4 mb-4">
  <div class="col-md-6">
    <div class="stat-card"><div class="stat-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div>
      <div><h3><?php echo $confirmedBookings; ?></h3><p>Confirmed Bookings</p></div></div>
  </div>
  <div class="col-md-6">
    <div class="stat-card"><div class="stat-icon" style="color:var(--danger-red);"><i class="fa-solid fa-circle-xmark"></i></div>
      <div><h3><?php echo $cancelledBookings; ?></h3><p>Cancelled Bookings</p></div></div>
  </div>
</div>


<div class="row g-4 mb-4">
  <div class="col-lg-7">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-line text-primary"></i> Bookings &amp; Revenue Trend</h5>
      <p class="chart-sub">Last 6 months, based on all ticket bookings</p>
      <div class="chart-canvas-wrap h-260">
        <canvas id="trendChart"></canvas>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-pie text-primary"></i> Booking Status Distribution</h5>
      <p class="chart-sub">Across all bookings on the platform</p>
      <div class="chart-canvas-wrap h-260">
        <canvas id="statusChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="chart-card">
      <h5><i class="fa-solid fa-route text-primary"></i> Top 5 Routes by Bookings</h5>
      <p class="chart-sub">Most booked source → destination routes</p>
      <div class="chart-canvas-wrap h-220">
        <canvas id="routeChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <h5><i class="fa-solid fa-clock-rotate-left"></i> Recent Bookings</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Flight</th><th>Class</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php while ($b = mysqli_fetch_assoc($recent)): ?>
        <?php $badge = ['Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'][$b['booking_status']] ?? 'secondary'; ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['full_name']); ?></td>
          <td><?php echo clean($b['flight_number']); ?></td>
          <td><?php echo clean($b['travel_class']); ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($b['booking_status']); ?></span></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Chart.js for admin dashboard graphs -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
(function() {
  const trendLabels = <?php echo json_encode($trendLabels); ?>;

  new Chart(document.getElementById('trendChart'), {
    data: {
      labels: trendLabels,
      datasets: [
        {
          type: 'bar',
          label: 'Bookings',
          data: <?php echo json_encode($trendBookings); ?>,
          backgroundColor: 'rgba(30,144,255,0.55)',
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'line',
          label: 'Revenue (₹)',
          data: <?php echo json_encode($trendRevenue); ?>,
          borderColor: '#1fa971',
          backgroundColor: 'rgba(31,169,113,0.15)',
          borderWidth: 3,
          tension: 0.35,
          fill: true,
          pointBackgroundColor: '#1fa971',
          pointRadius: 4,
          yAxisID: 'y1',
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Poppins', size: 12 } } }
      },
      scales: {
        y: { beginAtZero: true, position: 'left', grid: { color: '#eef3fa' }, title: { display: true, text: 'Bookings' } },
        y1: { beginAtZero: true, position: 'right', grid: { display: false }, title: { display: true, text: 'Revenue (₹)' } },
        x: { grid: { display: false } }
      }
    }
  });

  new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
      labels: ['Confirmed', 'Pending', 'Completed', 'Cancelled'],
      datasets: [{
        data: [
          <?php echo (int) $statusCounts['Confirmed']; ?>,
          <?php echo (int) $statusCounts['Pending']; ?>,
          <?php echo (int) $statusCounts['Completed']; ?>,
          <?php echo (int) $statusCounts['Cancelled']; ?>
        ],
        backgroundColor: ['#1e90ff', '#f4b400', '#1fa971', '#dc3545'],
        borderWidth: 3,
        borderColor: '#fff',
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '62%',
      plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Poppins', size: 12 } } } }
    }
  });

  new Chart(document.getElementById('routeChart'), {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($routeLabels); ?>,
      datasets: [{
        label: 'Bookings',
        data: <?php echo json_encode($routeCounts); ?>,
        backgroundColor: '#0b2545',
        borderRadius: 6,
        maxBarThickness: 46
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, grid: { color: '#eef3fa' } },
        y: { grid: { display: false } }
      }
    }
  });
})();
</script>

<?php require_once 'includes/footer.php'; ?>
