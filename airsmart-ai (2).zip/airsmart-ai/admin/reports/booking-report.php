<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Booking Report';

$fromDate = clean($_GET['from'] ?? '');
$toDate = clean($_GET['to'] ?? '');

$sql = "SELECT b.*, u.full_name, f.flight_number FROM bookings b
    JOIN users u ON b.user_id=u.user_id JOIN flights f ON b.flight_id=f.flight_id WHERE 1=1";
$params = []; $types = '';
if ($fromDate !== '') { $sql .= " AND DATE(b.booking_date) >= ?"; $params[]=$fromDate; $types.='s'; }
if ($toDate !== '') { $sql .= " AND DATE(b.booking_date) <= ?"; $params[]=$toDate; $types.='s'; }
$sql .= " ORDER BY b.booking_date DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$bookings = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$totalConfirmed = 0; $totalCancelled = 0; $totalRevenue = 0;
foreach ($bookings as $b) {
    if ($b['booking_status']==='Confirmed' || $b['booking_status']==='Completed') { $totalConfirmed++; $totalRevenue += $b['total_amount']; }
    if ($b['booking_status']==='Cancelled') $totalCancelled++;
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="admin-card">
  <form method="GET" class="row g-2 align-items-end mb-2">
    <div class="col-auto"><label class="small">From</label><input type="date" name="from" class="form-control" value="<?php echo clean($fromDate); ?>"></div>
    <div class="col-auto"><label class="small">To</label><input type="date" name="to" class="form-control" value="<?php echo clean($toDate); ?>"></div>
    <div class="col-auto"><button class="btn btn-dark-blue"><i class="fa-solid fa-filter"></i> Filter</button></div>
  </form>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-circle-check"></i></div><div><h3><?php echo $totalConfirmed; ?></h3><p>Confirmed/Completed</p></div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-circle-xmark"></i></div><div><h3><?php echo $totalCancelled; ?></h3><p>Cancelled</p></div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div><div><h3><?php echo formatMoney($totalRevenue); ?></h3><p>Revenue in Range</p></div></div></div>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Flight</th><th>Amount</th><th>Status</th><th>Booked On</th></tr></thead>
      <tbody>
      <?php foreach ($bookings as $b): ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['full_name']); ?></td>
          <td><?php echo clean($b['flight_number']); ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><?php echo clean($b['booking_status']); ?></td>
          <td><?php echo formatDate($b['booking_date']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
