<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Flight Report';

$result = mysqli_query($conn, "SELECT f.*,
    (SELECT COUNT(*) FROM bookings b WHERE b.flight_id=f.flight_id AND b.booking_status IN ('Confirmed','Completed')) AS total_bookings,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.flight_id=f.flight_id AND b.payment_status='Success') AS revenue
    FROM flights f ORDER BY f.departure_date DESC");
$flights = mysqli_fetch_all($result, MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4">
  <li class="nav-item"><a class="nav-link active" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="admin-card">
  <h5><i class="fa-solid fa-plane"></i> Flight-wise Bookings & Revenue</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Flight No</th><th>Route</th><th>Date</th><th>Economy Sold</th><th>Business Sold</th><th>Total Bookings</th><th>Revenue</th></tr></thead>
      <tbody>
      <?php foreach ($flights as $f): ?>
        <tr>
          <td><?php echo clean($f['flight_number']); ?></td>
          <td><?php echo clean($f['source']); ?> → <?php echo clean($f['destination']); ?></td>
          <td><?php echo formatDate($f['departure_date']); ?></td>
          <td><?php echo $f['economy_total_seats'] - $f['economy_available_seats']; ?>/<?php echo $f['economy_total_seats']; ?></td>
          <td><?php echo $f['business_total_seats'] - $f['business_available_seats']; ?>/<?php echo $f['business_total_seats']; ?></td>
          <td><?php echo $f['total_bookings']; ?></td>
          <td><?php echo formatMoney($f['revenue']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
