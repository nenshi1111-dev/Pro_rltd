-- ============================================================
-- AIRSMART AI - AI BASED AIRLINE TICKET BOOKING SYSTEM
-- Database: airline_db
-- Import this file using phpMyAdmin (XAMPP / WAMP)
-- ============================================================

CREATE DATABASE IF NOT EXISTS airline_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE airline_db;

-- ------------------------------------------------------------
-- Table: admins
-- ------------------------------------------------------------
CREATE TABLE admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: users
-- ------------------------------------------------------------
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') NOT NULL,
    dob DATE NOT NULL,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    address VARCHAR(255) DEFAULT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: flights
-- ------------------------------------------------------------
CREATE TABLE flights (
    flight_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_number VARCHAR(20) NOT NULL,
    airline_name VARCHAR(100) NOT NULL,
    source VARCHAR(50) NOT NULL,
    destination VARCHAR(50) NOT NULL,
    departure_date DATE NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    duration VARCHAR(20) NOT NULL,
    economy_total_seats INT NOT NULL DEFAULT 150,
    economy_available_seats INT NOT NULL DEFAULT 150,
    economy_price DECIMAL(10,2) NOT NULL,
    business_total_seats INT NOT NULL DEFAULT 30,
    business_available_seats INT NOT NULL DEFAULT 30,
    business_price DECIMAL(10,2) NOT NULL,
    status ENUM('Scheduled','Delayed','Cancelled','Completed') DEFAULT 'Scheduled',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_route (source, destination),
    INDEX idx_date (departure_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: bookings
-- ------------------------------------------------------------
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(30) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    flight_id INT NOT NULL,
    travel_class ENUM('Economy','Business') NOT NULL,
    passenger_count INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
    payment_status ENUM('Pending','Success','Failed','Refunded') DEFAULT 'Pending',
    booking_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    cancellation_date DATETIME DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_flight (flight_id)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: passengers
-- ------------------------------------------------------------
CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') NOT NULL,
    dob DATE NOT NULL,
    id_number VARCHAR(50) DEFAULT NULL,
    seat_number VARCHAR(10) NOT NULL,
    travel_class ENUM('Economy','Business') NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: seats
-- ------------------------------------------------------------
CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    flight_id INT NOT NULL,
    travel_date DATE NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    travel_class ENUM('Economy','Business') NOT NULL,
    status ENUM('Available','Booked') DEFAULT 'Available',
    booking_id INT DEFAULT NULL,
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL,
    UNIQUE KEY uniq_seat (flight_id, travel_date, seat_number)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: payments
-- ------------------------------------------------------------
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    transaction_id VARCHAR(50) NOT NULL,
    masked_card_number VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('Pending','Success','Failed','Refunded') DEFAULT 'Pending',
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: announcements
-- ------------------------------------------------------------
CREATE TABLE announcements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    publish_date DATE NOT NULL,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_by INT DEFAULT NULL,
    FOREIGN KEY (created_by) REFERENCES admins(admin_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: cancellations
-- ------------------------------------------------------------
CREATE TABLE cancellations (
    cancellation_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    reason VARCHAR(255) DEFAULT NULL,
    cancelled_by ENUM('User','Admin') DEFAULT 'User',
    cancellation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    refund_amount DECIMAL(10,2) DEFAULT 0,
    refund_status ENUM('Pending','Refunded','Not Applicable') DEFAULT 'Pending',
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: settings
-- ------------------------------------------------------------
CREATE TABLE settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: contact_messages
-- ------------------------------------------------------------
CREATE TABLE contact_messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Table: feedback
-- Stores user feedback submitted from the Home Page Feedback
-- button, plus the admin's reply (Admin Feedback Management).
-- ------------------------------------------------------------
CREATE TABLE feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    rating TINYINT DEFAULT NULL,
    status ENUM('Pending','Replied') DEFAULT 'Pending',
    admin_reply TEXT DEFAULT NULL,
    replied_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE / DUMMY DATA
-- ============================================================

-- Admin account (username: admin / password: admin123)
INSERT INTO admins (username, full_name, password) VALUES
('admin', 'System Administrator', '$2b$10$pU4UYsqD5sfWzsy4mzc68OKMTmiFePWQyTsDREy7/P3aOrRC6JWs2');

-- Sample users (password for all: user123)
INSERT INTO users (full_name, gender, dob, mobile, email, address, username, password, status) VALUES
('Rahul Patel', 'Male', '1998-05-14', '9876543210', 'rahul.patel@example.com', 'Rajkot, Gujarat', 'rahulpatel', '$2b$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active'),
('Priya Shah', 'Female', '2000-08-22', '9876501234', 'priya.shah@example.com', 'Ahmedabad, Gujarat', 'priyashah', '$2b$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active'),
('Aman Verma', 'Male', '1995-11-02', '9998877665', 'aman.verma@example.com', 'Mumbai, Maharashtra', 'amanverma', '$2b$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active'),
('Sneha Joshi', 'Female', '1999-02-18', '9123456780', 'sneha.joshi@example.com', 'Pune, Maharashtra', 'snehajoshi', '$2b$10$oOq4p9cQNY1uZguMUDwZoOQ.IgadFNzewucNyKFW31fcnJMM3.leG', 'Active');

-- Sample flights
INSERT INTO flights (flight_number, airline_name, source, destination, departure_date, departure_time, arrival_time, duration, economy_total_seats, economy_available_seats, economy_price, business_total_seats, business_available_seats, business_price, status) VALUES
('AI101', 'Sky Book Airlines', 'Rajkot', 'Mumbai', DATE_ADD(CURDATE(), INTERVAL 5 DAY), '10:30:00', '12:00:00', '1h 30m', 150, 150, 4500.00, 30, 30, 9500.00, 'Scheduled'),
('AI102', 'Sky Book Airlines', 'Mumbai', 'Rajkot', DATE_ADD(CURDATE(), INTERVAL 5 DAY), '14:00:00', '15:30:00', '1h 30m', 150, 150, 4500.00, 30, 30, 9500.00, 'Scheduled'),
('AI205', 'Sky Book Airlines', 'Ahmedabad', 'Delhi', DATE_ADD(CURDATE(), INTERVAL 3 DAY), '07:15:00', '09:15:00', '2h 00m', 150, 150, 5200.00, 30, 30, 11000.00, 'Scheduled'),
('AI206', 'Sky Book Airlines', 'Delhi', 'Ahmedabad', DATE_ADD(CURDATE(), INTERVAL 3 DAY), '18:00:00', '20:00:00', '2h 00m', 150, 150, 5200.00, 30, 30, 11000.00, 'Scheduled'),
('AI310', 'Sky Book Airlines', 'Mumbai', 'Bengaluru', DATE_ADD(CURDATE(), INTERVAL 7 DAY), '06:45:00', '08:15:00', '1h 30m', 150, 150, 4800.00, 30, 30, 10200.00, 'Scheduled'),
('AI311', 'Sky Book Airlines', 'Bengaluru', 'Mumbai', DATE_ADD(CURDATE(), INTERVAL 7 DAY), '20:30:00', '22:00:00', '1h 30m', 150, 150, 4800.00, 30, 30, 10200.00, 'Scheduled'),
('AI415', 'Sky Book Airlines', 'Delhi', 'Goa', DATE_ADD(CURDATE(), INTERVAL 10 DAY), '09:00:00', '11:30:00', '2h 30m', 150, 150, 6200.00, 30, 30, 13000.00, 'Scheduled'),
('AI416', 'Sky Book Airlines', 'Goa', 'Delhi', DATE_ADD(CURDATE(), INTERVAL 10 DAY), '16:00:00', '18:30:00', '2h 30m', 150, 150, 6200.00, 30, 30, 13000.00, 'Scheduled'),
('AI520', 'Sky Book Airlines', 'Chennai', 'Kolkata', DATE_ADD(CURDATE(), INTERVAL 4 DAY), '11:00:00', '13:20:00', '2h 20m', 150, 150, 5600.00, 30, 30, 11800.00, 'Scheduled'),
('AI521', 'Sky Book Airlines', 'Kolkata', 'Chennai', DATE_ADD(CURDATE(), INTERVAL 4 DAY), '15:30:00', '17:50:00', '2h 20m', 150, 150, 5600.00, 30, 30, 11800.00, 'Scheduled'),
('AI102', 'Sky Book Airlines', 'Rajkot', 'Mumbai', DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00:00', '10:30:00', '1h 30m', 150, 148, 4300.00, 30, 29, 9200.00, 'Scheduled'),
('AI604', 'Sky Book Airlines', 'Jaipur', 'Mumbai', DATE_SUB(CURDATE(), INTERVAL 2 DAY), '08:00:00', '09:45:00', '1h 45m', 150, 150, 4700.00, 30, 30, 9900.00, 'Completed');

-- Sample bookings, passengers, seats and payments (linked to Rahul Patel - user_id 1, flight_id 1)
INSERT INTO bookings (booking_reference, user_id, flight_id, travel_class, passenger_count, total_amount, booking_status, payment_status, booking_date) VALUES
('AS20260810001', 1, 1, 'Economy', 2, 9450.00, 'Confirmed', 'Success', NOW()),
('AS20260810002', 2, 5, 'Business', 1, 10710.00, 'Confirmed', 'Success', NOW()),
('AS20260810003', 3, 12, 'Economy', 1, 4700.00, 'Completed', 'Success', NOW());

INSERT INTO passengers (booking_id, full_name, gender, dob, id_number, seat_number, travel_class) VALUES
(1, 'Rahul Patel', 'Male', '1998-05-14', 'PAS1234567', '12A', 'Economy'),
(1, 'Kavita Patel', 'Female', '2001-03-09', 'PAS7654321', '12B', 'Economy'),
(2, 'Priya Shah', 'Female', '2000-08-22', 'PAS1122334', '2A', 'Business'),
(3, 'Aman Verma', 'Male', '1995-11-02', 'PAS9988776', '15C', 'Economy');

INSERT INTO seats (flight_id, travel_date, seat_number, travel_class, status, booking_id) VALUES
(1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '12A', 'Economy', 'Booked', 1),
(1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '12B', 'Economy', 'Booked', 1),
(5, DATE_ADD(CURDATE(), INTERVAL 7 DAY), '2A', 'Business', 'Booked', 2),
(12, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '15C', 'Economy', 'Booked', 3);

INSERT INTO payments (booking_id, transaction_id, masked_card_number, amount, payment_status, payment_date) VALUES
(1, 'TXN100000001', '************3456', 9450.00, 'Success', NOW()),
(2, 'TXN100000002', '************7890', 10710.00, 'Success', NOW()),
(3, 'TXN100000003', '************1122', 4700.00, 'Success', NOW());

-- Sample announcements
INSERT INTO announcements (title, description, publish_date, status, created_by) VALUES
('Flight Schedule Updated', 'Please note that some flight timings have been revised for the upcoming week. Check your booking details for the latest schedule.', CURDATE(), 'Active', 1),
('Special Booking Offer', 'Get flat 10% off on Business class bookings made this month. Limited time offer for AirSmart AI users.', CURDATE(), 'Active', 1),
('Airport Information', 'Passengers are requested to arrive at least 2 hours before departure for domestic flights.', CURDATE(), 'Active', 1),
('Holiday Travel Notice', 'Expect higher demand during the holiday season. Book your tickets early to secure preferred seats.', CURDATE(), 'Active', 1);

-- Default system settings
INSERT INTO settings (setting_key, setting_value) VALUES
('site_name', 'Sky Book'),
('one_booking_per_day', '0'),
('tax_percentage', '5'),
('support_phone', '+91 98765 43210'),
('support_email', 'support@skybook.com'),
('support_address', 'Sky Book HQ, Rajkot, Gujarat, India');

-- Sample contact message
INSERT INTO contact_messages (name, email, phone, subject, message) VALUES
('Demo User', 'demo.user@example.com', '9999900000', 'General Query', 'This is a sample contact message for demo and testing purposes.');

-- Sample feedback (one replied, one pending)
INSERT INTO feedback (user_id, message, rating, status, admin_reply, replied_at, created_at) VALUES
(1, 'Booking my tickets on Sky Book was very quick and the seat selection screen is really easy to use. Loved the experience!', 5, 'Replied', 'Thank you so much for your kind words, Rahul! We are glad you enjoyed booking with Sky Book.', NOW(), NOW()),
(2, 'It would be great if there were more payment options available at checkout.', 4, 'Pending', NULL, NULL, NOW());

-- ============================================================
-- END OF AIRSMART_AI DATABASE
-- ============================================================
