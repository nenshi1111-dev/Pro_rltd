<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Cancel Booking';

$userId = $_SESSION['user_id'];
$bookingId = (int) ($_POST['booking_id'] ?? $_GET['id'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_date, f.economy_available_seats, f.business_available_seats
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$canCancel = ($booking['booking_status'] === 'Confirmed') && (strtotime($booking['departure_date']) >= strtotime(date('Y-m-d')));
if (!$canCancel) {
    setAlert('This booking is not eligible for cancellation.', 'warning');
    redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    mysqli_begin_transaction($conn);
    try {
        // Mark booking cancelled
        $stmt = mysqli_prepare($conn, "UPDATE bookings SET booking_status='Cancelled', payment_status='Refunded', cancellation_date=NOW() WHERE booking_id=?");
        mysqli_stmt_bind_param($stmt, 'i', $bookingId);
        mysqli_stmt_execute($stmt);

        // Log the cancellation
        $stmt = mysqli_prepare($conn, "INSERT INTO cancellations (booking_id, reason, cancelled_by, refund_amount, refund_status) VALUES (?,?, 'User', ?, 'Refunded')");
        $reason = 'Cancelled by user from booking history.';
        mysqli_stmt_bind_param($stmt, 'isd', $bookingId, $reason, $booking['total_amount']);
        mysqli_stmt_execute($stmt);

        // Free up the seats
        mysqli_query($conn, "DELETE FROM seats WHERE booking_id = " . (int)$bookingId);

        // Give the seats back to the correct class only (Section 9)
        if ($booking['travel_class'] === 'Business') {
            mysqli_query($conn, "UPDATE flights SET business_available_seats = business_available_seats + " . (int)$booking['passenger_count'] . " WHERE flight_id = " . (int)$booking['flight_id']);
        } else {
            mysqli_query($conn, "UPDATE flights SET economy_available_seats = economy_available_seats + " . (int)$booking['passenger_count'] . " WHERE flight_id = " . (int)$booking['flight_id']);
        }

        mysqli_commit($conn);
        setAlert('Your booking has been cancelled and the amount will be refunded.', 'success');
        redirect(BASE_URL . 'user/booking-history.php');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        setAlert('Something went wrong while cancelling. Please try again.', 'danger');
        redirect(BASE_URL . 'user/view-booking.php?id=' . $bookingId);
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:600px;">
    <div class="dash-card text-center">
      <i class="fa-solid fa-triangle-exclamation text-danger fs-1 mb-3"></i>
      <h4>Cancel Booking <?php echo clean($booking['booking_reference']); ?>?</h4>
      <p class="text-muted">You are about to cancel your booking for flight <?php echo clean($booking['flight_number']); ?>
        (<?php echo clean($booking['source']); ?> → <?php echo clean($booking['destination']); ?>) on <?php echo formatDate($booking['departure_date']); ?>.
        This action cannot be undone.</p>
      <form method="POST" action="cancel-booking.php">
        <input type="hidden" name="booking_id" value="<?php echo $bookingId; ?>">
        <button type="submit" class="btn btn-danger me-2">Yes, Cancel Booking</button>
        <a href="view-booking.php?id=<?php echo $bookingId; ?>" class="btn btn-outline-secondary">No, Go Back</a>
      </form>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
