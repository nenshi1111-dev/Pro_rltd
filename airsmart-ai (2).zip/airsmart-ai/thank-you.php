<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Thank You';
require_once 'includes/header.php';
?>

<div class="thankyou-wrapper">
  <div class="thankyou-card">
    <i class="fa-solid fa-circle-check thankyou-icon"></i>
    <h1>Thank You for Your Valuable Feedback!</h1>
    <p>We really appreciate you taking the time to share your experience with Sky Book. Our team reviews every message, and we'll get back to you with a reply right here if needed.</p>
    <div class="mt-4 d-flex gap-3 justify-content-center flex-wrap">
      <a href="<?php echo BASE_URL; ?>index.php" class="btn btn-outline-custom"><i class="fa-solid fa-house"></i> Back to Home</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?php echo BASE_URL; ?>user/index.php" class="btn btn-primary-custom"><i class="fa-solid fa-gauge"></i> Go to Dashboard</a>
      <?php else: ?>
        <a href="<?php echo BASE_URL; ?>login.php" class="btn btn-primary-custom"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
