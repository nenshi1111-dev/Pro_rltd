<?php
// ==========================================================
// hash-generator.php
// DEV/TEST UTILITY ONLY — delete this file before going live.
//
// Whenever you insert a member/trainer/admin row manually via
// phpMyAdmin's Insert tab, the "password" column must contain a
// bcrypt HASH, not plain text — login uses password_verify(),
// which will reject plain text every time ("Invalid credentials").
//
// Use this page to generate the hash, then copy-paste the output
// into phpMyAdmin's password field for that row.
//
// Usage: http://localhost/gym-management/hash-generator.php?pw=test123
// ==========================================================

$plain = (isset($_GET['pw']) ? $_GET['pw'] : '');
$hash = $plain !== '' ? password_hash($plain, PASSWORD_DEFAULT) : '';
?>
<!DOCTYPE html>
<html>
<head><title>Password Hash Generator</title></head>
<body style="font-family: Arial, sans-serif; padding: 40px; max-width: 700px;">
    <h3>Password Hash Generator (dev/test only)</h3>
    <form method="GET">
        <label>Plain password: </label>
        <input type="text" name="pw" value="<?php echo htmlspecialchars($plain); ?>" style="width:250px;">
        <button type="submit">Generate Hash</button>
    </form>

    <?php if ($hash): ?>
        <p>Hash for "<strong><?php echo htmlspecialchars($plain); ?></strong>":</p>
        <textarea readonly style="width:100%; height:60px; font-family:monospace;"><?php echo $hash; ?></textarea>
        <p style="color:#555; font-size:14px;">
            Copy this whole string into phpMyAdmin's <code>password</code> column
            for the row you're manually inserting/editing. Then log in using the
            <strong>plain</strong> password above (<?php echo htmlspecialchars($plain); ?>) — the site
            hashes what you type at login and compares it to this stored hash.
        </p>
    <?php endif; ?>

    <p style="color:red; margin-top:30px;"><strong>Delete this file (hash-generator.php) when you're done testing.</strong></p>
</body>
</html>
