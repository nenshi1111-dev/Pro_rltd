<?php
// ==========================================================
// includes/config.php
// Database connection file (mysqli, procedural style)
// This file is included at the very top of every page that
// needs database access.
// ==========================================================

// Load PHP 5.4 compatibility polyfills FIRST — before anything
// else runs, so password_hash(), password_verify(), and
// array_column() are guaranteed to exist no matter which PHP
// version this runs on (harmless no-op on modern PHP).
require_once __DIR__ . "/compat.php";

// Start the session here so every page that includes this
// file automatically has session access (login checks, etc.)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Database settings ----
// UwAmp (college lab) default credentials are root / root.
// XAMPP (most personal PCs) default credentials are root / (blank).
// Change $db_pass below to match whichever server you're running on.
$db_host = "localhost";
$db_user = "root";
$db_pass = "";    // UwAmp default. XAMPP users: change this to ""
$db_name = "gym_pro";

// ---- Create connection ----
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Stop everything if the connection failed
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Force UTF-8 so names/text save correctly
mysqli_set_charset($conn, "utf8mb4");

// Base URL of the project — used for links/redirects that need
// to work no matter which folder a page is opened from.
// Change 'gym-management' if you renamed the project folder.
define('BASE_URL', '/gym-management/');
?>
