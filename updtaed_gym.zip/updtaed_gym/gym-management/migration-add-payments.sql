-- ==========================================================
-- migration-add-payments.sql
-- Run this ONCE in phpMyAdmin -> gym_pro -> SQL tab, IF you
-- already have the multi-batch schema (i.e. a member_batches
-- table already exists) and want to KEEP your existing data.
--
-- If you're starting fresh, don't run this — just import the
-- full gym_pro.sql instead, which already includes everything
-- below.
--
-- Safe to run even if some of this already exists — each
-- statement checks first and does nothing if already applied.
-- ==========================================================

-- 1) Add monthly_fee to batches (defaults to 0 for existing rows —
--    edit each batch afterward in Admin -> Batches to set real fees)
SET @col_exists = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'batches' AND COLUMN_NAME = 'monthly_fee'
);
SET @sql = IF(@col_exists = 0,
    'ALTER TABLE batches ADD COLUMN monthly_fee DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER capacity',
    'SELECT "monthly_fee column already exists, skipped"'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 2) Create the payments table (only if it doesn't already exist)
CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    receipt_number VARCHAR(20) NOT NULL UNIQUE,
    member_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('Cash','UPI','Card','Bank Transfer','Other') DEFAULT 'Cash',
    notes VARCHAR(255),
    recorded_by INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES admins(admin_id) ON DELETE CASCADE
);

-- ==========================================================
-- After running this: go to Admin -> Batches -> edit each batch
-- to set its real monthly fee (they'll all show Rs. 0 until you do).
-- ==========================================================
