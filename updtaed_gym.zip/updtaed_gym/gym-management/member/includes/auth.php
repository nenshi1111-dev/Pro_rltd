<?php
// ==========================================================
// member/includes/auth.php
// Session guard for every protected Member page.
// An Expired member is redirected to expired.php from every
// normal dashboard page — they can only reach expired.php,
// renew-request.php, renew-status.php, and logout.php.
// $allow_expired can be set to true by a page BEFORE including
// this file if that page is one of the allowed exceptions.
// ==========================================================
if (!isset($_SESSION['member_id'])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($allow_expired)) {
    $allow_expired = false;
}

// ---- Auto-expire check ----
// The stored 'status' column does NOT change by itself when the
// clock passes membership_expiry_date. So on every page load we
// compare the expiry date to today and, if it has passed while
// status is still 'Active', we flip it to 'Expired' right here.
// This means: to TEST expiry, you don't need to wait — just edit
// membership_expiry_date to a past date (e.g. yesterday) in
// phpMyAdmin, then reload any member page. No cron job needed.
$stmt = mysqli_prepare($conn, "SELECT status, membership_expiry_date FROM members WHERE member_id=?");
mysqli_stmt_bind_param($stmt, "i", $_SESSION['member_id']);
mysqli_stmt_execute($stmt);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($row) {
    $expiry = strtotime($row['membership_expiry_date']);
    $today  = strtotime(date('Y-m-d'));

    if ($row['status'] === 'Active' && $expiry < $today) {
        $upd = mysqli_prepare($conn, "UPDATE members SET status='Expired' WHERE member_id=?");
        mysqli_stmt_bind_param($upd, "i", $_SESSION['member_id']);
        mysqli_stmt_execute($upd);
        $row['status'] = 'Expired'; // reflect the change for this request too
    }

    if (!$allow_expired && $row['status'] !== 'Active') {
        header("Location: expired.php");
        exit;
    }
}
?>
