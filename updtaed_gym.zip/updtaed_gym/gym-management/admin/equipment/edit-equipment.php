<?php
// ==========================================================
// admin/equipment/edit-equipment.php — Edit equipment record
// ==========================================================
require_once "../../includes/config.php";
require_once "../includes/auth.php";

$page_title = "Edit Equipment";
$active_menu = "equipment";
$error_msg = "";

$id = (int)((isset($_GET['id']) ? $_GET['id'] : 0));
$stmt = mysqli_prepare($conn, "SELECT * FROM equipment WHERE equipment_id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$item = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$item) {
    header("Location: equipment.php?err=" . urlencode("Equipment not found."));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim((isset($_POST['equipment_name']) ? $_POST['equipment_name'] : ''));
    $qty       = (int)((isset($_POST['quantity']) ? $_POST['quantity'] : 1));
    $pdate     = (isset($_POST['purchase_date']) ? $_POST['purchase_date'] : null);
    $condition = (isset($_POST['condition_status']) ? $_POST['condition_status'] : 'New');
    $vname     = trim((isset($_POST['vendor_name']) ? $_POST['vendor_name'] : ''));
    $vloc      = trim((isset($_POST['vendor_location']) ? $_POST['vendor_location'] : ''));
    $vmobile   = trim((isset($_POST['vendor_mobile']) ? $_POST['vendor_mobile'] : ''));

    if ($name === '' || $qty < 1) {
        $error_msg = "Please enter a valid equipment name and quantity.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE equipment SET equipment_name=?, quantity=?, purchase_date=?, condition_status=?, vendor_name=?, vendor_location=?, vendor_mobile=? WHERE equipment_id=?");
        mysqli_stmt_bind_param($stmt, "sisssssi", $name, $qty, $pdate, $condition, $vname, $vloc, $vmobile, $id);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: equipment.php?msg=" . urlencode("Equipment updated successfully."));
            exit;
        } else {
            $error_msg = "Update failed. Please try again.";
        }
    }
}

include "../includes/header.php";
include "../includes/sidebar.php";
include "../includes/topbar.php";
?>

<?php if ($error_msg): ?><div class="alert alert-danger auto-hide-alert"><?php echo htmlspecialchars($error_msg); ?></div><?php endif; ?>

<div class="gym-card p-4">
    <form method="POST">
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Equipment Name</label><input type="text" name="equipment_name" class="form-control" required value="<?php echo htmlspecialchars($item['equipment_name']); ?>"></div>
            <div class="col-md-6"><label class="form-label">Quantity</label><input type="number" name="quantity" class="form-control" min="1" required value="<?php echo (int)$item['quantity']; ?>"></div>
            <div class="col-md-6"><label class="form-label">Purchase Date</label><input type="date" name="purchase_date" class="form-control" value="<?php echo htmlspecialchars($item['purchase_date']); ?>"></div>
            <div class="col-md-6"><label class="form-label">Condition</label>
                <select name="condition_status" class="form-select">
                    <?php foreach (['New','Good','Needs Repair','Old'] as $c): ?>
                        <option <?php echo $item['condition_status']==$c?'selected':''; ?>><?php echo $c; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4"><label class="form-label">Vendor Name</label><input type="text" name="vendor_name" class="form-control" value="<?php echo htmlspecialchars($item['vendor_name']); ?>"></div>
            <div class="col-md-4"><label class="form-label">Vendor Location</label><input type="text" name="vendor_location" class="form-control" value="<?php echo htmlspecialchars($item['vendor_location']); ?>"></div>
            <div class="col-md-4"><label class="form-label">Vendor Mobile</label><input type="text" name="vendor_mobile" class="form-control" value="<?php echo htmlspecialchars($item['vendor_mobile']); ?>"></div>
        </div>
        <button type="submit" class="btn btn-gym-primary mt-4">Save Changes</button>
        <a href="equipment.php" class="btn btn-outline-secondary mt-4">Cancel</a>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
