<?php
// ==========================================================
// admin/equipment/delete-equipment.php — Delete equipment record
// ==========================================================
require_once "../../includes/config.php";
require_once "../includes/auth.php";

$id = (int)((isset($_GET['id']) ? $_GET['id'] : 0));

$stmt = mysqli_prepare($conn, "DELETE FROM equipment WHERE equipment_id=?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    header("Location: equipment.php?msg=" . urlencode("Equipment deleted successfully."));
} else {
    header("Location: equipment.php?err=" . urlencode("Could not delete equipment."));
}
exit;
?>
