<?php
// ==========================================================
// admin/equipment/equipment.php — Equipment list
// ==========================================================
require_once "../../includes/config.php";
require_once "../includes/auth.php";

$page_title = "Equipment";
$active_menu = "equipment";

$equipment = mysqli_query($conn, "SELECT * FROM equipment ORDER BY equipment_id DESC");

include "../includes/header.php";
include "../includes/sidebar.php";
include "../includes/topbar.php";
?>

<?php if (isset($_GET['msg'])): ?><div class="alert alert-success auto-hide-alert"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>
<?php if (isset($_GET['err'])): ?><div class="alert alert-danger auto-hide-alert"><?php echo htmlspecialchars($_GET['err']); ?></div><?php endif; ?>

<div class="d-flex justify-content-end mb-3">
    <a href="add-equipment.php" class="btn btn-gym-primary"><i class="bi bi-plus-circle me-1"></i>Add Equipment</a>
</div>

<div class="gym-card p-3">
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead><tr><th>Name</th><th>Qty</th><th>Purchase Date</th><th>Condition</th><th>Vendor</th><th>Vendor Contact</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while ($e = mysqli_fetch_assoc($equipment)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($e['equipment_name']); ?></td>
                    <td><?php echo (int)$e['quantity']; ?></td>
                    <td><?php echo htmlspecialchars($e['purchase_date']); ?></td>
                    <td><?php echo htmlspecialchars($e['condition_status']); ?></td>
                    <td><?php echo htmlspecialchars($e['vendor_name']) . " (" . htmlspecialchars($e['vendor_location']) . ")"; ?></td>
                    <td><?php echo htmlspecialchars($e['vendor_mobile']); ?></td>
                    <td class="text-nowrap">
                        <a href="edit-equipment.php?id=<?php echo $e['equipment_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <a href="delete-equipment.php?id=<?php echo $e['equipment_id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this equipment record?');"><i class="bi bi-trash"></i></a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
