<?php
// ==========================================================
// admin/equipment/add-equipment.php — Add equipment record
// ==========================================================
require_once "../../includes/config.php";
require_once "../includes/auth.php";

$page_title = "Add Equipment";
$active_menu = "equipment";
$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim((isset($_POST['equipment_name']) ? $_POST['equipment_name'] : ''));
    $qty       = (int)((isset($_POST['quantity']) ? $_POST['quantity'] : 1));
    $pdate     = (isset($_POST['purchase_date']) ? $_POST['purchase_date'] : null);
    $condition = (isset($_POST['condition_status']) ? $_POST['condition_status'] : 'New');
    $vname     = trim((isset($_POST['vendor_name']) ? $_POST['vendor_name'] : ''));
    $vloc      = trim((isset($_POST['vendor_location']) ? $_POST['vendor_location'] : ''));
    $vmobile   = trim((isset($_POST['vendor_mobile']) ? $_POST['vendor_mobile'] : ''));

    if ($name === '' || $qty < 1) {
        $error_msg = "Please enter a valid equipment name and quantity.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO equipment (equipment_name, quantity, purchase_date, condition_status, vendor_name, vendor_location, vendor_mobile) VALUES (?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "sisssss", $name, $qty, $pdate, $condition, $vname, $vloc, $vmobile);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: equipment.php?msg=" . urlencode("Equipment added successfully."));
            exit;
        } else {
            $error_msg = "Could not add equipment. Please try again.";
        }
    }
}

include "../includes/header.php";
include "../includes/sidebar.php";
include "../includes/topbar.php";
?>

<?php if ($error_msg): ?><div class="alert alert-danger auto-hide-alert"><?php echo htmlspecialchars($error_msg); ?></div><?php endif; ?>

<div class="gym-card p-4">
    <form method="POST">
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Equipment Name</label><input type="text" name="equipment_name" class="form-control" required></div>
            <div class="col-md-6"><label class="form-label">Quantity</label><input type="number" name="quantity" class="form-control" min="1" value="1" required></div>
            <div class="col-md-6"><label class="form-label">Purchase Date</label><input type="date" name="purchase_date" class="form-control"></div>
            <div class="col-md-6"><label class="form-label">Condition</label>
                <select name="condition_status" class="form-select">
                    <option>New</option><option>Good</option><option>Needs Repair</option><option>Old</option>
                </select>
            </div>
            <div class="col-md-4"><label class="form-label">Vendor Name</label><input type="text" name="vendor_name" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Vendor Location</label><input type="text" name="vendor_location" class="form-control"></div>
            <div class="col-md-4"><label class="form-label">Vendor Mobile</label><input type="text" name="vendor_mobile" class="form-control"></div>
        </div>
        <button type="submit" class="btn btn-gym-primary mt-4">Add Equipment</button>
        <a href="equipment.php" class="btn btn-outline-secondary mt-4">Cancel</a>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
