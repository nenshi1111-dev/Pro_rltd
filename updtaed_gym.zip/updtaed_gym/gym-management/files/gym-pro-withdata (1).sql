-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2026 at 05:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `full_name`, `email`, `created_at`) VALUES
(1, 'admin', '$2y$10$73FPzkXoB.sFKSTAKIbt0ei4JOY8Ea/fRJO2hVKdeCFsuyitACR9i', 'Super Admin', 'admin@gympro.com', '2026-08-20 07:31:47');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `publish_date` datetime DEFAULT current_timestamp(),
  `posted_by_role` enum('Admin','Trainer') DEFAULT 'Admin',
  `posted_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `title`, `description`, `publish_date`, `posted_by_role`, `posted_by_id`) VALUES
(1, 'Welcome to Gym-Pro', 'You can now join more than one batch — as long as their timings do not overlap. Check the Batches page to see what is available.', '2026-08-20 07:31:47', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('Present','Absent') DEFAULT 'Present'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `member_id`, `batch_id`, `date`, `status`) VALUES
(1, 1, 1, '2026-08-20', 'Present'),
(2, 1, 1, '2026-08-19', 'Present'),
(3, 1, 1, '2026-08-18', 'Absent'),
(4, 1, 1, '2026-08-17', 'Present'),
(5, 2, 3, '2026-08-20', 'Absent'),
(6, 2, 3, '2026-08-19', 'Present'),
(7, 2, 3, '2026-08-18', 'Present'),
(8, 2, 4, '2026-08-19', 'Absent'),
(9, 2, 4, '2026-08-18', 'Present'),
(11, 3, 3, '2026-08-20', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `batches`
--

CREATE TABLE `batches` (
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 20,
  `monthly_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Active','Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batches`
--

INSERT INTO `batches` (`batch_id`, `batch_name`, `start_time`, `end_time`, `capacity`, `monthly_fee`, `status`) VALUES
(1, 'Morning Yoga', '06:00:00', '07:00:00', 20, 800.00, 'Active'),
(2, 'Morning Strength', '06:00:00', '07:00:00', 25, 1000.00, 'Active'),
(3, 'Morning Cardio', '07:15:00', '08:15:00', 20, 700.00, 'Active'),
(4, 'Evening Zumba', '17:00:00', '18:00:00', 20, 900.00, 'Active'),
(5, 'Evening Strength', '18:15:00', '19:15:00', 25, 1000.00, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `batch_trainers`
--

CREATE TABLE `batch_trainers` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `trainer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_trainers`
--

INSERT INTO `batch_trainers` (`id`, `batch_id`, `trainer_id`) VALUES
(1, 1, 2),
(2, 2, 1),
(3, 3, 1),
(4, 4, 2),
(5, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `equipment_name` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `purchase_date` date DEFAULT NULL,
  `condition_status` enum('New','Good','Needs Repair','Old') DEFAULT 'New',
  `vendor_name` varchar(100) DEFAULT NULL,
  `vendor_location` varchar(150) DEFAULT NULL,
  `vendor_mobile` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `equipment_name`, `quantity`, `purchase_date`, `condition_status`, `vendor_name`, `vendor_location`, `vendor_mobile`) VALUES
(1, 'Treadmill', 4, '2024-01-10', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222'),
(2, 'Dumbbell Set (5-25kg)', 10, '2024-02-15', 'New', 'FitGear Traders', 'Jamnagar', '9222222222'),
(3, 'Yoga Mats', 25, '2024-03-01', 'Good', 'FitGear Traders', 'Jamnagar', '9222222222');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `member_id` int(11) NOT NULL,
  `member_code` varchar(20) NOT NULL,
  `photo` varchar(255) DEFAULT 'default-member.png',
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration_months` int(11) NOT NULL DEFAULT 1,
  `membership_start_date` date NOT NULL,
  `membership_expiry_date` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Expired','Inactive') DEFAULT 'Active',
  `created_by` varchar(50) DEFAULT NULL,
  `created_method` enum('Request','Admin') DEFAULT 'Admin',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `member_code`, `photo`, `full_name`, `gender`, `dob`, `phone`, `email`, `address`, `emergency_contact`, `duration_months`, `membership_start_date`, `membership_expiry_date`, `username`, `password`, `status`, `created_by`, `created_method`, `created_at`) VALUES
(1, 'GM0001', 'default-member.png', 'Amit Verma', 'Male', '1998-05-12', '9111111111', 'amit.member@gympro.com', 'Jamnagar, Gujarat', '9111111112', 1, '2026-08-20', '2026-09-20', 'member1', '$2y$10$73FPzkXoB.sFKSTAKIbt0ei4JOY8Ea/fRJO2hVKdeCFsuyitACR9i', 'Active', 'admin', 'Admin', '2026-08-20 07:31:47'),
(2, 'GM0002', 'default-member.png', 'Sneha Patel', 'Female', '2000-09-03', '9111111113', 'sneha.member@gympro.com', 'Rajkot, Gujarat', '9111111114', 3, '2026-08-20', '2026-11-20', 'member2', '$2y$10$73FPzkXoB.sFKSTAKIbt0ei4JOY8Ea/fRJO2hVKdeCFsuyitACR9i', 'Active', 'admin', 'Admin', '2026-08-20 07:31:47'),
(3, 'GM0003', 'default-member.png', 'rathod rajveer', 'Male', '2009-01-10', '6351891098', 'xyz@gmail.com', 'navagadh road ,JETPUR', '6351891098', 1, '2026-08-20', '2026-09-20', 'rajveer', '$2y$10$EkziuCTwQIOJrLVvpi4FHuKO.iNuDaTISQIX.3WI1VPStYeINa5XO', 'Active', 'Super Admin', 'Admin', '2026-08-20 19:52:41'),
(4, 'GM0004', 'default-member.png', 'pal nanadaniya', 'Female', '2006-04-01', '4545454545', 'pal@gmail.com', 'jetpur', '4545454545', 1, '2026-07-24', '2026-08-24', 'pal', '$2y$10$xLMfrsFdfEJJt8VEpKhhN.qP8svvawfX66A42JWsWdKVGbg75CBwe', 'Active', 'admin', 'Admin', '2026-08-20 20:10:19');

-- --------------------------------------------------------

--
-- Table structure for table `member_batches`
--

CREATE TABLE `member_batches` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member_batches`
--

INSERT INTO `member_batches` (`id`, `member_id`, `batch_id`) VALUES
(1, 1, 1),
(2, 2, 3),
(3, 2, 4),
(4, 3, 1),
(5, 3, 3),
(6, 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `receipt_number` varchar(20) NOT NULL,
  `member_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('Cash','UPI','Card','Bank Transfer','Other') DEFAULT 'Cash',
  `notes` varchar(255) DEFAULT NULL,
  `recorded_by` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `receipt_number`, `member_id`, `amount`, `payment_date`, `payment_method`, `notes`, `recorded_by`, `created_at`) VALUES
(1, 'RC0001', 1, 800.00, '2026-08-20', 'Cash', 'First month payment', 1, '2026-08-20 07:31:47'),
(2, 'RC0002', 2, 3000.00, '2026-08-20', 'UPI', 'Partial payment for 3-month renewal', 1, '2026-08-20 07:31:47'),
(3, 'RC0003', 2, 18000.00, '2026-08-20', 'Cash', 'complete payment', 1, '2026-08-20 19:50:45'),
(4, 'RC0004', 3, 900.00, '2026-08-20', 'Cash', 'first payment', 1, '2026-08-20 19:54:29'),
(5, 'RC0005', 3, 290.00, '2026-08-20', 'Cash', 'second payment', 1, '2026-08-20 19:55:11'),
(6, 'RC0006', 3, 1310.00, '2026-08-20', 'Cash', 'complete payment', 1, '2026-08-20 19:55:30');

-- --------------------------------------------------------

--
-- Table structure for table `renewal_requests`
--

CREATE TABLE `renewal_requests` (
  `renewal_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `requested_duration` int(11) DEFAULT 1,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT current_timestamp(),
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `renewal_request_batches`
--

CREATE TABLE `renewal_request_batches` (
  `id` int(11) NOT NULL,
  `renewal_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requested_members`
--

CREATE TABLE `requested_members` (
  `request_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `emergency_contact` varchar(20) DEFAULT NULL,
  `duration` int(11) DEFAULT 1,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` datetime DEFAULT current_timestamp(),
  `approved_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `requested_member_batches`
--

CREATE TABLE `requested_member_batches` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_id`, `setting_key`, `setting_value`) VALUES
(1, 'gym_name', 'Gym-Pro'),
(2, 'gym_address', 'Jamnagar, Gujarat, India'),
(3, 'gym_email', 'contact@gympro.com'),
(4, 'gym_phone', '9876543210'),
(5, 'max_batches_per_member', '3');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE `trainers` (
  `trainer_id` int(11) NOT NULL,
  `trainer_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT 'default-trainer.png',
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`trainer_id`, `trainer_code`, `full_name`, `gender`, `phone`, `email`, `specialization`, `photo`, `username`, `password`, `status`, `created_at`) VALUES
(1, 'TR0001', 'Rahul Sharma', 'Male', '9000000001', 'rahul.trainer@gympro.com', 'Strength & Conditioning', 'default-trainer.png', 'trainer1', '$2y$10$73FPzkXoB.sFKSTAKIbt0ei4JOY8Ea/fRJO2hVKdeCFsuyitACR9i', 'Active', '2026-08-20 07:31:47'),
(2, 'TR0002', 'Priya Nair', 'Female', '9000000002', 'priya.trainer@gympro.com', 'Yoga & Flexibility', 'default-trainer.png', 'trainer2', '$2y$10$73FPzkXoB.sFKSTAKIbt0ei4JOY8Ea/fRJO2hVKdeCFsuyitACR9i', 'Active', '2026-08-20 07:31:47');

-- --------------------------------------------------------

--
-- Table structure for table `workout_plans`
--

CREATE TABLE `workout_plans` (
  `workout_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `day_name` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `focus_area` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workout_plans`
--

INSERT INTO `workout_plans` (`workout_id`, `batch_id`, `day_name`, `focus_area`, `details`) VALUES
(1, 2, 'Monday', 'Chest & Triceps', 'Bench press 4x10, Incline dumbbell press 3x12, Tricep pushdown 3x15'),
(2, 2, 'Wednesday', 'Back & Biceps', 'Pull-ups 4x8, Barbell rows 4x10, Bicep curls 3x12'),
(3, 1, 'Tuesday', 'Flexibility & Breathing', 'Sun salutations, standing poses, pranayama 15 min');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_attendance` (`member_id`,`batch_id`,`date`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `batches`
--
ALTER TABLE `batches`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_assignment` (`batch_id`,`trainer_id`),
  ADD KEY `trainer_id` (`trainer_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `member_code` (`member_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_member_batch` (`member_id`,`batch_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `recorded_by` (`recorded_by`);

--
-- Indexes for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD PRIMARY KEY (`renewal_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `renewal_id` (`renewal_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
  ADD PRIMARY KEY (`trainer_id`),
  ADD UNIQUE KEY `trainer_code` (`trainer_code`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD PRIMARY KEY (`workout_id`),
  ADD UNIQUE KEY `unique_batch_day` (`batch_id`,`day_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `batches`
--
ALTER TABLE `batches`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `member_batches`
--
ALTER TABLE `member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  MODIFY `renewal_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requested_members`
--
ALTER TABLE `requested_members`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
  MODIFY `trainer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `workout_plans`
--
ALTER TABLE `workout_plans`
  MODIFY `workout_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `batch_trainers`
--
ALTER TABLE `batch_trainers`
  ADD CONSTRAINT `batch_trainers_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `batch_trainers_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`trainer_id`) ON DELETE CASCADE;

--
-- Constraints for table `member_batches`
--
ALTER TABLE `member_batches`
  ADD CONSTRAINT `member_batches_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `renewal_requests`
--
ALTER TABLE `renewal_requests`
  ADD CONSTRAINT `renewal_requests_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`member_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_requests_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `renewal_request_batches`
--
ALTER TABLE `renewal_request_batches`
  ADD CONSTRAINT `renewal_request_batches_ibfk_1` FOREIGN KEY (`renewal_id`) REFERENCES `renewal_requests` (`renewal_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `renewal_request_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `requested_members`
--
ALTER TABLE `requested_members`
  ADD CONSTRAINT `requested_members_ibfk_1` FOREIGN KEY (`approved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `requested_member_batches`
--
ALTER TABLE `requested_member_batches`
  ADD CONSTRAINT `requested_member_batches_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `requested_members` (`request_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `requested_member_batches_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;

--
-- Constraints for table `workout_plans`
--
ALTER TABLE `workout_plans`
  ADD CONSTRAINT `workout_plans_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batches` (`batch_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
