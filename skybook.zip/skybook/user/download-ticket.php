<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

$bookingId = (int) (isset($_GET['booking_id']) ? $_GET['booking_id'] : 0);
$userId = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.airline_name, f.source, f.destination, f.departure_date, f.departure_time, f.arrival_time
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.booking_id = ? AND b.user_id = ?");
mysqli_stmt_bind_param($stmt, 'ii', $bookingId, $userId);
mysqli_stmt_execute($stmt);
$booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$booking || $booking['booking_status'] !== 'Confirmed') {
    setAlert('Ticket not available for download.', 'danger');
    redirect(BASE_URL . 'user/booking-history.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE booking_id = ? AND status = 'Active' ORDER BY passenger_id");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$passengers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$fareEach = passengerFareShare($booking);

// ---------------- Build a fully self-contained ticket HTML file ----------------
// (inline CSS only, no external files, so it still displays and prints
// correctly even after being saved and reopened offline later.)
$cardsHtml = '';
foreach ($passengers as $p) {
    $cardsHtml .= '
      <div class="ticket-card">
        <div class="ticket-header">
          <h3>' . clean(SITE_NAME) . '</h3>
          <p class="sub">BOARDING TICKET</p>
        </div>
        <div class="row"><span class="label">Booking ID</span><span class="value">' . clean($booking['booking_reference']) . '</span></div>
        <div class="row"><span class="label">Ticket Number</span><span class="value">' . clean(generateTicketNumber($p['passenger_id'])) . '</span></div>
        <div class="row"><span class="label">Passenger</span><span class="value">' . clean($p['full_name']) . '</span></div>
        <div class="row"><span class="label">Flight</span><span class="value">' . clean($booking['flight_number']) . '</span></div>
        <div class="row"><span class="label">From</span><span class="value">' . clean($booking['source']) . '</span></div>
        <div class="row"><span class="label">To</span><span class="value">' . clean($booking['destination']) . '</span></div>
        <div class="row"><span class="label">Date</span><span class="value">' . clean(formatDate($booking['departure_date'])) . '</span></div>
        <div class="row"><span class="label">Departure</span><span class="value">' . clean(formatTime($booking['departure_time'])) . '</span></div>
        <div class="row"><span class="label">Arrival</span><span class="value">' . clean(formatTime($booking['arrival_time'])) . '</span></div>
        <div class="row"><span class="label">Class</span><span class="value">' . clean($p['travel_class']) . '</span></div>
        <div class="row"><span class="label">Seat</span><span class="value">' . clean($p['seat_number']) . '</span></div>
        <div class="row"><span class="label">Fare</span><span class="value">' . formatMoney($fareEach) . '</span></div>
        <div class="row last"><span class="label">Payment</span><span class="value paid">PAID</span></div>
        <div class="status">&#10004; BOOKING CONFIRMED</div>
      </div>';
}

$html = '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Ticket - ' . clean($booking['booking_reference']) . '</title>
<style>
  body { font-family: Arial, Helvetica, sans-serif; background:#e8f3ff; color:#333; margin:0; padding:24px; }
  .no-print { text-align:center; margin-bottom:20px; }
  .no-print button { background:#1e90ff; color:#fff; border:none; padding:10px 22px; border-radius:6px; font-size:14px; cursor:pointer; }
  .ticket-card { background:#fff; border:2px dashed #1e90ff; border-radius:16px; padding:26px; max-width:560px; margin:0 auto 24px; box-shadow:0 6px 24px rgba(0,0,0,0.1); }
  .ticket-header { text-align:center; border-bottom:2px dashed #ddd; padding-bottom:14px; margin-bottom:14px; }
  .ticket-header h3 { margin:0; color:#0b2545; }
  .ticket-header .sub { margin:4px 0 0; color:#777; font-size:13px; letter-spacing:1px; }
  .row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px dotted #eee; font-size:14px; }
  .row.last { border-bottom:none; }
  .row .label { color:#6c757d; }
  .row .value { font-weight:600; color:#0b2545; }
  .row .value.paid { color:#1fa971; }
  .status { text-align:center; color:#1fa971; font-weight:700; font-size:16px; margin-top:14px; }
  @media print { .no-print { display:none; } body { background:#fff; padding:0; } .ticket-card { box-shadow:none; border:2px solid #000; } }
</style>
</head>
<body>
  <div class="no-print"><button onclick="window.print()">Print this ticket</button></div>
  ' . $cardsHtml . '
</body>
</html>';

$filename = 'Ticket-' . preg_replace('/[^A-Za-z0-9_-]/', '', $booking['booking_reference']) . '.html';

// Force the browser's Save/Download dialog so the user can choose where to save it.
header('Content-Type: text/html; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($html));
echo $html;
exit();
