<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Flight Report';

$result = mysqli_query($conn, "SELECT f.*,
    (SELECT COUNT(*) FROM bookings b WHERE b.flight_id=f.flight_id AND b.booking_status IN ('Confirmed','Completed')) AS total_bookings,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.flight_id=f.flight_id AND b.payment_status='Success') AS revenue
    FROM flights f ORDER BY f.departure_date DESC");
$flights = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Top 8 flights by bookings, for the chart below
$chartFlights = $flights;
usort($chartFlights, function ($a, $b) { return $b['total_bookings'] - $a['total_bookings']; });
$chartFlights = array_slice($chartFlights, 0, 8);
$flightLabels = [];
$flightBookingCounts = [];
$flightRevenue = [];
foreach ($chartFlights as $cf) {
    $flightLabels[] = $cf['flight_number'];
    $flightBookingCounts[] = (int) $cf['total_bookings'];
    $flightRevenue[] = (float) $cf['revenue'];
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link active" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="row g-3 mb-3">
  <div class="col-12">
    <div class="chart-card">
      <h5><i class="fa-solid fa-plane text-primary"></i> Top Flights by Bookings & Revenue</h5>
      <p class="chart-sub">Busiest flights, ranked by number of bookings</p>
      <div class="chart-canvas-wrap h-230">
        <canvas id="flightChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <h5><i class="fa-solid fa-plane"></i> Flight-wise Bookings & Revenue</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Flight No</th><th>Route</th><th>Date</th><th>Economy Sold</th><th>Business Sold</th><th>Total Bookings</th><th>Revenue</th></tr></thead>
      <tbody>
      <?php foreach ($flights as $f): ?>
        <tr>
          <td><?php echo clean($f['flight_number']); ?></td>
          <td><?php echo clean($f['source']); ?> → <?php echo clean($f['destination']); ?></td>
          <td><?php echo formatDate($f['departure_date']); ?></td>
          <td><?php echo $f['economy_total_seats'] - $f['economy_available_seats']; ?>/<?php echo $f['economy_total_seats']; ?></td>
          <td><?php echo $f['business_total_seats'] - $f['business_available_seats']; ?>/<?php echo $f['business_total_seats']; ?></td>
          <td><?php echo $f['total_bookings']; ?></td>
          <td><?php echo formatMoney($f['revenue']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
// Fallback in case cdnjs is unreachable on this network (common on local WAMP/uWAMP setups)
if (typeof Chart === 'undefined') {
  document.write('<script src="https:\/\/cdn.jsdelivr.net\/npm\/chart.js@4.4.4\/dist\/chart.umd.min.js"><\/script>');
}
</script>
<script>
try {
new Chart(document.getElementById('flightChart'), {
  data: {
    labels: <?php echo json_encode($flightLabels); ?>,
    datasets: [
      {
        type: 'bar',
        label: 'Bookings',
        data: <?php echo json_encode($flightBookingCounts); ?>,
        backgroundColor: 'rgba(30,144,255,0.55)',
        borderRadius: 6,
        yAxisID: 'y'
      },
      {
        type: 'line',
        label: 'Revenue (₹)',
        data: <?php echo json_encode($flightRevenue); ?>,
        borderColor: '#1fa971',
        backgroundColor: 'rgba(31,169,113,0.15)',
        borderWidth: 3,
        tension: 0.3,
        fill: true,
        pointBackgroundColor: '#1fa971',
        pointRadius: 4,
        yAxisID: 'y1'
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 14, font: { family: 'Poppins', size: 12 } } } },
    scales: {
      y: { beginAtZero: true, position: 'left', grid: { color: '#eef3fa' }, title: { display: true, text: 'Bookings' } },
      y1: { beginAtZero: true, position: 'right', grid: { display: false }, title: { display: true, text: 'Revenue (₹)' } },
      x: { grid: { display: false } }
    }
  }
});
} catch (e) { console.error(e); }
</script>

<?php require_once '../includes/footer.php'; ?>
