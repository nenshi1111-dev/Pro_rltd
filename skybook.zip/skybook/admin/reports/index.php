<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Reports Dashboard';

// ---------------- KPI cards ----------------
$totalFlights = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM flights"))['total'];
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'];
$totalBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings"))['total'];
$totalRevenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_amount),0) AS total FROM bookings WHERE payment_status='Success'"))['total'];
$confirmedBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Confirmed'"))['total'];
$cancelledBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Cancelled'"))['total'];
$totalRefundAmount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(refund_amount),0) AS total FROM cancellations"))['total'];
$pendingRefundCount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations WHERE refund_status IN ('Pending','Processing')"))['total'];
$pendingFeedbackCount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback WHERE status='Pending'"))['total'];

// ---------------- Bookings & Revenue Trend (last 6 months) ----------------
$trendResult = mysqli_query($conn, "SELECT DATE_FORMAT(booking_date,'%b %y') AS label, DATE_FORMAT(booking_date,'%Y-%m') AS ym,
    COUNT(*) AS bookings, SUM(CASE WHEN payment_status='Success' THEN total_amount ELSE 0 END) AS revenue
    FROM bookings WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym ORDER BY ym ASC");
$trendLabels = []; $trendBookings = []; $trendRevenue = [];
while ($row = mysqli_fetch_assoc($trendResult)) {
    $trendLabels[] = $row['label'];
    $trendBookings[] = (int) $row['bookings'];
    $trendRevenue[] = (float) $row['revenue'];
}

// ---------------- Booking Status Distribution ----------------
$statusCounts = ['Pending' => 0, 'Confirmed' => 0, 'Completed' => 0, 'Cancelled' => 0];
$statusResult = mysqli_query($conn, "SELECT booking_status, COUNT(*) AS total FROM bookings GROUP BY booking_status");
while ($row = mysqli_fetch_assoc($statusResult)) { $statusCounts[$row['booking_status']] = (int) $row['total']; }

// ---------------- Flight-wise Bookings & Revenue (top 8) ----------------
$flightResult = mysqli_query($conn, "SELECT f.flight_number,
    (SELECT COUNT(*) FROM bookings b WHERE b.flight_id=f.flight_id AND b.booking_status IN ('Confirmed','Completed')) AS total_bookings,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.flight_id=f.flight_id AND b.payment_status='Success') AS revenue
    FROM flights f ORDER BY total_bookings DESC LIMIT 8");
$flightLabels = []; $flightBookingCounts = []; $flightRevenue = [];
while ($row = mysqli_fetch_assoc($flightResult)) {
    $flightLabels[] = $row['flight_number'];
    $flightBookingCounts[] = (int) $row['total_bookings'];
    $flightRevenue[] = (float) $row['revenue'];
}

// ---------------- Payment Status Breakdown ----------------
$payStatusCounts = ['Success' => 0, 'Pending' => 0, 'Failed' => 0, 'Refunded' => 0];
$payResult = mysqli_query($conn, "SELECT payment_status, COUNT(*) AS total FROM payments GROUP BY payment_status");
while ($row = mysqli_fetch_assoc($payResult)) { $payStatusCounts[$row['payment_status']] = (int) $row['total']; }

// ---------------- Refund Amount Trend (last 6 months) ----------------
$refundTrendResult = mysqli_query($conn, "SELECT DATE_FORMAT(cancellation_date,'%b %y') AS label, DATE_FORMAT(cancellation_date,'%Y-%m') AS ym,
    SUM(refund_amount) AS amt FROM cancellations WHERE cancellation_date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym ORDER BY ym ASC");
$refundLabels = []; $refundAmounts = [];
while ($row = mysqli_fetch_assoc($refundTrendResult)) {
    $refundLabels[] = $row['label'];
    $refundAmounts[] = (float) $row['amt'];
}

// ---------------- Feedback Rating Distribution ----------------
$ratingCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
$ratingResult = mysqli_query($conn, "SELECT rating, COUNT(*) AS total FROM feedback WHERE rating IS NOT NULL GROUP BY rating");
while ($row = mysqli_fetch_assoc($ratingResult)) { $ratingCounts[(int) $row['rating']] = (int) $row['total']; }

// ---------------- Top 5 Routes by Bookings ----------------
$routeResult = mysqli_query($conn, "SELECT CONCAT(f.source,' -> ',f.destination) AS route, COUNT(*) AS total
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id
    GROUP BY route ORDER BY total DESC LIMIT 5");
$routeLabels = []; $routeCounts = [];
while ($row = mysqli_fetch_assoc($routeResult)) {
    $routeLabels[] = $row['route'];
    $routeCounts[] = (int) $row['total'];
}

// ---------------- Top Users by Spending (top 8) ----------------
$userResult = mysqli_query($conn, "SELECT u.full_name,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.user_id=u.user_id AND b.payment_status='Success') AS total_spent
    FROM users u ORDER BY total_spent DESC LIMIT 8");
$userLabels = []; $userSpend = [];
while ($row = mysqli_fetch_assoc($userResult)) {
    $userLabels[] = $row['full_name'];
    $userSpend[] = (float) $row['total_spent'];
}

// ---------------- Recent Bookings / Payments / Refunds / Feedback ----------------
$recentBookings = mysqli_query($conn, "SELECT b.*, u.full_name, f.flight_number FROM bookings b
    JOIN users u ON b.user_id=u.user_id JOIN flights f ON b.flight_id=f.flight_id
    ORDER BY b.booking_date DESC LIMIT 5");
$recentPayments = mysqli_query($conn, "SELECT p.*, u.full_name FROM payments p
    JOIN bookings b ON p.booking_id=b.booking_id JOIN users u ON b.user_id=u.user_id
    ORDER BY p.payment_date DESC LIMIT 5");
$recentRefunds = mysqli_query($conn, "SELECT c.*, b.booking_reference, u.full_name FROM cancellations c
    JOIN bookings b ON c.booking_id=b.booking_id JOIN users u ON b.user_id=u.user_id
    ORDER BY c.cancellation_date DESC LIMIT 5");
$recentFeedback = mysqli_query($conn, "SELECT f.*, u.full_name FROM feedback f
    JOIN users u ON f.user_id=u.user_id ORDER BY f.created_at DESC LIMIT 5");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link active" href="index.php"><i class="fa-solid fa-gauge"></i> Overview</a></li>
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>
<p class="text-muted mb-3" style="margin-top:-12px;">Overview of bookings, payments, refunds and feedback.</p>

<div class="row g-2 mb-2">
  <div class="col-md-3 col-sm-6"><div class="kpi-card"><div class="kpi-icon"><i class="fa-solid fa-plane"></i></div><div><h4><?php echo $totalFlights; ?></h4><p>Total Flights</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="kpi-card"><div class="kpi-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div><div><h4><?php echo $confirmedBookings; ?></h4><p>Confirmed Bookings</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="kpi-card"><div class="kpi-icon" style="color:var(--danger-red);"><i class="fa-solid fa-circle-xmark"></i></div><div><h4><?php echo $cancelledBookings; ?></h4><p>Cancelled Bookings</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="kpi-card"><div class="kpi-icon"><i class="fa-solid fa-ticket"></i></div><div><h4><?php echo $totalBookings; ?></h4><p>Total Bookings</p></div></div></div>
</div>
<div class="row g-2 mb-3">
  <div class="col-md col-sm-6"><div class="kpi-card"><div class="kpi-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div><div><h4><?php echo formatMoney($totalRevenue); ?></h4><p>Total Revenue</p></div></div></div>
  <div class="col-md col-sm-6"><div class="kpi-card"><div class="kpi-icon" style="color:#f4b400;"><i class="fa-solid fa-rotate-left"></i></div><div><h4><?php echo formatMoney($totalRefundAmount); ?></h4><p>Total Refunds</p></div></div></div>
  <div class="col-md col-sm-6"><div class="kpi-card"><div class="kpi-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div><div><h4><?php echo $pendingRefundCount; ?></h4><p>Refunds Pending</p></div></div></div>
  <div class="col-md col-sm-6"><div class="kpi-card"><div class="kpi-icon" style="color:#7b5cd6;"><i class="fa-solid fa-comment-dots"></i></div><div><h4><?php echo $pendingFeedbackCount; ?></h4><p>Feedback Pending</p></div></div></div>
  <div class="col-md col-sm-6"><div class="kpi-card"><div class="kpi-icon"><i class="fa-solid fa-users"></i></div><div><h4><?php echo $totalUsers; ?></h4><p>Registered Users</p></div></div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-5">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-line text-primary"></i> Bookings &amp; Revenue Trend</h5>
      <p class="chart-sub">Last 6 months overview</p>
      <div class="chart-canvas-wrap h-200"><canvas id="trendChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-3">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-pie text-primary"></i> Booking Status</h5>
      <p class="chart-sub">Across all bookings</p>
      <div class="chart-canvas-wrap h-200"><canvas id="statusChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="chart-card">
      <h5><i class="fa-solid fa-plane text-primary"></i> Flight-wise Bookings</h5>
      <p class="chart-sub">Top flights, bookings &amp; revenue</p>
      <div class="chart-canvas-wrap h-200"><canvas id="flightChart"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-4">
    <div class="chart-card">
      <h5><i class="fa-solid fa-credit-card text-primary"></i> Payment Analysis</h5>
      <p class="chart-sub">Payment attempts, by status</p>
      <div class="chart-canvas-wrap h-190"><canvas id="paymentChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="chart-card">
      <h5><i class="fa-solid fa-rotate-left text-primary"></i> Refund Analysis</h5>
      <p class="chart-sub">Refunded amount, last 6 months</p>
      <div class="chart-canvas-wrap h-190"><canvas id="refundChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="chart-card">
      <h5><i class="fa-solid fa-star text-primary"></i> Feedback Analysis</h5>
      <p class="chart-sub">Star rating distribution</p>
      <div class="chart-canvas-wrap h-190"><canvas id="ratingChart"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-6">
    <div class="chart-card">
      <h5><i class="fa-solid fa-route text-primary"></i> Booking Analysis</h5>
      <p class="chart-sub">Top 5 routes by bookings</p>
      <div class="chart-canvas-wrap h-190"><canvas id="routeChart"></canvas></div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="chart-card">
      <h5><i class="fa-solid fa-crown text-primary"></i> User Analysis</h5>
      <p class="chart-sub">Top users by spending</p>
      <div class="chart-canvas-wrap h-190"><canvas id="userChart"></canvas></div>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-4">
    <div class="admin-card mb-0 h-100">
      <div class="d-flex justify-content-between align-items-center mb-2"><h6 class="mb-0"><i class="fa-solid fa-ticket"></i> Recent Bookings</h6></div>
      <div class="table-responsive">
        <table class="table table-custom table-sm align-middle mb-2">
          <thead><tr><th>Ref</th><th>User</th><th>Amt</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($recentBookings) === 0): ?>
            <tr><td colspan="4" class="text-center text-muted py-3">No bookings yet.</td></tr>
          <?php endif; ?>
          <?php while ($b = mysqli_fetch_assoc($recentBookings)): ?>
            <?php $badgeMap = array('Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'); $badge = isset($badgeMap[$b['booking_status']]) ? $badgeMap[$b['booking_status']] : 'secondary'; ?>
            <tr>
              <td><small><?php echo clean($b['booking_reference']); ?></small></td>
              <td><small><?php echo clean($b['full_name']); ?></small></td>
              <td><small><?php echo formatMoney($b['total_amount']); ?></small></td>
              <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($b['booking_status']); ?></span></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <a href="<?php echo BASE_URL; ?>admin/bookings/bookings.php" class="btn btn-sm btn-outline-primary">View All Bookings</a>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="admin-card mb-0 h-100">
      <div class="d-flex justify-content-between align-items-center mb-2"><h6 class="mb-0"><i class="fa-solid fa-credit-card"></i> Recent Payments</h6></div>
      <div class="table-responsive">
        <table class="table table-custom table-sm align-middle mb-2">
          <thead><tr><th>User</th><th>Amt</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($recentPayments) === 0): ?>
            <tr><td colspan="3" class="text-center text-muted py-3">No payments yet.</td></tr>
          <?php endif; ?>
          <?php while ($p = mysqli_fetch_assoc($recentPayments)): ?>
            <?php $pBadgeMap = array('Success'=>'success','Pending'=>'warning','Failed'=>'danger','Refunded'=>'secondary'); $pBadge = isset($pBadgeMap[$p['payment_status']]) ? $pBadgeMap[$p['payment_status']] : 'secondary'; ?>
            <tr>
              <td><small><?php echo clean($p['full_name']); ?></small></td>
              <td><small><?php echo formatMoney($p['amount']); ?></small></td>
              <td><span class="badge bg-<?php echo $pBadge; ?>"><?php echo clean($p['payment_status']); ?></span></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <a href="<?php echo BASE_URL; ?>admin/payments/payments.php" class="btn btn-sm btn-outline-primary">View All Payments</a>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="admin-card mb-0 h-100">
      <div class="d-flex justify-content-between align-items-center mb-2"><h6 class="mb-0"><i class="fa-solid fa-rotate-left"></i> Recent Refunds</h6></div>
      <div class="table-responsive">
        <table class="table table-custom table-sm align-middle mb-2">
          <thead><tr><th>Booking</th><th>Amt</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($recentRefunds) === 0): ?>
            <tr><td colspan="3" class="text-center text-muted py-3">No refunds yet.</td></tr>
          <?php endif; ?>
          <?php while ($r = mysqli_fetch_assoc($recentRefunds)): ?>
            <tr>
              <td><small><?php echo clean($r['booking_reference']); ?></small></td>
              <td><small><?php echo formatMoney($r['refund_amount']); ?></small></td>
              <td><span class="badge bg-<?php echo refundStatusBadge($r['refund_status']); ?>"><?php echo clean($r['refund_status']); ?></span></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <a href="<?php echo BASE_URL; ?>admin/refunds/refunds.php" class="btn btn-sm btn-outline-primary">Manage Refunds</a>
    </div>
  </div>
</div>

<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center mb-2"><h6 class="mb-0"><i class="fa-solid fa-comment-dots"></i> Recent Feedback</h6></div>
  <div class="table-responsive">
    <table class="table table-custom table-sm align-middle mb-2">
      <thead><tr><th>User</th><th>Message</th><th>Rating</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php if (mysqli_num_rows($recentFeedback) === 0): ?>
        <tr><td colspan="5" class="text-center text-muted py-3">No feedback submitted yet.</td></tr>
      <?php endif; ?>
      <?php while ($f = mysqli_fetch_assoc($recentFeedback)): ?>
        <tr>
          <td><small><?php echo clean($f['full_name']); ?></small></td>
          <td><small><?php echo clean(mb_strimwidth($f['message'], 0, 50, '...')); ?></small></td>
          <td><small><?php echo $f['rating'] ? clean($f['rating']) . ' ★' : '—'; ?></small></td>
          <td><span class="badge bg-<?php echo $f['status']=='Replied'?'success':'warning'; ?>"><?php echo clean($f['status']); ?></span></td>
          <td><small><?php echo formatDate($f['created_at']); ?></small></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <a href="<?php echo BASE_URL; ?>admin/feedback/feedback.php" class="btn btn-sm btn-outline-primary">Manage Feedback</a>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
// Fallback in case cdnjs is unreachable on this network (common on local WAMP/uWAMP setups)
if (typeof Chart === 'undefined') {
  document.write('<script src="https:\/\/cdn.jsdelivr.net\/npm\/chart.js@4.4.4\/dist\/chart.umd.min.js"><\/script>');
}
</script>
<script>
try {
new Chart(document.getElementById('trendChart'), {
  data: {
    labels: <?php echo json_encode($trendLabels); ?>,
    datasets: [
      { type: 'bar', label: 'Bookings', data: <?php echo json_encode($trendBookings); ?>, backgroundColor: 'rgba(30,144,255,0.55)', borderRadius: 5, yAxisID: 'y', order: 2 },
      { type: 'line', label: 'Revenue (₹)', data: <?php echo json_encode($trendRevenue); ?>, borderColor: '#1fa971', backgroundColor: 'rgba(31,169,113,0.15)', borderWidth: 2, tension: 0.35, fill: true, pointRadius: 3, yAxisID: 'y1', order: 1 }
    ]
  },
  options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 10, font: { size: 11 } } } },
    scales: { y: { beginAtZero: true, position: 'left', grid: { color: '#eef3fa' } }, y1: { beginAtZero: true, position: 'right', grid: { display: false } }, x: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('statusChart'), {
  type: 'doughnut',
  data: { labels: ['Confirmed', 'Pending', 'Completed', 'Cancelled'],
    datasets: [{ data: [<?php echo (int)$statusCounts['Confirmed']; ?>, <?php echo (int)$statusCounts['Pending']; ?>, <?php echo (int)$statusCounts['Completed']; ?>, <?php echo (int)$statusCounts['Cancelled']; ?>],
      backgroundColor: ['#1e90ff', '#f4b400', '#1fa971', '#dc3545'], borderWidth: 2, borderColor: '#fff', hoverOffset: 6 }] },
  options: { responsive: true, maintainAspectRatio: false, cutout: '62%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 10, font: { size: 11 } } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('flightChart'), {
  data: { labels: <?php echo json_encode($flightLabels); ?>,
    datasets: [
      { type: 'bar', label: 'Bookings', data: <?php echo json_encode($flightBookingCounts); ?>, backgroundColor: 'rgba(30,144,255,0.55)', borderRadius: 5, yAxisID: 'y' },
      { type: 'line', label: 'Revenue (₹)', data: <?php echo json_encode($flightRevenue); ?>, borderColor: '#1fa971', backgroundColor: 'rgba(31,169,113,0.15)', borderWidth: 2, tension: 0.3, fill: true, pointRadius: 3, yAxisID: 'y1' }
    ] },
  options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false },
    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 10, font: { size: 11 } } } },
    scales: { y: { beginAtZero: true, position: 'left', grid: { color: '#eef3fa' } }, y1: { beginAtZero: true, position: 'right', grid: { display: false } }, x: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('paymentChart'), {
  type: 'doughnut',
  data: { labels: ['Success', 'Pending', 'Failed', 'Refunded'],
    datasets: [{ data: [<?php echo (int)$payStatusCounts['Success']; ?>, <?php echo (int)$payStatusCounts['Pending']; ?>, <?php echo (int)$payStatusCounts['Failed']; ?>, <?php echo (int)$payStatusCounts['Refunded']; ?>],
      backgroundColor: ['#1fa971', '#f4b400', '#dc3545', '#6c757d'], borderWidth: 2, borderColor: '#fff' }] },
  options: { responsive: true, maintainAspectRatio: false, cutout: '58%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 10, font: { size: 11 } } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('refundChart'), {
  type: 'line',
  data: { labels: <?php echo json_encode($refundLabels); ?>,
    datasets: [{ label: 'Refund Amount (₹)', data: <?php echo json_encode($refundAmounts); ?>, borderColor: '#dc3545', backgroundColor: 'rgba(220,53,69,0.12)', borderWidth: 2, tension: 0.35, fill: true, pointRadius: 3 }] },
  options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true, grid: { color: '#eef3fa' } }, x: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('ratingChart'), {
  type: 'bar',
  data: { labels: ['1★','2★','3★','4★','5★'],
    datasets: [{ label: 'Feedback Count', data: [<?php echo (int)$ratingCounts[1]; ?>, <?php echo (int)$ratingCounts[2]; ?>, <?php echo (int)$ratingCounts[3]; ?>, <?php echo (int)$ratingCounts[4]; ?>, <?php echo (int)$ratingCounts[5]; ?>], backgroundColor: '#f4b400', borderRadius: 5, maxBarThickness: 30 }] },
  options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true, grid: { color: '#eef3fa' }, ticks: { precision: 0 } }, x: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('routeChart'), {
  type: 'bar',
  data: { labels: <?php echo json_encode($routeLabels); ?>,
    datasets: [{ label: 'Bookings', data: <?php echo json_encode($routeCounts); ?>, backgroundColor: '#0b2545', borderRadius: 5, maxBarThickness: 34 }] },
  options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
    scales: { x: { beginAtZero: true, grid: { color: '#eef3fa' } }, y: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
try {
new Chart(document.getElementById('userChart'), {
  type: 'bar',
  data: { labels: <?php echo json_encode($userLabels); ?>,
    datasets: [{ label: 'Total Spent (₹)', data: <?php echo json_encode($userSpend); ?>, backgroundColor: 'rgba(30,144,255,0.6)', borderRadius: 5, maxBarThickness: 30 }] },
  options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
    scales: { x: { beginAtZero: true, grid: { color: '#eef3fa' } }, y: { grid: { display: false } } } }
});
} catch (e) { console.error(e); }
</script>

<?php require_once '../includes/footer.php'; ?>
