<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once 'includes/auth.php';
$pageTitle = 'Dashboard';

// ---------------- Summary counts ----------------
$totalFlights = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM flights"))['total'];
$totalUsers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'];
$totalBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings"))['total'];
$totalRevenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_amount),0) AS total FROM bookings WHERE payment_status='Success'"))['total'];
$confirmedBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Confirmed'"))['total'];
$cancelledBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_status='Cancelled'"))['total'];

// ---------------- Recent bookings ----------------
$recent = mysqli_query($conn, "SELECT b.*, u.full_name, f.flight_number FROM bookings b
    JOIN users u ON b.user_id = u.user_id JOIN flights f ON b.flight_id = f.flight_id
    ORDER BY b.booking_date DESC LIMIT 8");

// ---------------- Graph data: bookings & revenue trend, last 6 months ----------------
$trendResult = mysqli_query($conn, "SELECT DATE_FORMAT(booking_date,'%b %y') AS label, DATE_FORMAT(booking_date,'%Y-%m') AS ym,
    COUNT(*) AS bookings, SUM(CASE WHEN payment_status='Success' THEN total_amount ELSE 0 END) AS revenue
    FROM bookings WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym ORDER BY ym ASC");
$trendLabels = [];
$trendBookings = [];
$trendRevenue = [];
while ($row = mysqli_fetch_assoc($trendResult)) {
    $trendLabels[] = $row['label'];
    $trendBookings[] = (int) $row['bookings'];
    $trendRevenue[] = (float) $row['revenue'];
}

// ---------------- Graph data: booking status distribution ----------------
$statusCounts = ['Pending' => 0, 'Confirmed' => 0, 'Completed' => 0, 'Cancelled' => 0];
$statusResult = mysqli_query($conn, "SELECT booking_status, COUNT(*) AS total FROM bookings GROUP BY booking_status");
while ($row = mysqli_fetch_assoc($statusResult)) {
    $statusCounts[$row['booking_status']] = (int) $row['total'];
}

$totalRefundAmount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(refund_amount),0) AS total FROM cancellations"))['total'];
$pendingRefundCount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations WHERE refund_status IN ('Pending','Processing')"))['total'];
$pendingFeedbackCount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback WHERE status='Pending'"))['total'];

// ---------------- Recent payments ----------------
$recentPayments = mysqli_query($conn, "SELECT p.*, b.booking_reference, u.full_name FROM payments p
    JOIN bookings b ON p.booking_id = b.booking_id JOIN users u ON b.user_id = u.user_id
    ORDER BY p.payment_date DESC LIMIT 5");

// ---------------- Recent refunds ----------------
$recentRefunds = mysqli_query($conn, "SELECT c.*, b.booking_reference, u.full_name FROM cancellations c
    JOIN bookings b ON c.booking_id = b.booking_id JOIN users u ON b.user_id = u.user_id
    ORDER BY c.cancellation_date DESC LIMIT 5");

// ---------------- Recent feedback ----------------
$recentFeedback = mysqli_query($conn, "SELECT f.*, u.full_name FROM feedback f
    JOIN users u ON f.user_id = u.user_id ORDER BY f.created_at DESC LIMIT 5");

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
require_once 'includes/topbar.php';
?>
<div class="row g-3 mb-3">
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-plane"></i></div>
      <div><h3><?php echo $totalFlights; ?></h3><p>Total Flights</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-users"></i></div>
      <div><h3><?php echo $totalUsers; ?></h3><p>Registered Users</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-ticket"></i></div>
      <div><h3><?php echo $totalBookings; ?></h3><p>Total Bookings</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div>
      <div><h3><?php echo formatMoney($totalRevenue); ?></h3><p>Total Revenue</p></div></div>
  </div>
</div>

<div class="row g-2 mb-3">
  <div class="col-md col-sm-6">
    <div class="kpi-card"><div class="kpi-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div>
      <div><h4><?php echo $confirmedBookings; ?></h4><p>Confirmed Bookings</p></div></div>
  </div>
  <div class="col-md col-sm-6">
    <div class="kpi-card"><div class="kpi-icon" style="color:var(--danger-red);"><i class="fa-solid fa-circle-xmark"></i></div>
      <div><h4><?php echo $cancelledBookings; ?></h4><p>Cancelled Bookings</p></div></div>
  </div>
  <div class="col-md col-sm-6">
    <div class="kpi-card"><div class="kpi-icon" style="color:#f4b400;"><i class="fa-solid fa-rotate-left"></i></div>
      <div><h4><?php echo formatMoney($totalRefundAmount); ?></h4><p>Total Refund Amount</p></div></div>
  </div>
  <div class="col-md col-sm-6">
    <div class="kpi-card"><div class="kpi-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div>
      <div><h4><?php echo $pendingRefundCount; ?></h4><p>Refunds Awaiting Action</p></div></div>
  </div>
  <div class="col-md col-sm-6">
    <div class="kpi-card"><div class="kpi-icon" style="color:#7b5cd6;"><i class="fa-solid fa-comment-dots"></i></div>
      <div><h4><?php echo $pendingFeedbackCount; ?></h4><p>Feedback Awaiting Reply</p></div></div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-7">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-line text-primary"></i> Bookings &amp; Revenue Trend</h5>
      <p class="chart-sub">Last 6 months, based on all ticket bookings</p>
      <div class="chart-canvas-wrap h-230">
        <canvas id="trendChart"></canvas>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-pie text-primary"></i> Booking Status Distribution</h5>
      <p class="chart-sub">Across all bookings on the platform</p>
      <div class="chart-canvas-wrap h-230">
        <canvas id="statusChart"></canvas>
      </div>
    </div>
  </div>
</div>

<p class="text-center mb-3"><a href="<?php echo BASE_URL; ?>admin/reports/index.php" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-chart-line"></i> View Full Reports Dashboard</a></p>

<div class="admin-card">
  <h5><i class="fa-solid fa-clock-rotate-left"></i> Recent Bookings</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Flight</th><th>Class</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php while ($b = mysqli_fetch_assoc($recent)): ?>
        <?php $badgeMap = array('Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'); $badge = isset($badgeMap[$b['booking_status']]) ? $badgeMap[$b['booking_status']] : 'secondary'; ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['full_name']); ?></td>
          <td><?php echo clean($b['flight_number']); ?></td>
          <td><?php echo clean($b['travel_class']); ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($b['booking_status']); ?></span></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-6">
    <div class="admin-card mb-0 h-100">
      <h5><i class="fa-solid fa-credit-card"></i> Recent Payments</h5>
      <div class="table-responsive">
        <table class="table table-custom align-middle">
          <thead><tr><th>Transaction</th><th>User</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($recentPayments) === 0): ?>
            <tr><td colspan="4" class="text-center text-muted py-3">No payments yet.</td></tr>
          <?php endif; ?>
          <?php while ($p = mysqli_fetch_assoc($recentPayments)): ?>
            <?php $pBadgeMap = array('Success'=>'success','Pending'=>'warning','Failed'=>'danger','Refunded'=>'secondary'); $pBadge = isset($pBadgeMap[$p['payment_status']]) ? $pBadgeMap[$p['payment_status']] : 'secondary'; ?>
            <tr>
              <td><small><?php echo clean($p['transaction_id']); ?></small></td>
              <td><?php echo clean($p['full_name']); ?></td>
              <td><?php echo formatMoney($p['amount']); ?></td>
              <td><span class="badge bg-<?php echo $pBadge; ?>"><?php echo clean($p['payment_status']); ?></span></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <a href="<?php echo BASE_URL; ?>admin/payments/payments.php" class="btn btn-sm btn-outline-primary">View All Payments</a>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="admin-card mb-0 h-100">
      <h5><i class="fa-solid fa-rotate-left"></i> Recent Refunds</h5>
      <div class="table-responsive">
        <table class="table table-custom align-middle">
          <thead><tr><th>Booking</th><th>User</th><th>Refund Amt</th><th>Status</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($recentRefunds) === 0): ?>
            <tr><td colspan="4" class="text-center text-muted py-3">No refund requests yet.</td></tr>
          <?php endif; ?>
          <?php while ($r = mysqli_fetch_assoc($recentRefunds)): ?>
            <tr>
              <td><?php echo clean($r['booking_reference']); ?></td>
              <td><?php echo clean($r['full_name']); ?></td>
              <td><?php echo formatMoney($r['refund_amount']); ?></td>
              <td><span class="badge bg-<?php echo refundStatusBadge($r['refund_status']); ?>"><?php echo clean($r['refund_status']); ?></span></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      <a href="<?php echo BASE_URL; ?>admin/refunds/refunds.php" class="btn btn-sm btn-outline-primary">Manage Refunds</a>
    </div>
  </div>
</div>

<div class="admin-card">
  <h5><i class="fa-solid fa-comment-dots"></i> Recent Feedback</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>User</th><th>Message</th><th>Rating</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php if (mysqli_num_rows($recentFeedback) === 0): ?>
        <tr><td colspan="5" class="text-center text-muted py-3">No feedback submitted yet.</td></tr>
      <?php endif; ?>
      <?php while ($f = mysqli_fetch_assoc($recentFeedback)): ?>
        <tr>
          <td><?php echo clean($f['full_name']); ?></td>
          <td><?php echo clean(mb_strimwidth($f['message'], 0, 60, '...')); ?></td>
          <td><?php echo $f['rating'] ? clean($f['rating']) . ' ★' : '—'; ?></td>
          <td><span class="badge bg-<?php echo $f['status']=='Replied'?'success':'warning'; ?>"><?php echo clean($f['status']); ?></span></td>
          <td><?php echo formatDate($f['created_at']); ?></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
  <a href="<?php echo BASE_URL; ?>admin/feedback/feedback.php" class="btn btn-sm btn-outline-primary">Manage Feedback</a>
</div>


<!-- Chart.js for admin dashboard graphs -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
// Fallback in case cdnjs is unreachable on this network (common on local WAMP/uWAMP setups)
if (typeof Chart === 'undefined') {
  document.write('<script src="https:\/\/cdn.jsdelivr.net\/npm\/chart.js@4.4.4\/dist\/chart.umd.min.js"><\/script>');
}
</script>
<script>
(function() {
  const trendLabels = <?php echo json_encode($trendLabels); ?>;

  try {
  new Chart(document.getElementById('trendChart'), {
    data: {
      labels: trendLabels,
      datasets: [
        {
          type: 'bar',
          label: 'Bookings',
          data: <?php echo json_encode($trendBookings); ?>,
          backgroundColor: 'rgba(30,144,255,0.55)',
          borderRadius: 6,
          yAxisID: 'y',
          order: 2
        },
        {
          type: 'line',
          label: 'Revenue (₹)',
          data: <?php echo json_encode($trendRevenue); ?>,
          borderColor: '#1fa971',
          backgroundColor: 'rgba(31,169,113,0.15)',
          borderWidth: 3,
          tension: 0.35,
          fill: true,
          pointBackgroundColor: '#1fa971',
          pointRadius: 4,
          yAxisID: 'y1',
          order: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Poppins', size: 12 } } }
      },
      scales: {
        y: { beginAtZero: true, position: 'left', grid: { color: '#eef3fa' }, title: { display: true, text: 'Bookings' } },
        y1: { beginAtZero: true, position: 'right', grid: { display: false }, title: { display: true, text: 'Revenue (₹)' } },
        x: { grid: { display: false } }
      }
    }
  });
  } catch (e) { console.error(e); }

  try {
  new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
      labels: ['Confirmed', 'Pending', 'Completed', 'Cancelled'],
      datasets: [{
        data: [
          <?php echo (int) $statusCounts['Confirmed']; ?>,
          <?php echo (int) $statusCounts['Pending']; ?>,
          <?php echo (int) $statusCounts['Completed']; ?>,
          <?php echo (int) $statusCounts['Cancelled']; ?>
        ],
        backgroundColor: ['#1e90ff', '#f4b400', '#1fa971', '#dc3545'],
        borderWidth: 3,
        borderColor: '#fff',
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '62%',
      plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Poppins', size: 12 } } } }
    }
  });
  } catch (e) { console.error(e); }
})();
</script>

<?php require_once 'includes/footer.php'; ?>
