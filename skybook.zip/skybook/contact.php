<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Contact Us';

$errors = [];
$successMsg = '';
$old = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['name'] = trim(isset($_POST['name']) ? $_POST['name'] : '');
    $old['email'] = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $old['phone'] = trim(isset($_POST['phone']) ? $_POST['phone'] : '');
    $old['subject'] = trim(isset($_POST['subject']) ? $_POST['subject'] : '');
    $old['message'] = trim(isset($_POST['message']) ? $_POST['message'] : '');

    if ($old['name'] === '') $errors[] = 'Please enter your name.';
    if (strlen($old['name']) > 0 && strlen($old['name']) < 3) $errors[] = 'Name must be at least 3 characters long.';
    if ($old['email'] === '' || !filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if ($old['phone'] === '') {
        $errors[] = 'Please enter your phone number.';
    } elseif (!preg_match('/^[0-9+\-\s()]{7,15}$/', $old['phone'])) {
        $errors[] = 'Please enter a valid phone number.';
    }
    if ($old['subject'] === '') $errors[] = 'Please enter a subject.';
    if (strlen($old['subject']) > 0 && strlen($old['subject']) < 3) $errors[] = 'Subject must be at least 3 characters long.';
    if ($old['message'] === '') $errors[] = 'Please enter your message.';
    if ($old['message'] !== '' && strlen($old['message']) < 10) $errors[] = 'Message must be at least 10 characters long.';

    if (empty($errors)) {
        $name = clean($old['name']);
        $email = clean($old['email']);
        $phone = clean($old['phone']);
        $subject = clean($old['subject']);
        $message = clean($old['message']);

        $stmt = mysqli_prepare($conn, "INSERT INTO contact_messages (name, email, phone, subject, message) VALUES (?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sssss', $name, $email, $phone, $subject, $message);
        if (mysqli_stmt_execute($stmt)) {
            $successMsg = 'Thank you for contacting Sky Book! Your message has been sent successfully — our team will get back to you soon.';
            $old = ['name' => '', 'email' => '', 'phone' => '', 'subject' => '', 'message' => ''];
        } else {
            $errors[] = 'Something went wrong while sending your message. Please try again.';
        }
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<section class="hero-section" style="padding:90px 0 110px;">
  <div class="container">
    <span class="badge-hero"><i class="fa-solid fa-headset"></i> We're Here to Help</span>
    <h1>Contact Us</h1>
    <p class="lead">Have a question about a booking, a flight, or your account? Send us a message and our team will get back to you shortly.</p>
  </div>
</section>

<section class="container contact-section">
  <div class="row g-4 g-lg-5">

    <!-- ---------------- Contact Info Column ---------------- -->
    <div class="col-lg-4">
      <div class="contact-info-card">
        <h4 class="mb-1">Get In Touch</h4>
        <p class="text-muted mb-4">Reach out to us any time — we usually reply within 24 hours.</p>

        <div class="contact-info-item">
          <div class="contact-info-icon"><i class="fa-solid fa-phone"></i></div>
          <div>
            <h6>Call Us</h6>
            <p class="mb-0"><?php echo clean(getSetting($conn, 'support_phone', '+91 98765 43210')); ?></p>
          </div>
        </div>

        <div class="contact-info-item">
          <div class="contact-info-icon"><i class="fa-solid fa-envelope"></i></div>
          <div>
            <h6>Email Us</h6>
            <p class="mb-0"><?php echo clean(getSetting($conn, 'support_email', 'support@skybook.com')); ?></p>
          </div>
        </div>

        <div class="contact-info-item">
          <div class="contact-info-icon"><i class="fa-solid fa-location-dot"></i></div>
          <div>
            <h6>Visit Us</h6>
            <p class="mb-0"><?php echo clean(getSetting($conn, 'support_address', 'Sky Book HQ, Rajkot, Gujarat, India')); ?></p>
          </div>
        </div>

        <div class="contact-info-item">
          <div class="contact-info-icon"><i class="fa-solid fa-clock"></i></div>
          <div>
            <h6>Support Hours</h6>
            <p class="mb-0">Mon – Sat, 9:00 AM to 8:00 PM IST</p>
          </div>
        </div>

        <div class="contact-social mt-4">
          <a href="#" title="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="#" title="Twitter / X"><i class="fa-brands fa-twitter"></i></a>
          <a href="#" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="#" title="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
        </div>
      </div>
    </div>

    <!-- ---------------- Contact Form Column ---------------- -->
    <div class="col-lg-8">
      <div class="contact-form-card">
        <h4 class="mb-1"><i class="fa-solid fa-paper-plane text-primary"></i> Send Us a Message</h4>
        <p class="text-muted mb-4">Fill out the form below and we'll respond as soon as possible.</p>

        <?php if (!empty($successMsg)): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-circle-check"></i> <?php echo clean($successMsg); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
              <?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>

        <form method="POST" action="contact.php" class="contact-form">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label"><i class="fa-solid fa-user"></i> Full Name</label>
              <input type="text" name="name" class="form-control" placeholder="Your full name" minlength="3" value="<?php echo clean($old['name']); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label"><i class="fa-solid fa-envelope"></i> Email Address</label>
              <input type="email" name="email" class="form-control" placeholder="you@example.com" value="<?php echo clean($old['email']); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label"><i class="fa-solid fa-phone"></i> Phone Number</label>
              <input type="text" name="phone" class="form-control" placeholder="e.g. 9876543210" pattern="[0-9+\-\s()]{7,15}" title="Enter a valid phone number" value="<?php echo clean($old['phone']); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label"><i class="fa-solid fa-tag"></i> Subject</label>
              <input type="text" name="subject" class="form-control" placeholder="What is this about?" minlength="3" value="<?php echo clean($old['subject']); ?>" required>
            </div>
            <div class="col-12">
              <label class="form-label"><i class="fa-solid fa-comment"></i> Message</label>
              <textarea name="message" rows="5" class="form-control" placeholder="Tell us how we can help..." minlength="10" required><?php echo clean($old['message']); ?></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary-custom mt-4 w-100 w-md-auto px-5"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
        </form>
      </div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
