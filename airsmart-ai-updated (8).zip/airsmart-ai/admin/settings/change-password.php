<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Change Password';

$adminId = $_SESSION['admin_id'];
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $stmt = mysqli_prepare($conn, "SELECT password FROM admins WHERE admin_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $adminId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$row || !password_verify($current, $row['password'])) {
        $errors[] = 'Current password is incorrect.';
    }
    if (strlen($new) < 6) {
        $errors[] = 'New password must be at least 6 characters long.';
    }
    if ($new !== $confirm) {
        $errors[] = 'New password and confirm password do not match.';
    }

    if (empty($errors)) {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "UPDATE admins SET password = ? WHERE admin_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $hashed, $adminId);
        mysqli_stmt_execute($stmt);
        $success = true;
    }
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:600px;">
  <h5><i class="fa-solid fa-key"></i> Change Admin Password</h5>
  <?php if ($success): ?><div class="alert alert-success">Password updated successfully.</div><?php endif; ?>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="change-password.php">
    <div class="mb-3">
      <label>Current Password</label>
      <div class="password-wrapper">
        <input type="password" name="current_password" class="form-control" required>
        <i class="fa-solid fa-eye toggle-eye"></i>
      </div>
    </div>
    <div class="mb-3">
      <label>New Password</label>
      <div class="password-wrapper">
        <input type="password" name="new_password" class="form-control" required>
        <i class="fa-solid fa-eye toggle-eye"></i>
      </div>
    </div>
    <div class="mb-3">
      <label>Confirm New Password</label>
      <div class="password-wrapper">
        <input type="password" name="confirm_password" class="form-control" required>
        <i class="fa-solid fa-eye toggle-eye"></i>
      </div>
    </div>
    <button type="submit" class="btn btn-primary-custom">Update Password</button>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
