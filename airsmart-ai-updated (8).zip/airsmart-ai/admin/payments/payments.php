<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Manage Payments';

$result = mysqli_query($conn, "SELECT p.*, b.booking_reference, u.full_name FROM payments p
    JOIN bookings b ON p.booking_id = b.booking_id JOIN users u ON b.user_id = u.user_id
    ORDER BY p.payment_date DESC");
$payments = mysqli_fetch_all($result, MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Transaction ID</th><th>Booking Ref</th><th>User</th><th>Card</th><th>Amount</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (empty($payments)): ?><tr><td colspan="8" class="text-center text-muted py-4">No payments found.</td></tr><?php endif; ?>
      <?php foreach ($payments as $p): ?>
        <?php $badge = ['Success'=>'success','Pending'=>'warning','Failed'=>'danger','Refunded'=>'secondary'][$p['payment_status']] ?? 'secondary'; ?>
        <tr>
          <td><?php echo clean($p['transaction_id']); ?></td>
          <td><?php echo clean($p['booking_reference']); ?></td>
          <td><?php echo clean($p['full_name']); ?></td>
          <td><?php echo clean($p['masked_card_number']); ?></td>
          <td><?php echo formatMoney($p['amount']); ?></td>
          <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($p['payment_status']); ?></span></td>
          <td><?php echo formatDate($p['payment_date']); ?></td>
          <td><a href="view-payment.php?id=<?php echo $p['payment_id']; ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-eye"></i></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
