<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Announcements';

$result = mysqli_query($conn, "SELECT * FROM announcements ORDER BY publish_date DESC, announcement_id DESC");
$announcements = mysqli_fetch_all($result, MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <div class="d-flex justify-content-between mb-3">
    <h5 class="mb-0"><i class="fa-solid fa-bullhorn"></i> Announcements</h5>
    <a href="add-announcement.php" class="btn btn-primary-custom"><i class="fa-solid fa-plus"></i> Add Announcement</a>
  </div>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Title</th><th>Message</th><th>Publish Date</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (empty($announcements)): ?><tr><td colspan="5" class="text-center text-muted py-4">No announcements yet.</td></tr><?php endif; ?>
      <?php foreach ($announcements as $a): ?>
        <tr>
          <td><?php echo clean($a['title']); ?></td>
          <td><?php echo clean(mb_strimwidth($a['description'], 0, 60, '...')); ?></td>
          <td><?php echo formatDate($a['publish_date']); ?></td>
          <td><span class="badge bg-<?php echo $a['status']=='Active'?'success':'secondary'; ?>"><?php echo clean($a['status']); ?></span></td>
          <td>
            <a href="edit-announcement.php?id=<?php echo $a['announcement_id']; ?>" class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-pen"></i></a>
            <a href="delete-announcement.php?id=<?php echo $a['announcement_id']; ?>" class="btn btn-sm btn-outline-danger confirm-delete"><i class="fa-solid fa-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
