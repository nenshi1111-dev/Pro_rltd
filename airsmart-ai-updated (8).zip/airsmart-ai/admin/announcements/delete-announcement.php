<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';

$id = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "DELETE FROM announcements WHERE announcement_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
setAlert('Announcement deleted successfully.', 'success');
redirect(BASE_URL . 'admin/announcements/announcements.php');
