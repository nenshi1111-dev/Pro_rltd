<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Edit Announcement';

$id = (int) ($_GET['id'] ?? $_POST['announcement_id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT * FROM announcements WHERE announcement_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$a = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$a) {
    setAlert('Announcement not found.', 'danger');
    redirect(BASE_URL . 'admin/announcements/announcements.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = clean($_POST['title']);
    $description = clean($_POST['description']);
    $publishDate = clean($_POST['publish_date']);
    $status = clean($_POST['status']);

    if ($title === '' || $description === '') {
        $errors[] = 'Please fill both title and message.';
    }

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "UPDATE announcements SET title=?, description=?, publish_date=?, status=? WHERE announcement_id=?");
        mysqli_stmt_bind_param($stmt, 'ssssi', $title, $description, $publishDate, $status, $id);
        mysqli_stmt_execute($stmt);
        setAlert('Announcement updated successfully.', 'success');
        redirect(BASE_URL . 'admin/announcements/announcements.php');
    }
    $a = array_merge($a, ['title'=>$title,'description'=>$description,'publish_date'=>$publishDate,'status'=>$status]);
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card" style="max-width:700px;">
  <h5><i class="fa-solid fa-pen"></i> Edit Announcement</h5>
  <?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div><?php endif; ?>
  <form method="POST" action="edit-announcement.php?id=<?php echo $id; ?>">
    <div class="mb-3"><label>Title</label><input type="text" name="title" class="form-control" value="<?php echo clean($a['title']); ?>" required></div>
    <div class="mb-3"><label>Message</label><textarea name="description" class="form-control" rows="4" required><?php echo clean($a['description']); ?></textarea></div>
    <div class="mb-3"><label>Publish Date</label><input type="date" name="publish_date" class="form-control" value="<?php echo clean($a['publish_date']); ?>" required></div>
    <div class="mb-3">
      <label>Status</label>
      <select name="status" class="form-select">
        <option value="Active" <?php echo $a['status']=='Active'?'selected':''; ?>>Active</option>
        <option value="Inactive" <?php echo $a['status']=='Inactive'?'selected':''; ?>>Inactive</option>
      </select>
    </div>
    <button type="submit" class="btn btn-primary-custom"><i class="fa-solid fa-check"></i> Update</button>
    <a href="announcements.php" class="btn btn-outline-secondary">Cancel</a>
  </form>
</div>
<?php require_once '../includes/footer.php'; ?>
