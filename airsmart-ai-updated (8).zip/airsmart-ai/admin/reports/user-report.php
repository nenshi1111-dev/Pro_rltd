<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'User Report';

$result = mysqli_query($conn, "SELECT u.*,
    (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.user_id) AS total_bookings,
    (SELECT IFNULL(SUM(b.total_amount),0) FROM bookings b WHERE b.user_id=u.user_id AND b.payment_status='Success') AS total_spent
    FROM users u ORDER BY total_spent DESC");
$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="user-report.php">User Report</a></li>
</ul>

<div class="admin-card">
  <h5><i class="fa-solid fa-users"></i> Top Users by Spending</h5>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Name</th><th>Email</th><th>Total Bookings</th><th>Total Spent</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo clean($u['full_name']); ?></td>
          <td><?php echo clean($u['email']); ?></td>
          <td><?php echo $u['total_bookings']; ?></td>
          <td><?php echo formatMoney($u['total_spent']); ?></td>
          <td><span class="badge bg-<?php echo $u['status']=='Active'?'success':'secondary'; ?>"><?php echo clean($u['status']); ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
