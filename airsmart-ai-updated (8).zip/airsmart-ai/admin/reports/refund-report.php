<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Refund Report';

$fromDate = clean($_GET['from'] ?? '');
$toDate = clean($_GET['to'] ?? '');

$sql = "SELECT c.*, b.booking_reference, b.travel_class, u.full_name FROM cancellations c
    JOIN bookings b ON c.booking_id = b.booking_id JOIN users u ON b.user_id = u.user_id WHERE 1=1";
$params = []; $types = '';
if ($fromDate !== '') { $sql .= " AND DATE(c.cancellation_date) >= ?"; $params[] = $fromDate; $types .= 's'; }
if ($toDate !== '') { $sql .= " AND DATE(c.cancellation_date) <= ?"; $params[] = $toDate; $types .= 's'; }
$sql .= " ORDER BY c.cancellation_date DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$refunds = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$totalRequested = count($refunds);
$totalCompletedAmount = 0; $totalPendingAmount = 0; $totalRejected = 0;
$statusCounts = ['Pending' => 0, 'Processing' => 0, 'Completed' => 0, 'Rejected' => 0, 'Not Applicable' => 0];
foreach ($refunds as $r) {
    $statusCounts[$r['refund_status']] = ($statusCounts[$r['refund_status']] ?? 0) + 1;
    if ($r['refund_status'] === 'Completed') $totalCompletedAmount += $r['refund_amount'];
    if (in_array($r['refund_status'], ['Pending', 'Processing'], true)) $totalPendingAmount += $r['refund_amount'];
    if ($r['refund_status'] === 'Rejected') $totalRejected++;
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="admin-card">
  <form method="GET" class="row g-2 align-items-end mb-2">
    <div class="col-auto"><label class="small">From</label><input type="date" name="from" class="form-control" value="<?php echo clean($fromDate); ?>"></div>
    <div class="col-auto"><label class="small">To</label><input type="date" name="to" class="form-control" value="<?php echo clean($toDate); ?>"></div>
    <div class="col-auto"><button class="btn btn-dark-blue"><i class="fa-solid fa-filter"></i> Filter</button></div>
  </form>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-rotate-left"></i></div><div><h3><?php echo $totalRequested; ?></h3><p>Total Requests</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:var(--success-green);"><i class="fa-solid fa-indian-rupee-sign"></i></div><div><h3><?php echo formatMoney($totalCompletedAmount); ?></h3><p>Refunded (Completed)</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div><div><h3><?php echo formatMoney($totalPendingAmount); ?></h3><p>Awaiting Refund</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:var(--danger-red);"><i class="fa-solid fa-circle-xmark"></i></div><div><h3><?php echo $totalRejected; ?></h3><p>Rejected</p></div></div></div>
</div>

<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-pie text-primary"></i> Refund Status Breakdown</h5>
      <p class="chart-sub">All refund requests in the selected range, by status</p>
      <div class="chart-canvas-wrap h-220">
        <canvas id="refundStatusChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Class</th><th>Cancelled By</th><th>Refund %</th><th>Refund Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php if (empty($refunds)): ?><tr><td colspan="8" class="text-center text-muted py-4">No refund records found.</td></tr><?php endif; ?>
      <?php foreach ($refunds as $r): ?>
        <tr>
          <td><?php echo clean($r['booking_reference']); ?></td>
          <td><?php echo clean($r['full_name']); ?></td>
          <td><?php echo clean($r['travel_class']); ?></td>
          <td><?php echo clean($r['cancelled_by']); ?></td>
          <td><?php echo (float) $r['refund_percentage']; ?>%</td>
          <td><?php echo formatMoney($r['refund_amount']); ?></td>
          <td><span class="badge bg-<?php echo refundStatusBadge($r['refund_status']); ?>"><?php echo clean($r['refund_status']); ?></span></td>
          <td><?php echo formatDate($r['cancellation_date']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('refundStatusChart'), {
  type: 'bar',
  data: {
    labels: ['Pending', 'Processing', 'Completed', 'Rejected', 'Not Applicable'],
    datasets: [{
      label: 'Requests',
      data: [
        <?php echo (int) $statusCounts['Pending']; ?>,
        <?php echo (int) $statusCounts['Processing']; ?>,
        <?php echo (int) $statusCounts['Completed']; ?>,
        <?php echo (int) $statusCounts['Rejected']; ?>,
        <?php echo (int) $statusCounts['Not Applicable']; ?>
      ],
      backgroundColor: ['#f4b400', '#1e90ff', '#1fa971', '#dc3545', '#6c757d'],
      borderRadius: 6,
      maxBarThickness: 46
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, grid: { color: '#eef3fa' }, ticks: { precision: 0 } },
      x: { grid: { display: false } }
    }
  }
});
</script>

<?php require_once '../includes/footer.php'; ?>
