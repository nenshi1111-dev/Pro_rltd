<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Feedback Report';

$fromDate = clean($_GET['from'] ?? '');
$toDate = clean($_GET['to'] ?? '');

$sql = "SELECT f.*, u.full_name FROM feedback f JOIN users u ON f.user_id = u.user_id WHERE 1=1";
$params = []; $types = '';
if ($fromDate !== '') { $sql .= " AND DATE(f.created_at) >= ?"; $params[] = $fromDate; $types .= 's'; }
if ($toDate !== '') { $sql .= " AND DATE(f.created_at) <= ?"; $params[] = $toDate; $types .= 's'; }
$sql .= " ORDER BY f.created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$feedbackList = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$totalFeedback = count($feedbackList);
$pendingCount = 0; $repliedCount = 0; $ratingSum = 0; $ratingN = 0;
$ratingCounts = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
foreach ($feedbackList as $f) {
    if ($f['status'] === 'Pending') $pendingCount++; else $repliedCount++;
    if ($f['rating']) { $ratingSum += $f['rating']; $ratingN++; $ratingCounts[(int) $f['rating']]++; }
}
$avgRating = $ratingN ? round($ratingSum / $ratingN, 1) : 0;

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="admin-card">
  <form method="GET" class="row g-2 align-items-end mb-2">
    <div class="col-auto"><label class="small">From</label><input type="date" name="from" class="form-control" value="<?php echo clean($fromDate); ?>"></div>
    <div class="col-auto"><label class="small">To</label><input type="date" name="to" class="form-control" value="<?php echo clean($toDate); ?>"></div>
    <div class="col-auto"><button class="btn btn-dark-blue"><i class="fa-solid fa-filter"></i> Filter</button></div>
  </form>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-comment-dots"></i></div><div><h3><?php echo $totalFeedback; ?></h3><p>Total Feedback</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div><div><h3><?php echo $pendingCount; ?></h3><p>Pending Reply</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div><div><h3><?php echo $repliedCount; ?></h3><p>Replied</p></div></div></div>
  <div class="col-md-3 col-sm-6"><div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-star"></i></div><div><h3><?php echo $avgRating; ?> / 5</h3><p>Average Rating</p></div></div></div>
</div>

<div class="row g-4 mb-4">
  <div class="col-12">
    <div class="chart-card">
      <h5><i class="fa-solid fa-chart-column text-primary"></i> Rating Distribution</h5>
      <p class="chart-sub">Star ratings for feedback in the selected range</p>
      <div class="chart-canvas-wrap h-220">
        <canvas id="fbRatingChart"></canvas>
      </div>
    </div>
  </div>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>User</th><th>Message</th><th>Rating</th><th>Status</th><th>Submitted On</th></tr></thead>
      <tbody>
      <?php if (empty($feedbackList)): ?><tr><td colspan="5" class="text-center text-muted py-4">No feedback found.</td></tr><?php endif; ?>
      <?php foreach ($feedbackList as $f): ?>
        <tr>
          <td><?php echo clean($f['full_name']); ?></td>
          <td><?php echo clean(mb_strimwidth($f['message'], 0, 80, '...')); ?></td>
          <td><?php echo $f['rating'] ? clean($f['rating']) . ' ★' : '—'; ?></td>
          <td><span class="badge bg-<?php echo $f['status']=='Replied'?'success':'warning'; ?>"><?php echo clean($f['status']); ?></span></td>
          <td><?php echo formatDate($f['created_at']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('fbRatingChart'), {
  type: 'bar',
  data: {
    labels: ['1 ★', '2 ★', '3 ★', '4 ★', '5 ★'],
    datasets: [{
      label: 'Feedback Count',
      data: [
        <?php echo (int) $ratingCounts[1]; ?>,
        <?php echo (int) $ratingCounts[2]; ?>,
        <?php echo (int) $ratingCounts[3]; ?>,
        <?php echo (int) $ratingCounts[4]; ?>,
        <?php echo (int) $ratingCounts[5]; ?>
      ],
      backgroundColor: '#f4b400',
      borderRadius: 6,
      maxBarThickness: 46
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, grid: { color: '#eef3fa' }, ticks: { precision: 0 } },
      x: { grid: { display: false } }
    }
  }
});
</script>

<?php require_once '../includes/footer.php'; ?>
