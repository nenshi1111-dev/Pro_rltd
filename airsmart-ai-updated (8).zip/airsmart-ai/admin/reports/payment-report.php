<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Payment Report';

$result = mysqli_query($conn, "SELECT p.*, b.booking_reference, u.full_name FROM payments p
    JOIN bookings b ON p.booking_id=b.booking_id JOIN users u ON b.user_id=u.user_id ORDER BY p.payment_date DESC");
$payments = mysqli_fetch_all($result, MYSQLI_ASSOC);

$totalSuccess = 0; $totalFailed = 0; $totalAmount = 0;
foreach ($payments as $p) {
    if ($p['payment_status']==='Success') { $totalSuccess++; $totalAmount += $p['amount']; }
    if ($p['payment_status']==='Failed') $totalFailed++;
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<ul class="nav nav-pills mb-4 flex-wrap">
  <li class="nav-item"><a class="nav-link" href="flight-report.php">Flight Report</a></li>
  <li class="nav-item"><a class="nav-link" href="booking-report.php">Booking Report</a></li>
  <li class="nav-item"><a class="nav-link active" href="payment-report.php">Payment Report</a></li>
  <li class="nav-item"><a class="nav-link" href="refund-report.php">Refund Report</a></li>
  <li class="nav-item"><a class="nav-link" href="feedback-report.php">Feedback Report</a></li>
  <li class="nav-item"><a class="nav-link" href="user-report.php">User Report</a></li>
</ul>

<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-check"></i></div><div><h3><?php echo $totalSuccess; ?></h3><p>Successful Payments</p></div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-xmark"></i></div><div><h3><?php echo $totalFailed; ?></h3><p>Failed Payments</p></div></div></div>
  <div class="col-md-4"><div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div><div><h3><?php echo formatMoney($totalAmount); ?></h3><p>Total Collected</p></div></div></div>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Transaction ID</th><th>Booking Ref</th><th>User</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($payments as $p): ?>
        <tr>
          <td><?php echo clean($p['transaction_id']); ?></td>
          <td><?php echo clean($p['booking_reference']); ?></td>
          <td><?php echo clean($p['full_name']); ?></td>
          <td><?php echo formatMoney($p['amount']); ?></td>
          <td><?php echo clean($p['payment_status']); ?></td>
          <td><?php echo formatDate($p['payment_date']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
