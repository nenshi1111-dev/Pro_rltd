<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Refund Management';

// ---------------- Handle refund status update ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancellation_id'])) {
    $cancellationId = (int) $_POST['cancellation_id'];
    $newStatus = $_POST['refund_status'] ?? '';
    $allowed = ['Pending', 'Processing', 'Completed', 'Rejected', 'Not Applicable'];

    if (!in_array($newStatus, $allowed, true)) {
        setAlert('Invalid refund status selected.', 'danger');
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE cancellations SET refund_status = ?, updated_at = NOW() WHERE cancellation_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $newStatus, $cancellationId);
        if (mysqli_stmt_execute($stmt)) {
            // When a refund is marked Completed, reflect that on the linked
            // payment record too, so the Payments section stays in sync.
            if ($newStatus === 'Completed') {
                $stmt2 = mysqli_prepare($conn, "SELECT booking_id FROM cancellations WHERE cancellation_id = ?");
                mysqli_stmt_bind_param($stmt2, 'i', $cancellationId);
                mysqli_stmt_execute($stmt2);
                $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt2));
                if ($row) {
                    mysqli_query($conn, "UPDATE payments SET payment_status='Refunded' WHERE booking_id=" . (int) $row['booking_id']);
                    mysqli_query($conn, "UPDATE bookings SET payment_status='Refunded' WHERE booking_id=" . (int) $row['booking_id']);
                }
            }
            setAlert('Refund status updated to "' . clean($newStatus) . '".', 'success');
        } else {
            setAlert('Something went wrong. Please try again.', 'danger');
        }
    }
    redirect(BASE_URL . 'admin/refunds/refunds.php');
}

// ---------------- Filter ----------------
$statusFilter = clean($_GET['status'] ?? '');
$sql = "SELECT c.*, b.booking_reference, b.total_amount, b.travel_class, u.full_name, u.email, f.flight_number, f.departure_date
    FROM cancellations c
    JOIN bookings b ON c.booking_id = b.booking_id
    JOIN users u ON b.user_id = u.user_id
    JOIN flights f ON b.flight_id = f.flight_id
    WHERE 1=1";
$params = []; $types = '';
if ($statusFilter !== '') {
    $sql .= " AND c.refund_status = ?";
    $params[] = $statusFilter; $types .= 's';
}
$sql .= " ORDER BY (c.refund_status='Pending') DESC, c.cancellation_date DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$refunds = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

// ---------------- Summary counts ----------------
$totalRefunds = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations"))['total'];
$pendingRefunds = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations WHERE refund_status IN ('Pending','Processing')"))['total'];
$completedRefunds = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations WHERE refund_status='Completed'"))['total'];
$totalRefundAmount = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(refund_amount),0) AS total FROM cancellations WHERE refund_status='Completed'"))['total'];

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>

<div class="row g-4 mb-4">
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-rotate-left"></i></div>
      <div><h3><?php echo $totalRefunds; ?></h3><p>Total Refund Requests</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon" style="color:#f4b400;"><i class="fa-solid fa-hourglass-half"></i></div>
      <div><h3><?php echo $pendingRefunds; ?></h3><p>Pending / Processing</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon" style="color:var(--success-green);"><i class="fa-solid fa-circle-check"></i></div>
      <div><h3><?php echo $completedRefunds; ?></h3><p>Completed Refunds</p></div></div>
  </div>
  <div class="col-md-3 col-sm-6">
    <div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-indian-rupee-sign"></i></div>
      <div><h3><?php echo formatMoney($totalRefundAmount); ?></h3><p>Total Refunded Amount</p></div></div>
  </div>
</div>

<div class="admin-card">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <h5 class="mb-0"><i class="fa-solid fa-rotate-left"></i> All Refund Requests</h5>
    <form method="GET" class="d-flex gap-2">
      <select name="status" class="form-select w-auto" onchange="this.form.submit()">
        <option value="">All Status</option>
        <?php foreach (['Pending', 'Processing', 'Completed', 'Rejected', 'Not Applicable'] as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $statusFilter === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead>
        <tr>
          <th>Booking Ref</th><th>User</th><th>Flight</th><th>Cancelled By</th>
          <th>Original Amount</th><th>Refund %</th><th>Refund Amount</th><th>Status</th><th>Date</th><th>Update</th>
        </tr>
      </thead>
      <tbody>
      <?php if (empty($refunds)): ?>
        <tr><td colspan="10" class="text-center text-muted py-4">No refund requests found.</td></tr>
      <?php endif; ?>
      <?php foreach ($refunds as $r): ?>
        <tr>
          <td><?php echo clean($r['booking_reference']); ?></td>
          <td><?php echo clean($r['full_name']); ?><br><small class="text-muted"><?php echo clean($r['email']); ?></small></td>
          <td><?php echo clean($r['flight_number']); ?> <span class="badge bg-secondary"><?php echo clean($r['travel_class']); ?></span></td>
          <td><?php echo clean($r['cancelled_by']); ?></td>
          <td><?php echo formatMoney($r['total_amount']); ?></td>
          <td><?php echo (float) $r['refund_percentage']; ?>%</td>
          <td><strong><?php echo formatMoney($r['refund_amount']); ?></strong></td>
          <td><span class="badge bg-<?php echo refundStatusBadge($r['refund_status']); ?>"><?php echo clean($r['refund_status']); ?></span></td>
          <td><?php echo formatDate($r['cancellation_date']); ?></td>
          <td>
            <?php if (!in_array($r['refund_status'], ['Completed', 'Rejected', 'Not Applicable'], true)): ?>
            <form method="POST" class="d-flex gap-1">
              <input type="hidden" name="cancellation_id" value="<?php echo (int) $r['cancellation_id']; ?>">
              <select name="refund_status" class="form-select form-select-sm">
                <option value="Pending" <?php echo $r['refund_status']=='Pending'?'selected':''; ?>>Pending</option>
                <option value="Processing" <?php echo $r['refund_status']=='Processing'?'selected':''; ?>>Processing</option>
                <option value="Completed">Completed</option>
                <option value="Rejected">Rejected</option>
              </select>
              <button type="submit" class="btn btn-sm btn-primary-custom"><i class="fa-solid fa-check"></i></button>
            </form>
            <?php else: ?>
              <span class="text-muted small">—</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
