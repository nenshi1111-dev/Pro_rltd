<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

session_unset();
session_destroy();
session_start();
setAlert('Admin logged out successfully.', 'success');
redirect(BASE_URL . 'admin/login.php');
