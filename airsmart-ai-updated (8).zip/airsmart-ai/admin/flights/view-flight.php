<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'View Flight';

$flightId = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $flightId);
mysqli_stmt_execute($stmt);
$f = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$f) {
    setAlert('Flight not found.', 'danger');
    redirect(BASE_URL . 'admin/flights/flights.php');
}

// Bookings on this flight
$stmt = mysqli_prepare($conn, "SELECT b.*, u.full_name FROM bookings b JOIN users u ON b.user_id=u.user_id WHERE b.flight_id=? ORDER BY b.booking_date DESC");
mysqli_stmt_bind_param($stmt, 'i', $flightId);
mysqli_stmt_execute($stmt);
$bookings = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <h5><i class="fa-solid fa-plane"></i> Flight <?php echo clean($f['flight_number']); ?></h5>
  <div class="row">
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Airline</span><span class="value"><?php echo clean($f['airline_name']); ?></span></div>
      <div class="ticket-row"><span class="label">Route</span><span class="value"><?php echo clean($f['source']); ?> → <?php echo clean($f['destination']); ?></span></div>
      <div class="ticket-row"><span class="label">Date</span><span class="value"><?php echo formatDate($f['departure_date']); ?></span></div>
      <div class="ticket-row"><span class="label">Time</span><span class="value"><?php echo formatTime($f['departure_time']); ?> - <?php echo formatTime($f['arrival_time']); ?> (<?php echo clean($f['duration']); ?>)</span></div>
    </div>
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Status</span><span class="value"><?php echo clean($f['status']); ?></span></div>
      <div class="ticket-row"><span class="label">Economy</span><span class="value"><?php echo $f['economy_available_seats']; ?>/<?php echo $f['economy_total_seats']; ?> available — <?php echo formatMoney($f['economy_price']); ?></span></div>
      <div class="ticket-row"><span class="label">Business</span><span class="value"><?php echo $f['business_available_seats']; ?>/<?php echo $f['business_total_seats']; ?> available — <?php echo formatMoney($f['business_price']); ?></span></div>
    </div>
  </div>
  <a href="edit-flight.php?id=<?php echo $flightId; ?>" class="btn btn-primary-custom mt-2"><i class="fa-solid fa-pen"></i> Edit</a>
  <a href="flights.php" class="btn btn-outline-secondary mt-2">Back</a>
</div>

<div class="admin-card">
  <h5><i class="fa-solid fa-ticket"></i> Bookings on this Flight</h5>
  <div class="table-responsive">
    <table class="table table-custom">
      <thead><tr><th>Booking Ref</th><th>User</th><th>Class</th><th>Passengers</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php if (empty($bookings)): ?><tr><td colspan="6" class="text-center text-muted py-3">No bookings yet.</td></tr><?php endif; ?>
      <?php foreach ($bookings as $b): ?>
        <tr>
          <td><?php echo clean($b['booking_reference']); ?></td>
          <td><?php echo clean($b['full_name']); ?></td>
          <td><?php echo clean($b['travel_class']); ?></td>
          <td><?php echo (int)$b['passenger_count']; ?></td>
          <td><?php echo formatMoney($b['total_amount']); ?></td>
          <td><?php echo clean($b['booking_status']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
