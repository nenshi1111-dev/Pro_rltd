<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Manage Flights';

$search = clean($_GET['search'] ?? '');
$sql = "SELECT * FROM flights WHERE 1=1";
$params = []; $types = '';
if ($search !== '') {
    $sql .= " AND (flight_number LIKE ? OR source LIKE ? OR destination LIKE ?)";
    $like = "%$search%";
    $params = [$like, $like, $like];
    $types = 'sss';
}
$sql .= " ORDER BY departure_date DESC, departure_time DESC";
$stmt = mysqli_prepare($conn, $sql);
if (!empty($params)) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$flights = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
    <form method="GET" class="d-flex gap-2">
      <input type="text" name="search" class="form-control" placeholder="Search flight no. / route" value="<?php echo clean($search); ?>">
      <button class="btn btn-dark-blue"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <a href="add-flight.php" class="btn btn-primary-custom"><i class="fa-solid fa-plus"></i> Add New Flight</a>
  </div>
  <div class="table-responsive">
    <table class="table table-custom align-middle">
      <thead><tr><th>Flight No</th><th>Route</th><th>Date</th><th>Time</th><th>Economy</th><th>Business</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php if (empty($flights)): ?><tr><td colspan="8" class="text-center text-muted py-4">No flights found.</td></tr><?php endif; ?>
      <?php foreach ($flights as $f): ?>
        <?php $badge = ['Scheduled'=>'success','Delayed'=>'warning','Cancelled'=>'danger','Completed'=>'secondary'][$f['status']] ?? 'secondary'; ?>
        <tr>
          <td><?php echo clean($f['flight_number']); ?></td>
          <td><?php echo clean($f['source']); ?> → <?php echo clean($f['destination']); ?></td>
          <td><?php echo formatDate($f['departure_date']); ?></td>
          <td><?php echo formatTime($f['departure_time']); ?></td>
          <td><?php echo $f['economy_available_seats']; ?>/<?php echo $f['economy_total_seats']; ?></td>
          <td><?php echo $f['business_available_seats']; ?>/<?php echo $f['business_total_seats']; ?></td>
          <td><span class="badge bg-<?php echo $badge; ?>"><?php echo clean($f['status']); ?></span></td>
          <td>
            <a href="view-flight.php?id=<?php echo $f['flight_id']; ?>" class="btn btn-sm btn-outline-primary" title="View"><i class="fa-solid fa-eye"></i></a>
            <a href="edit-flight.php?id=<?php echo $f['flight_id']; ?>" class="btn btn-sm btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i></a>
            <a href="delete-flight.php?id=<?php echo $f['flight_id']; ?>" class="btn btn-sm btn-outline-danger confirm-delete" title="Delete"><i class="fa-solid fa-trash"></i></a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
