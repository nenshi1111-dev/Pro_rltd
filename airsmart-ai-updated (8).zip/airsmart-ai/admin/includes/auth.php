<?php
/* ============================================================
   AirSmart AI - Admin Authentication Guard
   Include this file at the top of any page that only the
   ADMIN should be able to access. Uses BASE_URL (absolute path)
   because admin pages live at different folder depths
   (admin/index.php vs admin/flights/add-flight.php).
   ============================================================ */
if (!isset($_SESSION['admin_id'])) {
    redirect(BASE_URL . 'admin/login.php');
}
