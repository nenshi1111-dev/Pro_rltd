  </main><!-- /.admin-main -->
</div><!-- /.admin-wrapper -->

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo BASE_URL; ?>js/script.js"></script>
  <script src="<?php echo BASE_URL; ?>admin/js/admin-script.js"></script>
</body>
</html>
