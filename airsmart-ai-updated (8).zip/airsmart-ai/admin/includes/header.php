<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? clean($pageTitle) . ' - Admin - ' . SITE_NAME : 'Admin - ' . SITE_NAME; ?></title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="<?php echo BASE_URL; ?>css/style.css" rel="stylesheet">
<link href="<?php echo BASE_URL; ?>admin/css/admin-style.css" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
