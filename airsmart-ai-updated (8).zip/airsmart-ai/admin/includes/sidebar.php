<?php $currentFile = basename($_SERVER['PHP_SELF']); $currentDir = basename(dirname($_SERVER['PHP_SELF'])); ?>
<aside class="admin-sidebar">
  <div class="admin-brand">
    <i class="fa-solid fa-plane-up"></i> <?php echo SITE_NAME; ?>
    <small class="d-block">Admin Panel</small>
  </div>
  <nav class="admin-nav">
    <a href="<?php echo BASE_URL; ?>admin/index.php" class="<?php echo $currentFile=='index.php' && $currentDir=='admin' ? 'active':''; ?>"><i class="fa-solid fa-gauge"></i> Dashboard</a>
    <a href="<?php echo BASE_URL; ?>admin/flights/flights.php" class="<?php echo $currentDir=='flights'?'active':''; ?>"><i class="fa-solid fa-plane"></i> Flights</a>
    <a href="<?php echo BASE_URL; ?>admin/users/users.php" class="<?php echo $currentDir=='users'?'active':''; ?>"><i class="fa-solid fa-users"></i> Users</a>
    <a href="<?php echo BASE_URL; ?>admin/bookings/bookings.php" class="<?php echo $currentDir=='bookings'?'active':''; ?>"><i class="fa-solid fa-ticket"></i> Bookings</a>
    <a href="<?php echo BASE_URL; ?>admin/payments/payments.php" class="<?php echo $currentDir=='payments'?'active':''; ?>"><i class="fa-solid fa-credit-card"></i> Payments</a>
    <a href="<?php echo BASE_URL; ?>admin/refunds/refunds.php" class="<?php echo $currentDir=='refunds'?'active':''; ?>"><i class="fa-solid fa-rotate-left"></i> Refunds<?php
        $pendingRefundResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM cancellations WHERE refund_status IN ('Pending','Processing')");
        $pendingRefundCount = $pendingRefundResult ? (int) mysqli_fetch_assoc($pendingRefundResult)['total'] : 0;
        if ($pendingRefundCount > 0) echo ' <span class="badge bg-warning text-dark rounded-pill ms-1">' . $pendingRefundCount . '</span>';
    ?></a>
    <a href="<?php echo BASE_URL; ?>admin/reports/flight-report.php" class="<?php echo $currentDir=='reports'?'active':''; ?>"><i class="fa-solid fa-chart-line"></i> Reports</a>
    <a href="<?php echo BASE_URL; ?>admin/announcements/announcements.php" class="<?php echo $currentDir=='announcements'?'active':''; ?>"><i class="fa-solid fa-bullhorn"></i> Announcements</a>
    <a href="<?php echo BASE_URL; ?>admin/feedback/feedback.php" class="<?php echo $currentDir=='feedback'?'active':''; ?>"><i class="fa-solid fa-comment-dots"></i> Feedback<?php
        $pendingFbResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM feedback WHERE status='Pending'");
        $pendingFbCount = $pendingFbResult ? (int) mysqli_fetch_assoc($pendingFbResult)['total'] : 0;
        if ($pendingFbCount > 0) echo ' <span class="badge bg-danger rounded-pill ms-1">' . $pendingFbCount . '</span>';
    ?></a>
    <a href="<?php echo BASE_URL; ?>admin/settings/change-password.php" class="<?php echo $currentDir=='settings'?'active':''; ?>"><i class="fa-solid fa-key"></i> Change Password</a>
    <a href="<?php echo BASE_URL; ?>index.php" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> View Public Website</a>
    <a href="<?php echo BASE_URL; ?>admin/logout.php" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
  </nav>
</aside>
