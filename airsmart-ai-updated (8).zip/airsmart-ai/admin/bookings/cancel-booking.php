<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';

$bookingId = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT * FROM bookings WHERE booking_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$b = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$b || $b['booking_status'] !== 'Confirmed') {
    setAlert('This booking cannot be cancelled.', 'warning');
    redirect(BASE_URL . 'admin/bookings/bookings.php');
}

// Admin-initiated cancellations (e.g. flight rescheduled/cancelled by the
// airline) are not the traveller's fault, so they always qualify for a
// full 100% refund, regardless of how close the departure date is.
$refundPercentage = 100;
$refundAmount = round($b['total_amount'] * $refundPercentage / 100, 2);

mysqli_begin_transaction($conn);
try {
    $stmt = mysqli_prepare($conn, "UPDATE bookings SET booking_status='Cancelled', payment_status='Refunded', cancellation_date=NOW() WHERE booking_id=?");
    mysqli_stmt_bind_param($stmt, 'i', $bookingId);
    mysqli_stmt_execute($stmt);

    $reason = 'Cancelled by admin.';
    $refundStatus = 'Processing';
    $stmt = mysqli_prepare($conn, "INSERT INTO cancellations (booking_id, reason, cancelled_by, refund_amount, refund_percentage, refund_status, updated_at)
        VALUES (?, ?, 'Admin', ?, ?, ?, NOW())");
    mysqli_stmt_bind_param($stmt, 'isdds', $bookingId, $reason, $refundAmount, $refundPercentage, $refundStatus);
    mysqli_stmt_execute($stmt);

    mysqli_query($conn, "DELETE FROM seats WHERE booking_id = " . (int)$bookingId);

    if ($b['travel_class'] === 'Business') {
        mysqli_query($conn, "UPDATE flights SET business_available_seats = business_available_seats + " . (int)$b['passenger_count'] . " WHERE flight_id = " . (int)$b['flight_id']);
    } else {
        mysqli_query($conn, "UPDATE flights SET economy_available_seats = economy_available_seats + " . (int)$b['passenger_count'] . " WHERE flight_id = " . (int)$b['flight_id']);
    }

    mysqli_commit($conn);
    setAlert('Booking cancelled and seats released. A 100% refund of ' . formatMoney($refundAmount) . ' has been queued for processing.', 'success');
} catch (Exception $e) {
    mysqli_rollback($conn);
    setAlert('Could not cancel booking. Please try again.', 'danger');
}
redirect(BASE_URL . 'admin/bookings/bookings.php');
