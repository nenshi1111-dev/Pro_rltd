<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'View Booking';

$bookingId = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT b.*, u.full_name, u.email, u.mobile, f.flight_number, f.airline_name, f.source, f.destination, f.departure_date, f.departure_time, f.arrival_time
    FROM bookings b JOIN users u ON b.user_id=u.user_id JOIN flights f ON b.flight_id=f.flight_id WHERE b.booking_id=?");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$b = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$b) {
    setAlert('Booking not found.', 'danger');
    redirect(BASE_URL . 'admin/bookings/bookings.php');
}

$stmt = mysqli_prepare($conn, "SELECT * FROM passengers WHERE booking_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$passengers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$stmt = mysqli_prepare($conn, "SELECT * FROM payments WHERE booking_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $bookingId);
mysqli_stmt_execute($stmt);
$payment = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$cancellation = null;
if ($b['booking_status'] === 'Cancelled') {
    $stmt = mysqli_prepare($conn, "SELECT * FROM cancellations WHERE booking_id = ? ORDER BY cancellation_id DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $bookingId);
    mysqli_stmt_execute($stmt);
    $cancellation = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
require_once '../includes/topbar.php';
?>
<div class="admin-card">
  <h5><i class="fa-solid fa-ticket"></i> Booking <?php echo clean($b['booking_reference']); ?></h5>
  <div class="row">
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">User</span><span class="value"><?php echo clean($b['full_name']); ?> (<?php echo clean($b['email']); ?>)</span></div>
      <div class="ticket-row"><span class="label">Flight</span><span class="value"><?php echo clean($b['flight_number']); ?> - <?php echo clean($b['airline_name']); ?></span></div>
      <div class="ticket-row"><span class="label">Route</span><span class="value"><?php echo clean($b['source']); ?> → <?php echo clean($b['destination']); ?></span></div>
      <div class="ticket-row"><span class="label">Date</span><span class="value"><?php echo formatDate($b['departure_date']); ?></span></div>
    </div>
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Class</span><span class="value"><?php echo clean($b['travel_class']); ?></span></div>
      <div class="ticket-row"><span class="label">Passengers</span><span class="value"><?php echo (int)$b['passenger_count']; ?></span></div>
      <div class="ticket-row"><span class="label">Amount</span><span class="value"><?php echo formatMoney($b['total_amount']); ?></span></div>
      <div class="ticket-row"><span class="label">Status</span><span class="value"><?php echo clean($b['booking_status']); ?> / <?php echo clean($b['payment_status']); ?></span></div>
    </div>
  </div>
  <?php if ($payment): ?>
    <div class="ticket-row"><span class="label">Transaction ID</span><span class="value"><?php echo clean($payment['transaction_id']); ?></span></div>
    <div class="ticket-row"><span class="label">Card</span><span class="value"><?php echo clean($payment['masked_card_number']); ?></span></div>
  <?php endif; ?>
  <a href="bookings.php" class="btn btn-outline-secondary mt-3">Back</a>
</div>

<?php if ($cancellation): ?>
<div class="admin-card">
  <h5><i class="fa-solid fa-rotate-left"></i> Refund Details</h5>
  <div class="row">
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Cancelled By</span><span class="value"><?php echo clean($cancellation['cancelled_by']); ?></span></div>
      <div class="ticket-row"><span class="label">Refund Percentage</span><span class="value"><?php echo (float) $cancellation['refund_percentage']; ?>%</span></div>
    </div>
    <div class="col-md-6">
      <div class="ticket-row"><span class="label">Refund Amount</span><span class="value"><?php echo formatMoney($cancellation['refund_amount']); ?></span></div>
      <div class="ticket-row"><span class="label">Refund Status</span><span class="value"><span class="badge bg-<?php echo refundStatusBadge($cancellation['refund_status']); ?>"><?php echo clean($cancellation['refund_status']); ?></span></span></div>
    </div>
  </div>
  <a href="<?php echo BASE_URL; ?>admin/refunds/refunds.php" class="btn btn-sm btn-outline-primary mt-2"><i class="fa-solid fa-arrow-up-right-from-square"></i> Manage in Refunds</a>
</div>
<?php endif; ?>

<div class="admin-card">
  <h5>Passengers</h5>
  <div class="table-responsive">
    <table class="table table-custom">
      <thead><tr><th>#</th><th>Name</th><th>Gender</th><th>DOB</th><th>ID Number</th><th>Seat</th></tr></thead>
      <tbody>
      <?php foreach ($passengers as $i => $p): ?>
        <tr>
          <td><?php echo $i+1; ?></td>
          <td><?php echo clean($p['full_name']); ?></td>
          <td><?php echo clean($p['gender']); ?></td>
          <td><?php echo formatDate($p['dob']); ?></td>
          <td><?php echo clean($p['id_number']); ?></td>
          <td><?php echo clean($p['seat_number']); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require_once '../includes/footer.php'; ?>
