/* ============================================================
   AIRSMART AI - ADMIN PANEL JAVASCRIPT
   Most shared behaviour (password eye icon, delete confirm) is
   already handled by js/script.js, which is loaded on every
   admin page too. This file is for admin-only extras.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {
  // Close the mobile sidebar when a link inside it is clicked
  document.querySelectorAll('.admin-nav a').forEach(function (link) {
    link.addEventListener('click', function () {
      var sidebar = document.querySelector('.admin-sidebar');
      if (sidebar) sidebar.classList.remove('show');
    });
  });
});
