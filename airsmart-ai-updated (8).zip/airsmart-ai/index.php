<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Home';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

// Fetch a few recommended / upcoming flights to show on home page
$flightQuery = "SELECT * FROM flights WHERE departure_date >= CURDATE() AND status='Scheduled' ORDER BY departure_date ASC LIMIT 3";
$flightResult = mysqli_query($conn, $flightQuery);
?>

<!-- ================= HERO SECTION ================= -->
<section class="hero-section">
  <div class="hero-clouds"></div>
  <div class="hero-plane-layer">
    <i class="fa-solid fa-plane flying-plane plane-1"></i>
    <i class="fa-solid fa-plane flying-plane plane-2"></i>
    <i class="fa-solid fa-plane flying-plane plane-3"></i>
  </div>
  <div class="container">
    <span class="badge-hero"><i class="fa-solid fa-plane-up"></i> Trusted by travellers across India</span>
    <h1>Welcome To Sky Book</h1>
    <p class="lead">Smart, Fast and Easy Airline Ticket Booking</p>
    <a href="#searchCard" class="btn btn-primary-custom me-2">Search Flights</a>
    <a href="flights.php" class="btn btn-outline-custom">Explore Flights</a>
  </div>
</section>

<!-- ================= FLIGHT SEARCH CARD ================= -->
<div class="container">
  <div class="search-card" id="searchCard">
    <h5 class="mb-3"><i class="fa-solid fa-magnifying-glass text-primary"></i> Search Your Flight</h5>
    <form action="flights.php" method="GET">
      <div class="row g-3">
        <div class="col-md-3">
          <label>From</label>
          <input type="text" name="source" class="form-control" placeholder="e.g. Rajkot" required>
        </div>
        <div class="col-md-3">
          <label>To</label>
          <input type="text" name="destination" class="form-control" placeholder="e.g. Mumbai" required>
        </div>
        <div class="col-md-2">
          <label>Departure Date</label>
          <input type="date" name="departure_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" required>
        </div>
        <div class="col-md-2">
          <label>Class</label>
          <select name="travel_class" class="form-select">
            <option value="Economy">Economy</option>
            <option value="Business">Business</option>
          </select>
        </div>
        <div class="col-md-2">
          <label>Passengers</label>
          <input type="number" name="passengers" class="form-control" value="1" min="1" max="9">
        </div>
      </div>
      <div class="text-center mt-4">
        <button type="submit" class="btn btn-dark-blue px-5"><i class="fa-solid fa-magnifying-glass"></i> Search Flights</button>
      </div>
    </form>
  </div>
</div>

<!-- ================= WHY CHOOSE US ================= -->
<section class="container my-5 py-4">
  <div class="section-title">
    <h2>Why Choose Sky Book</h2>
    <p>Everything you need for a smooth flight booking experience</p>
  </div>
  <div class="row g-4">
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-ticket"></i><h6>Easy Booking</h6></div>
    </div>
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-brain"></i><h6>Smart Recommendations</h6></div>
    </div>
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-lock"></i><h6>Secure Payment</h6></div>
    </div>
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-chair"></i><h6>Seat Selection</h6></div>
    </div>
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-bolt"></i><h6>Instant Ticket</h6></div>
    </div>
    <div class="col-md-4 col-lg-2">
      <div class="feature-card"><i class="fa-solid fa-clock-rotate-left"></i><h6>Booking History</h6></div>
    </div>
  </div>
</section>

<!-- ================= POPULAR DESTINATIONS ================= -->
<section class="container my-5 py-4">
  <div class="section-title">
    <h2>Popular Destinations</h2>
    <p>Explore the most booked routes on Sky Book</p>
  </div>
  <div class="row g-4">
    <div class="col-md-3 col-6">
      <div class="destination-card">
        <div class="destination-img-wrap">
          <img src="<?php echo BASE_URL; ?>images/Chennai.jpg" alt="Chennai">
        </div>
        <div class="destination-name"><h6><i class="fa-solid fa-location-dot"></i>Chennai</h6></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="destination-card">
        <div class="destination-img-wrap">
          <img src="<?php echo BASE_URL; ?>images/delhi.jpg" alt="Delhi">
        </div>
        <div class="destination-name"><h6><i class="fa-solid fa-location-dot"></i>Delhi</h6></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="destination-card">
        <div class="destination-img-wrap">
          <img src="<?php echo BASE_URL; ?>images/goa.jpg" alt="Goa">
        </div>
        <div class="destination-name"><h6><i class="fa-solid fa-location-dot"></i>Goa</h6></div>
      </div>
    </div>
    <div class="col-md-3 col-6">
      <div class="destination-card">
        <div class="destination-img-wrap">
          <img src="<?php echo BASE_URL; ?>images/mumbai.jpg" alt="Mumbai">
        </div>
        <div class="destination-name"><h6><i class="fa-solid fa-location-dot"></i>Mumbai</h6></div>
      </div>
    </div>
  </div>
</section>

<!-- ================= RECOMMENDED FLIGHTS ================= -->
<section class="container my-5 py-4">
  <div class="section-title">
    <h2>Recommended Flights <i class="fa-solid fa-star text-warning"></i></h2>
    <p>A few upcoming flights you might like</p>
  </div>
  <div class="row">
    <?php if (mysqli_num_rows($flightResult) > 0): ?>
      <?php while ($f = mysqli_fetch_assoc($flightResult)): ?>
        <div class="col-md-4">
          <div class="flight-card">
            <div class="d-flex justify-content-between mb-2">
              <span class="flight-number"><?php echo clean($f['flight_number']); ?></span>
              <span class="badge-recommend">Recommended</span>
            </div>
            <div class="route-time"><?php echo clean($f['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($f['destination']); ?></div>
            <p class="mb-1 text-muted"><?php echo formatDate($f['departure_date']); ?> | <?php echo formatTime($f['departure_time']); ?></p>
            <p class="price mb-2"><?php echo formatMoney($f['economy_price']); ?> <small class="text-muted fs-6">/ Economy</small></p>
            <a href="flights.php" class="btn btn-primary-custom w-100">View Details</a>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p class="text-center text-muted">No upcoming flights available right now.</p>
    <?php endif; ?>
  </div>
</section>

<!-- ================= HOW IT WORKS ================= -->
<section class="container my-5 py-4">
  <div class="section-title">
    <h2>How It Works</h2>
    <p>Book your flight in 6 simple steps</p>
  </div>
  <div class="row text-center g-4">
    <div class="col-6 col-md-2">
      <div class="step-circle">1</div>
      <p class="fw-semibold">Search Flight</p>
    </div>
    <div class="col-6 col-md-2">
      <div class="step-circle">2</div>
      <p class="fw-semibold">Select Flight</p>
    </div>
    <div class="col-6 col-md-2">
      <div class="step-circle">3</div>
      <p class="fw-semibold">Select Seats</p>
    </div>
    <div class="col-6 col-md-2">
      <div class="step-circle">4</div>
      <p class="fw-semibold">Passenger Details</p>
    </div>
    <div class="col-6 col-md-2">
      <div class="step-circle">5</div>
      <p class="fw-semibold">Make Payment</p>
    </div>
    <div class="col-6 col-md-2">
      <div class="step-circle">6</div>
      <p class="fw-semibold">Get Ticket</p>
    </div>
  </div>
</section>

<!-- ================= CONTACT PREVIEW ================= -->
<section class="container my-5 py-4">
  <div class="row g-4 text-center">
    <div class="col-md-4">
      <div class="feature-card"><i class="fa-solid fa-phone"></i><h6>Phone</h6><p class="mb-0">+91 98765 43210</p></div>
    </div>
    <div class="col-md-4">
      <div class="feature-card"><i class="fa-solid fa-envelope"></i><h6>Email</h6><p class="mb-0">support@skybook.com</p></div>
    </div>
    <div class="col-md-4">
      <div class="feature-card"><i class="fa-solid fa-location-dot"></i><h6>Address</h6><p class="mb-0">Rajkot, Gujarat, India</p></div>
    </div>
  </div>
</section>

<!-- ================= FEEDBACK CALL-TO-ACTION ================= -->
<section class="container my-5 py-4">
  <div class="glass-card text-center p-5" style="background:linear-gradient(135deg, var(--primary-dark-blue), #123a6b); color:#fff;">
    <i class="fa-solid fa-comments fa-2x mb-3" style="color:var(--accent-sky-blue);"></i>
    <h2 style="color:#fff;">We'd Love to Hear From You</h2>
    <p style="color:#dce8fa;" class="mb-4">Tell us about your booking experience and help us make Sky Book even better.</p>
    <a href="feedback.php" class="btn btn-primary-custom feedback-hero-btn">
      <i class="fa-solid fa-star"></i> Give Feedback
    </a>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
