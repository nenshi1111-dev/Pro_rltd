<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'About Us';
require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<section class="hero-section" style="padding:80px 0;">
  <div class="container">
    <h1>About Sky Book</h1>
    <p class="lead">Smart, Fast and Easy Airline Ticket Booking</p>
  </div>
</section>

<section class="container my-5 py-4">
  <div class="row align-items-center g-5">
    <div class="col-md-6">
      <img src="<?php echo BASE_URL; ?>images/abouts.jpg" class="img-fluid rounded-4 shadow" alt="Sky Book">
    </div>
    <div class="col-md-6">
      <h2>What is Sky Book?</h2>
      <p>Sky Book is a complete online airline ticket booking system built as a BCA college final-year project. It allows registered users to search flights, view smart flight recommendations, select a travel class and seat, enter passenger details, make a secure payment, and instantly generate an electronic airline ticket.</p>

      <h5 class="mt-4"><i class="fa-solid fa-bullseye text-primary"></i> Project Objective</h5>
      <p>The objective of this project is to demonstrate a real-world style booking workflow using PHP, MySQL, HTML, CSS, JavaScript and Bootstrap — while keeping the code simple, secure and easy to explain in a viva.</p>
    </div>
  </div>

  <div class="row g-4 mt-3">
    <div class="col-md-3 col-6">
      <div class="feature-card"><i class="fa-solid fa-brain"></i><h6>Smart Flight Recommendation</h6><p class="small mb-0 text-muted">Simple scoring algorithm suggests the best flight for you.</p></div>
    </div>
    <div class="col-md-3 col-6">
      <div class="feature-card"><i class="fa-solid fa-ticket"></i><h6>Easy Booking</h6><p class="small mb-0 text-muted">Search, select and book in a few clicks.</p></div>
    </div>
    <div class="col-md-3 col-6">
      <div class="feature-card"><i class="fa-solid fa-lock"></i><h6>Secure Payment</h6><p class="small mb-0 text-muted">Card details are validated and never stored in full.</p></div>
    </div>
    <div class="col-md-3 col-6">
      <div class="feature-card"><i class="fa-solid fa-file-invoice"></i><h6>Online Ticket Generation</h6><p class="small mb-0 text-muted">Instant boarding-pass style e-ticket after booking.</p></div>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>
