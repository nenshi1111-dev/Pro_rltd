<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Login';

// If already logged in, go straight to dashboard
if (isset($_SESSION['user_id'])) {
    redirect(BASE_URL . 'user/index.php');
}

$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameOrEmail = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($usernameOrEmail === '' || $password === '') {
        $errorMsg = 'Invalid username or password.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'ss', $usernameOrEmail, $usernameOrEmail);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] !== 'Active') {
                $errorMsg = 'Your account is inactive. Please contact support.';
            } else {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_name'] = $user['full_name'];
                redirect(BASE_URL . 'user/index.php');
            }
        } else {
            $errorMsg = 'Invalid username or password.';
        }
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<div class="auth-wrapper">
  <div class="auth-split">
    <div class="auth-image-col">
      <img src="<?php echo BASE_URL; ?>images/login.png" alt="Sky Book Login">
    </div>
    <div class="auth-form-col">
      <div class="auth-card">
        <h3><i class="fa-solid fa-right-to-bracket text-primary"></i> User Login</h3>
        <p class="sub">Login to book and manage your flight tickets</p>

        <?php if ($errorMsg): ?>
          <div class="alert alert-danger"><?php echo clean($errorMsg); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
          <div class="mb-3">
            <label>Username or Email</label>
            <input type="text" name="username" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <div class="password-wrapper">
              <input type="password" name="password" id="loginPassword" class="form-control" required>
              <i class="fa-solid fa-eye toggle-eye"></i>
            </div>
          </div>
          <button type="submit" class="btn btn-primary-custom w-100 mt-2">Login</button>
        </form>

        <p class="text-center mt-4 mb-0">Don't have an account? <a href="register.php">Register here</a></p>
        <p class="text-center mt-2 mb-0"><a href="admin/login.php" class="small text-muted"><i class="fa-solid fa-user-shield"></i> Admin Login</a></p>
      </div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
