<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'My Feedback';

$userId = $_SESSION['user_id'];
$stmt = mysqli_prepare($conn, "SELECT * FROM feedback WHERE user_id = ? ORDER BY created_at DESC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$myFeedback = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
      <div class="section-title text-start mb-0"><h2 class="mb-0">My Feedback</h2></div>
      <a href="<?php echo BASE_URL; ?>feedback.php" class="btn btn-primary-custom"><i class="fa-solid fa-comment-dots"></i> Give New Feedback</a>
    </div>
    <?php showAlert(); ?>

    <?php if (empty($myFeedback)): ?>
      <div class="dash-card text-center py-5">
        <i class="fa-solid fa-comment-dots fs-1 text-muted mb-3 d-block"></i>
        <p class="text-muted mb-3">You have not submitted any feedback yet.</p>
        <a href="<?php echo BASE_URL; ?>feedback.php" class="btn btn-primary-custom">Share Your Feedback</a>
      </div>
    <?php endif; ?>

    <?php foreach ($myFeedback as $fb): ?>
      <div class="feedback-card">
        <div class="d-flex justify-content-between flex-wrap gap-2">
          <div>
            <small class="text-muted"><i class="fa-solid fa-clock"></i> Submitted on <?php echo date('d M Y, h:i A', strtotime($fb['created_at'])); ?></small>
          </div>
          <div class="text-end">
            <?php if ($fb['rating']): ?>
              <div class="feedback-stars-display">
                <?php for ($i = 1; $i <= 5; $i++) echo $i <= $fb['rating'] ? '★' : '☆'; ?>
              </div>
            <?php endif; ?>
            <span class="badge bg-<?php echo $fb['status'] == 'Replied' ? 'success' : 'warning'; ?>">
              <?php echo clean($fb['status']); ?>
            </span>
          </div>
        </div>

        <!-- Conversation-style layout: your message, then the admin's reply -->
        <div class="feedback-msg-bubble mine mt-3">
          <div class="label"><i class="fa-solid fa-user"></i> You</div>
          <p class="mb-0"><?php echo nl2br(clean($fb['message'])); ?></p>
        </div>

        <?php if ($fb['status'] == 'Replied'): ?>
          <div class="feedback-msg-bubble theirs">
            <div class="label"><i class="fa-solid fa-headset"></i> Admin Reply — <?php echo date('d M Y, h:i A', strtotime($fb['replied_at'])); ?></div>
            <p class="mb-0"><?php echo nl2br(clean($fb['admin_reply'])); ?></p>
          </div>
        <?php else: ?>
          <div class="feedback-msg-bubble waiting">
            <i class="fa-solid fa-hourglass-half"></i> Waiting for admin's reply...
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
