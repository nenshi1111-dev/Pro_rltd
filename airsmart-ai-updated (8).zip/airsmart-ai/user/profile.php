<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'My Profile';

$userId = $_SESSION['user_id'];
$errors = [];

$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean($_POST['full_name'] ?? '');
    $mobile = clean($_POST['mobile'] ?? '');
    $address = clean($_POST['address'] ?? '');

    if ($full_name === '') $errors[] = 'Full name is required.';
    if (!preg_match('/^[0-9]{10}$/', $mobile)) $errors[] = 'Please enter a valid 10 digit mobile number.';

    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "UPDATE users SET full_name=?, mobile=?, address=? WHERE user_id=?");
        mysqli_stmt_bind_param($stmt, 'sssi', $full_name, $mobile, $address, $userId);
        mysqli_stmt_execute($stmt);
        $_SESSION['user_name'] = $full_name;
        setAlert('Profile updated successfully.', 'success');
        redirect('profile.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>

<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <?php showAlert(); ?>

    <div class="dash-card" style="max-width:650px;">
      <h4 class="mb-4"><i class="fa-solid fa-user text-primary"></i> My Profile</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0"><?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?></ul>
        </div>
      <?php endif; ?>

      <p class="text-muted small mb-1">User ID: #<?php echo $user['user_id']; ?> &nbsp;|&nbsp; Joined on <?php echo formatDate($user['created_at']); ?></p>

      <form method="POST" action="profile.php">
        <div class="row g-3">
          <div class="col-md-6">
            <label>Full Name</label>
            <input type="text" name="full_name" class="form-control" value="<?php echo clean($user['full_name']); ?>" required>
          </div>
          <div class="col-md-6">
            <label>Gender</label>
            <input type="text" class="form-control" value="<?php echo clean($user['gender']); ?>" disabled>
          </div>
          <div class="col-md-6">
            <label>Date of Birth</label>
            <input type="text" class="form-control" value="<?php echo formatDate($user['dob']); ?>" disabled>
          </div>
          <div class="col-md-6">
            <label>Mobile Number</label>
            <input type="text" name="mobile" maxlength="10" class="form-control" value="<?php echo clean($user['mobile']); ?>" required>
          </div>
          <div class="col-md-6">
            <label>Email</label>
            <input type="text" class="form-control" value="<?php echo clean($user['email']); ?>" disabled>
          </div>
          <div class="col-md-6">
            <label>Username</label>
            <input type="text" class="form-control" value="<?php echo clean($user['username']); ?>" disabled>
          </div>
          <div class="col-12">
            <label>Address</label>
            <input type="text" name="address" class="form-control" value="<?php echo clean($user['address']); ?>">
          </div>
        </div>
        <button type="submit" class="btn btn-primary-custom mt-4">Update Profile</button>
        <a href="change-password.php" class="btn btn-outline-secondary mt-4"><i class="fa-solid fa-key"></i> Change Password</a>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/user-footer.php'; ?>
