<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'My Dashboard';

$userId = $_SESSION['user_id'];

// ---------------- Summary counts ----------------
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$totalBookings = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings b JOIN flights f ON b.flight_id = f.flight_id WHERE b.user_id = ? AND b.booking_status='Confirmed' AND f.departure_date >= CURDATE()");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$upcoming = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings WHERE user_id = ? AND booking_status='Completed'");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$completed = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM bookings WHERE user_id = ? AND booking_status='Cancelled'");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$cancelled = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

// ---------------- Total amount spent (successful / refunded payments) ----------------
$stmt = mysqli_prepare($conn, "SELECT IFNULL(SUM(total_amount),0) AS total FROM bookings WHERE user_id = ? AND payment_status IN ('Success','Refunded')");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$totalSpent = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

// ---------------- Refund information ----------------
$stmt = mysqli_prepare($conn, "SELECT c.*, b.booking_reference, b.total_amount FROM cancellations c
    JOIN bookings b ON c.booking_id = b.booking_id WHERE b.user_id = ? ORDER BY c.cancellation_date DESC LIMIT 5");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$myRefunds = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$stmt = mysqli_prepare($conn, "SELECT IFNULL(SUM(c.refund_amount),0) AS total FROM cancellations c
    JOIN bookings b ON c.booking_id = b.booking_id WHERE b.user_id = ? AND c.refund_status='Completed'");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$totalRefunded = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['total'];

// ---------------- Upcoming booking ----------------
$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_date, f.departure_time
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id
    WHERE b.user_id = ? AND b.booking_status='Confirmed' AND f.departure_date >= CURDATE()
    ORDER BY f.departure_date ASC LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$upcomingBooking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// ---------------- Simple recommended flights ----------------
$recResult = mysqli_query($conn, "SELECT * FROM flights WHERE departure_date >= CURDATE() AND status='Scheduled' ORDER BY economy_price ASC LIMIT 3");

// ---------------- Graph data: booking status breakdown ----------------
$statusCounts = ['Pending' => 0, 'Confirmed' => 0, 'Completed' => 0, 'Cancelled' => 0];
$stmt = mysqli_prepare($conn, "SELECT booking_status, COUNT(*) AS total FROM bookings WHERE user_id = ? GROUP BY booking_status");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$statusResult = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($statusResult)) {
    $statusCounts[$row['booking_status']] = (int) $row['total'];
}

// ---------------- Graph data: my spending, last 6 months ----------------
$stmt = mysqli_prepare($conn, "SELECT DATE_FORMAT(booking_date,'%b %y') AS label, DATE_FORMAT(booking_date,'%Y-%m') AS ym, SUM(total_amount) AS amt
    FROM bookings WHERE user_id = ? AND payment_status = 'Success' AND booking_date >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
    GROUP BY ym ORDER BY ym ASC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$spendResult = mysqli_stmt_get_result($stmt);
$spendLabels = [];
$spendAmounts = [];
while ($row = mysqli_fetch_assoc($spendResult)) {
    $spendLabels[] = $row['label'];
    $spendAmounts[] = (float) $row['amt'];
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>

<div class="dashboard-wrapper">
  <div class="container">
    <?php showAlert(); ?>
    <h3 class="mb-1">Welcome, <?php echo clean($_SESSION['user_name']); ?> 👋</h3>
    <p class="text-muted mb-4">Here is a quick summary of your Sky Book account</p>

    <div class="row g-4 mb-4">
      <div class="col-md-3 col-6">
        <div class="dash-card">
          <i class="fa-solid fa-ticket icon"></i>
          <h3><?php echo $totalBookings; ?></h3>
          <p>Total Bookings</p>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="dash-card">
          <i class="fa-solid fa-plane-departure icon"></i>
          <h3><?php echo $upcoming; ?></h3>
          <p>Upcoming Flights</p>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="dash-card">
          <i class="fa-solid fa-circle-check icon"></i>
          <h3><?php echo $completed; ?></h3>
          <p>Completed Flights</p>
        </div>
      </div>
      <div class="col-md-3 col-6">
        <div class="dash-card">
          <i class="fa-solid fa-circle-xmark icon"></i>
          <h3><?php echo $cancelled; ?></h3>
          <p>Cancelled Bookings</p>
        </div>
      </div>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-md-6">
        <div class="dash-card">
          <i class="fa-solid fa-indian-rupee-sign icon"></i>
          <h3><?php echo formatMoney($totalSpent); ?></h3>
          <p>Total Amount Spent</p>
        </div>
      </div>
      <div class="col-md-6">
        <div class="dash-card">
          <i class="fa-solid fa-rotate-left icon"></i>
          <h3><?php echo formatMoney($totalRefunded); ?></h3>
          <p>Total Refunded (Completed)</p>
        </div>
      </div>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-md-5">
        <div class="chart-card">
          <h5><i class="fa-solid fa-chart-pie text-primary"></i> My Booking Overview</h5>
          <p class="chart-sub">Breakdown of all your bookings by status</p>
          <div class="chart-canvas-wrap h-220">
            <canvas id="userStatusChart"></canvas>
          </div>
        </div>
      </div>
      <div class="col-md-7">
        <div class="chart-card">
          <h5><i class="fa-solid fa-chart-column text-primary"></i> My Spending (Last 6 Months)</h5>
          <p class="chart-sub">Total amount paid for successful bookings, month by month</p>
          <div class="chart-canvas-wrap h-220">
            <canvas id="userSpendChart"></canvas>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-md-3 col-6">
        <a href="search-flights.php" class="dash-card text-decoration-none d-block text-center">
          <i class="fa-solid fa-magnifying-glass icon d-block mb-2"></i> Search Flights
        </a>
      </div>
      <div class="col-md-3 col-6">
        <a href="booking-history.php" class="dash-card text-decoration-none d-block text-center">
          <i class="fa-solid fa-clock-rotate-left icon d-block mb-2"></i> My Bookings
        </a>
      </div>
      <div class="col-md-3 col-6">
        <a href="profile.php" class="dash-card text-decoration-none d-block text-center">
          <i class="fa-solid fa-user icon d-block mb-2"></i> My Profile
        </a>
      </div>
      <div class="col-md-3 col-6">
        <a href="recommendations.php" class="dash-card text-decoration-none d-block text-center">
          <i class="fa-solid fa-star icon d-block mb-2"></i> Recommendations
        </a>
      </div>
    </div>

    <?php if ($upcomingBooking): ?>
    <div class="dash-card mb-4">
      <h5 class="mb-3"><i class="fa-solid fa-plane-departure text-primary"></i> Your Upcoming Flight</h5>
      <div class="d-flex justify-content-between flex-wrap">
        <div>
          <strong><?php echo clean($upcomingBooking['flight_number']); ?></strong> —
          <?php echo clean($upcomingBooking['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($upcomingBooking['destination']); ?><br>
          <small class="text-muted"><?php echo formatDate($upcomingBooking['departure_date']); ?> at <?php echo formatTime($upcomingBooking['departure_time']); ?></small>
        </div>
        <a href="view-booking.php?id=<?php echo $upcomingBooking['booking_id']; ?>" class="btn btn-primary-custom align-self-center">View Booking</a>
      </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($myRefunds)): ?>
    <div class="dash-card mb-4">
      <h5 class="mb-3"><i class="fa-solid fa-rotate-left text-primary"></i> Refund Information</h5>
      <div class="table-responsive">
        <table class="table table-custom align-middle mb-0">
          <thead><tr><th>Booking Ref</th><th>Original Amount</th><th>Refund %</th><th>Refund Amount</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($myRefunds as $r): ?>
            <tr>
              <td><?php echo clean($r['booking_reference']); ?></td>
              <td><?php echo formatMoney($r['total_amount']); ?></td>
              <td><?php echo (float) $r['refund_percentage']; ?>%</td>
              <td><?php echo formatMoney($r['refund_amount']); ?></td>
              <td><span class="badge bg-<?php echo refundStatusBadge($r['refund_status']); ?>"><?php echo clean($r['refund_status']); ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <div class="dash-card">
      <h5 class="mb-3"><i class="fa-solid fa-star text-warning"></i> Smart Recommended Flights</h5>
      <div class="row">
        <?php while ($f = mysqli_fetch_assoc($recResult)): ?>
          <div class="col-md-4 mb-3">
            <div class="flight-card mb-0">
              <span class="flight-number"><?php echo clean($f['flight_number']); ?></span>
              <div class="route-time" style="font-size:1.1rem;"><?php echo clean($f['source']); ?> <i class="fa-solid fa-arrow-right"></i> <?php echo clean($f['destination']); ?></div>
              <small class="text-muted d-block mb-2"><?php echo formatDate($f['departure_date']); ?></small>
              <a href="booking.php?flight_id=<?php echo $f['flight_id']; ?>&class=Economy&passengers=1" class="btn btn-primary-custom w-100 btn-sm">Book Now</a>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
</div>

<!-- Chart.js for dashboard graphs -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<script>
(function() {
  const statusLabels = ['Confirmed', 'Pending', 'Completed', 'Cancelled'];
  const statusData = [
    <?php echo (int) $statusCounts['Confirmed']; ?>,
    <?php echo (int) $statusCounts['Pending']; ?>,
    <?php echo (int) $statusCounts['Completed']; ?>,
    <?php echo (int) $statusCounts['Cancelled']; ?>
  ];
  const statusColors = ['#1e90ff', '#f4b400', '#1fa971', '#dc3545'];

  new Chart(document.getElementById('userStatusChart'), {
    type: 'doughnut',
    data: {
      labels: statusLabels,
      datasets: [{
        data: statusData,
        backgroundColor: statusColors,
        borderWidth: 3,
        borderColor: '#fff',
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: { position: 'bottom', labels: { usePointStyle: true, padding: 16, font: { family: 'Poppins', size: 12 } } }
      }
    }
  });

  new Chart(document.getElementById('userSpendChart'), {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($spendLabels); ?>,
      datasets: [{
        label: 'Amount Spent (₹)',
        data: <?php echo json_encode($spendAmounts); ?>,
        backgroundColor: '#1e90ff',
        borderRadius: 8,
        maxBarThickness: 42
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, grid: { color: '#eef3fa' }, ticks: { font: { family: 'Poppins' } } },
        x: { grid: { display: false }, ticks: { font: { family: 'Poppins' } } }
      }
    }
  });
})();
</script>

<?php require_once '../includes/user-footer.php'; ?>
