<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Select Seats';

if (!isset($_SESSION['booking']) || empty($_SESSION['booking']['passengers'])) {
    setAlert('Please complete passenger details first.', 'warning');
    redirect(BASE_URL . 'user/passenger-details.php');
}
$booking = $_SESSION['booking'];
$passengerCount = (int) $booking['passenger_count'];
$travelClass = $booking['travel_class'];

$stmt = mysqli_prepare($conn, "SELECT * FROM flights WHERE flight_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $booking['flight_id']);
mysqli_stmt_execute($stmt);
$flight = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$totalSeatsForClass = ($travelClass === 'Business') ? $flight['business_total_seats'] : $flight['economy_total_seats'];
$seatMap = buildSeatMap($conn, $flight['flight_id'], $flight['departure_date'], $travelClass, $totalSeatsForClass);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedSeats = array_filter(array_map('trim', explode(',', $_POST['selected_seats'] ?? '')));
    $selectedSeats = array_values($selectedSeats);

    // ---------------- Rule 4: enough seats selected ----------------
    if (count($selectedSeats) !== $passengerCount) {
        $errors[] = "Please select exactly $passengerCount seat(s) for the passengers entered.";
    }

    // ---------------- Rule 5: duplicate seat inside this booking ----------------
    if (empty($errors) && count($selectedSeats) !== count(array_unique($selectedSeats))) {
        $errors[] = 'You cannot select the same seat twice.';
    }

    // ---------------- Rule 6 / Section 10: re-check DB, never trust frontend only ----------------
    if (empty($errors)) {
        foreach ($selectedSeats as $seat) {
            $stmt = mysqli_prepare($conn, "SELECT seat_id FROM seats WHERE flight_id = ? AND travel_date = ? AND seat_number = ? AND status = 'Booked'");
            mysqli_stmt_bind_param($stmt, 'iss', $flight['flight_id'], $flight['departure_date'], $seat);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_get_result($stmt)->num_rows > 0) {
                $errors[] = "Sorry, seat $seat has just been booked. Please select another seat.";
            }
        }
    }

    if (empty($errors)) {
        // Assign selected seats to passengers, in order
        $passengers = $_SESSION['booking']['passengers'];
        foreach ($passengers as $i => &$p) {
            $p['seat_number'] = $selectedSeats[$i];
        }
        unset($p);
        $_SESSION['booking']['passengers'] = $passengers;
        $_SESSION['booking']['seats'] = $selectedSeats;
        redirect(BASE_URL . 'user/payment.php');
    }
}

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container" style="max-width:750px;">
    <a href="passenger-details.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back</a>

    <div class="dash-card">
      <h4 class="mb-1"><i class="fa-solid fa-chair"></i> Select Your Seats</h4>
      <p class="text-muted">Flight <?php echo clean($flight['flight_number']); ?> — <?php echo clean($travelClass); ?> Class — choose <?php echo $passengerCount; ?> seat(s)</p>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.clean($e).'</li>'; ?></ul></div>
      <?php endif; ?>

      <div class="seat-legend text-center mb-3">
        <span><span class="legend-box" style="background:#fff;border:2px solid var(--accent-sky-blue);"></span> Available</span>
        <span><span class="legend-box" style="background:var(--accent-sky-blue);"></span> Selected</span>
        <span><span class="legend-box" style="background:#dcdcdc;"></span> Booked</span>
      </div>

      <form method="POST" action="seat-selection.php" id="seatForm">
        <input type="hidden" name="selected_seats" id="selected_seats" value="">

        <div class="seat-map mb-4">
          <?php foreach ($seatMap as $row): ?>
            <?php foreach ($row as $index => $seat): ?>
              <?php if ($index == ($travelClass === 'Business' ? 2 : 3)): ?><div class="seat-box aisle-gap"></div><?php endif; ?>
              <div class="seat-box <?php echo $seat['booked'] ? 'booked' : ''; ?>" data-seat="<?php echo $seat['seat']; ?>" onclick="toggleSeat(this, <?php echo $passengerCount; ?>)">
                <?php echo $seat['booked'] ? '<i class="fa-solid fa-lock"></i>' : clean($seat['seat']); ?>
              </div>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </div>

        <p class="text-center mb-4">Selected Seats: <strong id="selected_seats_display">No seats selected yet</strong></p>

        <button type="submit" class="btn btn-primary-custom w-100" onclick="return confirmSeats(<?php echo $passengerCount; ?>)">Continue to Payment <i class="fa-solid fa-arrow-right"></i></button>
      </form>
    </div>
  </div>
</div>
<script>
function confirmSeats(maxSeats) {
  var selected = document.querySelectorAll('.seat-box.selected').length;
  if (selected !== maxSeats) {
    alert('Please select exactly ' + maxSeats + ' seat(s) before continuing.');
    return false;
  }
  return true;
}
</script>
<?php require_once '../includes/user-footer.php'; ?>
