<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Destroy the user session and go back to the login page
session_unset();
session_destroy();
session_start();
setAlert('You have been logged out successfully.', 'success');
redirect(BASE_URL . 'login.php');
