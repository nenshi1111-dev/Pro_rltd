<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
$pageTitle = 'Booking History';

$userId = $_SESSION['user_id'];
$stmt = mysqli_prepare($conn, "SELECT b.*, f.flight_number, f.source, f.destination, f.departure_date, f.departure_time
    FROM bookings b JOIN flights f ON b.flight_id = f.flight_id
    WHERE b.user_id = ? ORDER BY b.booking_date DESC");
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$bookings = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

require_once '../includes/header.php';
require_once '../includes/user-sidebar.php';
?>
<div class="dashboard-wrapper">
  <div class="container">
    <a href="index.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Back to Dashboard</a>
    <div class="section-title text-start mb-4"><h2>My Bookings</h2></div>
    <?php showAlert(); ?>

    <div class="dash-card">
      <div class="table-responsive">
        <table class="table table-custom align-middle">
          <thead><tr><th>Booking Ref</th><th>Flight</th><th>Route</th><th>Date</th><th>Class</th><th>Passengers</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
          <?php if (empty($bookings)): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">You have not made any bookings yet.</td></tr>
          <?php endif; ?>
          <?php foreach ($bookings as $b): ?>
            <tr>
              <td><?php echo clean($b['booking_reference']); ?></td>
              <td><?php echo clean($b['flight_number']); ?></td>
              <td><?php echo clean($b['source']); ?> → <?php echo clean($b['destination']); ?></td>
              <td><?php echo formatDate($b['departure_date']); ?></td>
              <td><?php echo clean($b['travel_class']); ?></td>
              <td><?php echo (int)$b['passenger_count']; ?></td>
              <td><?php echo formatMoney($b['total_amount']); ?></td>
              <td>
                <?php
                  $badge = ['Confirmed'=>'success','Pending'=>'warning','Completed'=>'info','Cancelled'=>'danger'][$b['booking_status']] ?? 'secondary';
                ?>
                <span class="badge bg-<?php echo $badge; ?>"><?php echo clean($b['booking_status']); ?></span>
              </td>
              <td>
                <a href="view-booking.php?id=<?php echo $b['booking_id']; ?>" class="btn btn-sm btn-outline-primary mb-1"><i class="fa-solid fa-eye"></i></a>
                <?php if ($b['booking_status'] === 'Confirmed'): ?>
                  <a href="ticket.php?booking_id=<?php echo $b['booking_id']; ?>" class="btn btn-sm btn-primary-custom mb-1"><i class="fa-solid fa-ticket"></i></a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require_once '../includes/user-footer.php'; ?>
