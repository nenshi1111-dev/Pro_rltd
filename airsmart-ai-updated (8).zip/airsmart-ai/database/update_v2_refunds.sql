-- ============================================================
-- AIRSMART AI - DATABASE UPDATE SCRIPT (v2)
-- Run this ONLY if you already imported an earlier copy of
-- airline_db.sql and just want to add the new Percentage-Based
-- Refund System without losing your existing data.
--
-- HOW TO RUN:
--   1. Open phpMyAdmin -> select the "airline_db" database
--   2. Click the "SQL" tab
--   3. Paste everything below and click "Go"
--
-- (If you are setting up the project fresh, you do NOT need this
--  file — just import database/airline_db.sql, which already
--  includes these columns.)
-- ============================================================

USE airline_db;

-- 1) Add a refund_percentage column to store the % applied at cancellation
--    (skip this statement if the column already exists on your database)
ALTER TABLE cancellations
    ADD COLUMN refund_percentage DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER refund_amount;

-- 2) Expand refund_status to a full workflow: Pending -> Processing -> Completed / Rejected
ALTER TABLE cancellations
    MODIFY COLUMN refund_status ENUM('Pending','Processing','Completed','Rejected','Not Applicable') DEFAULT 'Pending';

-- 3) Track when the refund status was last changed by the admin
--    (skip this statement if the column already exists on your database)
ALTER TABLE cancellations
    ADD COLUMN updated_at DATETIME DEFAULT NULL AFTER refund_status;

-- ============================================================
-- END OF UPDATE SCRIPT
-- ============================================================
