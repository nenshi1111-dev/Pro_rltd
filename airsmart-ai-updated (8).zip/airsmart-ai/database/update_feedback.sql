-- ============================================================
-- AIRSMART AI - DATABASE UPDATE SCRIPT
-- Run this ONLY if you already imported the old airline_db.sql
-- and just want to add the new Feedback feature without losing
-- your existing data.
--
-- HOW TO RUN:
--   1. Open phpMyAdmin -> select the "airline_db" database
--   2. Click the "SQL" tab
--   3. Paste everything below and click "Go"
--
-- (If you are setting up the project fresh, you do NOT need this
--  file — just import database/airline_db.sql, which already
--  includes the feedback table.)
-- ============================================================

USE airline_db;

CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    rating TINYINT DEFAULT NULL,
    status ENUM('Pending','Replied') DEFAULT 'Pending',
    admin_reply TEXT DEFAULT NULL,
    replied_at DATETIME DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;
