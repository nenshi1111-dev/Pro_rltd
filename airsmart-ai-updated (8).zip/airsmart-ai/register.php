<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';
$pageTitle = 'Register';

if (isset($_SESSION['user_id'])) {
    redirect(BASE_URL . 'user/index.php');
}

$errors = [];
$old = ['full_name' => '', 'gender' => '', 'dob' => '', 'mobile' => '', 'email' => '', 'address' => '', 'username' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = clean($_POST['full_name'] ?? '');
    $gender = clean($_POST['gender'] ?? '');
    $dob = clean($_POST['dob'] ?? '');
    $mobile = clean($_POST['mobile'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $username = clean($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    $old = compact('full_name', 'gender', 'dob', 'mobile', 'email', 'address', 'username');

    // ---------------- Server-side validation ----------------
    if ($full_name === '' || $gender === '' || $dob === '' || $mobile === '' || $email === '' || $username === '' || $password === '') {
        $errors[] = 'Please fill all required fields.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (!preg_match('/^[0-9]{10}$/', $mobile)) {
        $errors[] = 'Please enter a valid 10 digit mobile number.';
    }
    if (strtotime($dob) > strtotime('-1 year')) {
        $errors[] = 'Please enter a valid date of birth.';
    }
    if ($password !== $confirm_password) {
        $errors[] = 'Password and Confirm Password do not match.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }

    if (empty($errors)) {
        // Check unique username
        $stmt = mysqli_prepare($conn, "SELECT user_id FROM users WHERE username = ?");
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
            $errors[] = 'This username is already taken.';
        }

        // Check unique email
        $stmt = mysqli_prepare($conn, "SELECT user_id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        if (mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
            $errors[] = 'This email is already registered.';
        }
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, gender, dob, mobile, email, address, username, password) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'ssssssss', $full_name, $gender, $dob, $mobile, $email, $address, $username, $hashedPassword);

        if (mysqli_stmt_execute($stmt)) {
            setAlert('Registration successful! Please login to continue.', 'success');
            redirect(BASE_URL . 'login.php');
        } else {
            $errors[] = 'Something went wrong. Please try again.';
        }
    }
}

require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>

<div class="auth-wrapper">
  <div class="auth-split" style="max-width:1050px;">
    <div class="auth-image-col">
      <img src="<?php echo BASE_URL; ?>images/register.png" alt="Sky Book Register">
    </div>
    <div class="auth-form-col">
  <div class="auth-card" style="max-width:650px;">
    <h3><i class="fa-solid fa-user-plus text-primary"></i> Create Account</h3>
    <p class="sub">Register to start booking flights on Sky Book</p>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="register.php" id="registerForm">
      <div class="row g-3">
        <div class="col-md-6">
          <label>Full Name</label>
          <input type="text" name="full_name" class="form-control" value="<?php echo clean($old['full_name']); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Gender</label>
          <select name="gender" class="form-select" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php echo $old['gender']=='Male'?'selected':''; ?>>Male</option>
            <option value="Female" <?php echo $old['gender']=='Female'?'selected':''; ?>>Female</option>
            <option value="Other" <?php echo $old['gender']=='Other'?'selected':''; ?>>Other</option>
          </select>
        </div>
        <div class="col-md-6">
          <label>Date of Birth</label>
          <input type="date" name="dob" class="form-control" value="<?php echo clean($old['dob']); ?>" max="<?php echo date('Y-m-d'); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Mobile Number</label>
          <input type="text" name="mobile" class="form-control" maxlength="10" value="<?php echo clean($old['mobile']); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Email</label>
          <input type="email" name="email" class="form-control" value="<?php echo clean($old['email']); ?>" required>
        </div>
        <div class="col-md-6">
          <label>Username</label>
          <input type="text" name="username" class="form-control" value="<?php echo clean($old['username']); ?>" required>
        </div>
        <div class="col-12">
          <label>Address</label>
          <input type="text" name="address" class="form-control" value="<?php echo clean($old['address']); ?>">
        </div>
        <div class="col-md-6">
          <label>Password</label>
          <div class="password-wrapper">
            <input type="password" name="password" id="regPassword" class="form-control" required minlength="6">
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
        <div class="col-md-6">
          <label>Confirm Password</label>
          <div class="password-wrapper">
            <input type="password" name="confirm_password" id="regConfirmPassword" class="form-control" required minlength="6">
            <i class="fa-solid fa-eye toggle-eye"></i>
          </div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary-custom w-100 mt-4">Register</button>
    </form>

    <p class="text-center mt-4 mb-0">Already have an account? <a href="login.php">Login here</a></p>
  </div>
    </div>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
