=================================================================
 SKY BOOK - AI BASED AIRLINE TICKET BOOKING SYSTEM
 Built with PHP (procedural, mysqli) + MySQL + Bootstrap 5
=================================================================

HOW TO SET UP ON XAMPP / WAMP
-------------------------------------------------
1. Copy the "airsmart-ai" folder into your server's root folder:
     XAMPP : C:\xampp\htdocs\airsmart-ai
     WAMP  : C:\wamp64\www\airsmart-ai

2. Start Apache and MySQL from the XAMPP/WAMP control panel.

3. Open phpMyAdmin: http://localhost/phpmyadmin
   - Click "Import"
   - Choose the file: airsmart-ai/database/airline_db.sql
   - Click "Go"
   This will create the "airline_db" database with all tables
   and sample/dummy data automatically.

4. Open includes/config.php and check the DB settings match your
   MySQL login (defaults below work for a fresh XAMPP/WAMP install):
     DB_HOST = localhost
     DB_USER = root
     DB_PASS = ''  (blank)
     DB_NAME = airline_db

   Also confirm BASE_URL matches your folder name, e.g.:
     define('BASE_URL', '/airsmart-ai/');

5. Visit the site in your browser:
     http://localhost/airsmart-ai/

-------------------------------------------------
LOGIN CREDENTIALS (DUMMY DATA)
-------------------------------------------------
ADMIN PANEL  -> http://localhost/airsmart-ai/admin/login.php
  Username: admin
  Password: admin123

USER LOGIN   -> http://localhost/airsmart-ai/login.php
  Username: rahulpatel   (or priyashah / amanverma / snehajoshi)
  Password: user123

-------------------------------------------------
TEST TIP
-------------------------------------------------
On the payment page, any 16-digit card number will succeed EXCEPT
a card number ending in "0000" - that is a demo/test card that
simulates a FAILED payment so you can test that flow too.

-------------------------------------------------
FOLDER STRUCTURE
-------------------------------------------------
/            -> public pages (home, about, flights, contact, login, register,
                feedback, thank-you)
/includes    -> shared config, header, navbar, footer, functions, auth guard,
                user-sidebar / user-footer (dashboard layout)
/user        -> logged-in user area (search, booking flow, tickets, history) -
                now uses a vertical sidebar layout
/admin       -> admin panel (flights, users, bookings, payments, reports,
                announcements, feedback, settings)
/css, /js    -> shared stylesheet and script
/database    -> airline_db.sql (import this first!)
                update_feedback.sql (only needed if you already had an
                older copy of this database and just want to add Feedback)

Enjoy building on Sky Book!

=================================================================
 UPDATE NOTES (UI/UX Upgrade)
=================================================================
This version adds:
  - bg.jpg used as the hero/background image across the site
  - Popular Destinations on the Home page: Chennai, Delhi, Goa, Mumbai
    (using the local images in /images)
  - login.png / register.png branding shown next to the Login and
    Register forms
  - About Us now uses images/abouts.jpg instead of the old bus photo
  - User Dashboard redesigned with a vertical sidebar (Search Flight,
    My Booking, My Profile, Recommendation, Logout)
  - Admin Dashboard: added a "Feedback" section with a pending-reply
    badge
  - New Feedback system:
      * Home page "Give Feedback" button -> feedback.php (login required)
      * Star rating + message, fully validated server-side
      * Admin can view all feedback and reply from
        admin/feedback/feedback.php
      * User is shown a "Thank You" page (thank-you.php) after submitting

If you already have the OLD airline_db database imported, run
database/update_feedback.sql once in phpMyAdmin to add the new
"feedback" table without touching any of your existing data. If you
are starting fresh, just import database/airline_db.sql as usual -
it already includes the feedback table.
