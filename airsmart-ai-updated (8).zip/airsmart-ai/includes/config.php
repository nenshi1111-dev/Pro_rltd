<?php
/* ============================================================
   AIRSMART AI - Database & Site Configuration
   Change DB_USER / DB_PASS below if your MySQL login is different.
   Default XAMPP/WAMP login is username "root" with a blank password.
   ============================================================ */

// Start the session on every page that includes this file
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------- Database Settings ----------
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'airline_db');

// ---------- Create Database Connection ----------
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}
mysqli_set_charset($conn, 'utf8mb4');

// ---------- Site Wide Settings ----------
define('SITE_NAME', 'Sky Book');

// BASE_URL is used everywhere so links work no matter which folder
// (root, user/, admin/, admin/flights/ etc.) the current page is in.
// IMPORTANT: change this if your project folder name is different.
define('BASE_URL', '/airsmart-ai/');

// ---------- Load common helper functions (clean, redirect, formatDate...) ----------
require_once __DIR__ . '/functions.php';

// ---------- Helper Function: get a system setting from the settings table ----------
function getSetting($conn, $key, $default = '') {
    $key = mysqli_real_escape_string($conn, $key);
    $result = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key = '$key' LIMIT 1");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['setting_value'];
    }
    return $default;
}
