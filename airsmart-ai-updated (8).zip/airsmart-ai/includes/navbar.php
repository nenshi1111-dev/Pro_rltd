<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar navbar-expand-lg navbar-dark sticky-top main-navbar">
  <div class="container">
    <a class="navbar-brand" href="<?php echo BASE_URL; ?>index.php">
      <i class="fa-solid fa-plane-up"></i> <?php echo SITE_NAME; ?>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center">
        <li class="nav-item"><a class="nav-link <?php echo $currentPage=='index.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $currentPage=='about.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>about.php">About</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $currentPage=='flights.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>flights.php">Flights</a></li>
        <li class="nav-item"><a class="nav-link <?php echo $currentPage=='contact.php'?'active':''; ?>" href="<?php echo BASE_URL; ?>contact.php">Contact</a></li>

        <?php if (isset($_SESSION['user_id'])): ?>
          <li class="nav-item"><a class="nav-link" href="<?php echo BASE_URL; ?>user/index.php"><i class="fa-solid fa-gauge"></i> Dashboard</a></li>
          <li class="nav-item"><a class="btn btn-outline-light btn-sm ms-lg-2 mt-2 mt-lg-0" href="<?php echo BASE_URL; ?>user/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="btn btn-nav-login ms-lg-2 mt-2 mt-lg-0" href="<?php echo BASE_URL; ?>login.php">Login</a></li>
          <li class="nav-item"><a class="btn btn-nav-register ms-lg-2 mt-2 mt-lg-0" href="<?php echo BASE_URL; ?>register.php">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
