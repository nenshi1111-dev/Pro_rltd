<?php
/* ============================================================
   AIRSMART AI - COMMON HELPER FUNCTIONS
   Small reusable functions used across user and admin pages.
   ============================================================ */

// Clean user input to prevent XSS when displaying data
function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Generate a unique booking reference like AS20260815001
function generateBookingReference($conn) {
    $prefix = 'AS' . date('Ymd');
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings WHERE booking_reference LIKE '$prefix%'");
    $row = mysqli_fetch_assoc($result);
    $next = $row['total'] + 1;
    return $prefix . str_pad($next, 3, '0', STR_PAD_LEFT);
}

// Generate a simple transaction id
function generateTransactionId() {
    return 'TXN' . time() . rand(100, 999);
}

// Generate a ticket number from the passenger id, e.g. TKT000001
function generateTicketNumber($passengerId) {
    return 'TKT' . str_pad($passengerId, 6, '0', STR_PAD_LEFT);
}

// Format a date nicely, e.g. 25 Aug 2026
function formatDate($date) {
    return date('d M Y', strtotime($date));
}

// Format time nicely, e.g. 10:30 AM
function formatTime($time) {
    return date('h:i A', strtotime($time));
}

// Format money with Indian Rupee symbol
function formatMoney($amount) {
    return '₹' . number_format($amount, 2);
}

// Redirect helper
function redirect($url) {
    header('Location: ' . $url);
    exit();
}

// Show a bootstrap alert message from session (used after redirects)
function showAlert() {
    if (isset($_SESSION['alert_message'])) {
        $type = $_SESSION['alert_type'] ?? 'info';
        $msg = $_SESSION['alert_message'];
        echo '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">'
            . clean($msg) .
            '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
        unset($_SESSION['alert_message']);
        unset($_SESSION['alert_type']);
    }
}

// Set an alert message to show after redirect
function setAlert($message, $type = 'info') {
    $_SESSION['alert_message'] = $message;
    $_SESSION['alert_type'] = $type; // success, danger, warning, info
}

/* ============================================================
   SIMPLE STUDENT-LEVEL "AI" FLIGHT RECOMMENDATION SCORING
   (Section 8 of the project prompt - no external AI API needed)

   Score = Price Score + Availability Score + Time Score + Route Match Score
   Shared by flights.php and user/search-flights.php so the logic
   is written only once (reusable include rule).
   ============================================================ */
function calculateFlightScore($flight, $travelClass, $searchedSource = '', $searchedDestination = '') {
    $price = ($travelClass === 'Business') ? $flight['business_price'] : $flight['economy_price'];
    $available = ($travelClass === 'Business') ? $flight['business_available_seats'] : $flight['economy_available_seats'];

    // Price Score: cheaper flights score higher (max 40 points)
    $priceScore = max(0, 40 - ($price / 200));

    // Availability Score: more available seats score higher (max 25 points)
    $availabilityScore = min(25, $available / 6);

    // Time Score: convenient daytime departure scores higher (max 20 points)
    $hour = (int) date('H', strtotime($flight['departure_time']));
    $timeScore = ($hour >= 6 && $hour <= 21) ? 20 : 10;

    // Route Match Score: exact source/destination match scores higher (max 15 points)
    $routeScore = 0;
    if ($searchedSource !== '' && stripos($flight['source'], $searchedSource) !== false) $routeScore += 8;
    if ($searchedDestination !== '' && stripos($flight['destination'], $searchedDestination) !== false) $routeScore += 7;
    if ($searchedSource === '' && $searchedDestination === '') $routeScore = 10;

    $total = round($priceScore + $availabilityScore + $timeScore + $routeScore, 1);

    // Simple human-readable reason
    $reasons = [];
    if ($priceScore >= 25) $reasons[] = 'lower price';
    if ($availabilityScore >= 15) $reasons[] = 'good seat availability';
    if ($timeScore == 20) $reasons[] = 'convenient departure time';
    if ($routeScore >= 8) $reasons[] = 'matches your searched route';
    if (empty($reasons)) $reasons[] = 'overall balanced score';

    $reasonText = 'Recommended because it has ' . implode(' and ', $reasons) . '.';

    return ['score' => $total, 'reason' => $reasonText];
}

/* ============================================================
   REFUND SYSTEM: percentage-based refund calculation
   Based on how many days remain before the flight's departure
   date at the moment of cancellation. Shared by the user and
   admin cancellation flows so the policy is written only once.
   ============================================================ */
function getRefundPolicyTiers() {
    return [
        ['label' => '7 or more days before departure', 'percentage' => 90],
        ['label' => '3 to 6 days before departure',     'percentage' => 50],
        ['label' => '1 to 2 days before departure',      'percentage' => 25],
        ['label' => 'Less than 24 hours / same day',     'percentage' => 0],
    ];
}

// Returns the refund percentage (0-100) that applies for a given departure date
function calculateRefundPercentage($departureDate) {
    $daysLeft = (strtotime($departureDate) - strtotime(date('Y-m-d'))) / 86400;
    if ($daysLeft >= 7) return 90;
    if ($daysLeft >= 3) return 50;
    if ($daysLeft >= 1) return 25;
    return 0;
}

// Bootstrap badge colour for a refund_status value
function refundStatusBadge($status) {
    $map = ['Pending' => 'warning', 'Processing' => 'info', 'Completed' => 'success', 'Rejected' => 'danger', 'Not Applicable' => 'secondary'];
    return $map[$status] ?? 'secondary';
}

// Build the seat map (A-F economy / A-D business) sized to the flight's
// actual total seat count for that class, and mark already booked seats.
function buildSeatMap($conn, $flightId, $travelDate, $travelClass, $totalSeats) {
    $cols = ($travelClass === 'Business') ? ['A','B','C','D'] : ['A','B','C','D','E','F'];
    $colCount = count($cols);
    $rows = (int) ceil($totalSeats / $colCount);

    // Get already booked seats for this exact flight + date + class
    $booked = [];
    $stmt = mysqli_prepare($conn, "SELECT seat_number FROM seats WHERE flight_id = ? AND travel_date = ? AND travel_class = ? AND status = 'Booked'");
    mysqli_stmt_bind_param($stmt, 'iss', $flightId, $travelDate, $travelClass);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $booked[] = $row['seat_number'];
    }

    $map = [];
    $seatCount = 0;
    for ($r = 1; $r <= $rows; $r++) {
        $rowSeats = [];
        foreach ($cols as $c) {
            if ($seatCount >= $totalSeats) break; // stop once we reach the flight's real seat total
            $seatNo = $r . $c;
            $rowSeats[] = ['seat' => $seatNo, 'booked' => in_array($seatNo, $booked)];
            $seatCount++;
        }
        if (!empty($rowSeats)) $map[] = $rowSeats;
    }
    return $map;
}
?>
