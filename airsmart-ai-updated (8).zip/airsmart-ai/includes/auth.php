<?php
/* ============================================================
   AirSmart AI - User Authentication Guard
   Include this file at the top of any page that a logged-in
   USER only should be able to access.
   ============================================================ */
if (!isset($_SESSION['user_id'])) {
    redirect(BASE_URL . 'login.php');
}
