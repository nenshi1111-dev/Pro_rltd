    </main><!-- /.user-main -->
  </div><!-- /.user-content-col -->
</div><!-- /.user-wrapper -->

<!-- Bootstrap JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<!-- Project custom JS -->
<script src="<?php echo BASE_URL; ?>js/script.js"></script>
</body>
</html>
